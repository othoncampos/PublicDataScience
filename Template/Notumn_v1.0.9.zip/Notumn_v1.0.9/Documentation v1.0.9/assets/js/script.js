(function($){
    
    /* ---------------------------------------------
     Clipboard
     --------------------------------------------- */
    function init_clipboardJs(){
        var clipboard = new Clipboard('.clip-btn-snippet, .clip-btn', {
            target: function(trigger) {
                return $(trigger).parent().find('code').get(0);
            }
        });
        
        $('.clip-btn-snippet, .clip-btn').tooltip({
            trigger: 'hover click',
            title: 'Copy to Clipboard',
        }).on('mouseleave', function(){
            $(this).attr('title', 'Copy to Clipboard')
                .tooltip('fixTitle').tooltip('hide');
        });
        
        clipboard.on('success', function(e) {
            e.clearSelection();
            $(e.trigger).attr('title', 'Copied!')
                .tooltip('fixTitle').tooltip('show');
        });
    }
    
    /* ---------------------------------------------
     HighlightJs
     --------------------------------------------- */
    function init_highlightJs(){
        $('pre code').each(function(i, block) {
            hljs.highlightBlock(block);
        });
    }
    
    /* ---------------------------------------------
     Scripts Initialization
     --------------------------------------------- */
    $(window).load(function(){
        
        // Hash menu forwarding
        if (window.location.hash){
            var hash_offset = $(window.location.hash).offset().top - 60;
            $("html, body").scrollTop(hash_offset);
        }
        
        $(window).trigger('resize');
    });
    
    $(document).ready(function(){
        $(window).trigger('resize');
        init_highlightJs();
        init_clipboardJs();
    });
    
})(jQuery);