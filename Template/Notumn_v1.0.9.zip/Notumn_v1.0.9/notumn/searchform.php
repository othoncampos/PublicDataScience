<?php
/**
 * Search Form.
 *
 * @package notumn
 * @since 1.0
 */

global $notumn_is_header;
$notumn_is_header = isset( $notumn_is_header ) ? $notumn_is_header : false;

if ( $notumn_is_header ) : ?>
	<form class="search-form form" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
		<input id="search" type="text" name="s" placeholder="<?php esc_attr_e( 'Type & Hit enter...', 'notumn' ); ?>" required>
		<input type="submit" value="">
		<div class="close-search">
			<i class="fa fa-close"></i>
		</div>
	</form>
<?php else : ?>
	<form action="<?php echo esc_url( home_url( '/' ) ); ?>" class="search-form form" method="get">
		<input type="text" class="search-field" name="s" placeholder="Search" required="required">
		<input type="submit" value="">
	</form>
<?php endif; ?>
