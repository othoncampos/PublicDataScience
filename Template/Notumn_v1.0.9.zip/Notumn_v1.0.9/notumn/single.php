<?php
/**
 * Single Template.
 *
 * @package notumn
 * @since 1.0
 */

$notumn_post_layout = get_post_meta( $post->ID, '_notumn-post-layout', true );
if ( empty( $notumn_post_layout ) ) {
	$notumn_post_layout = 'medium_sidebar';
}
$notumn_post_sidebar = ( preg_match( '/sidebar/', $notumn_post_layout ) ) ? true : false;
$notumn_container_lg = array( 'fullwidth' );

get_header();

if ( in_array( $notumn_post_layout, $notumn_container_lg, true ) ) : ?>
	<div class="container container-lg">
<?php else : ?>
	<div class="container">
<?php endif; ?>

	<div class="row">

		<?php if ( $notumn_post_layout === 'fullwidth' ) : ?>
		<div class="col-md-10 col-md-push-1">
			<?php else : ?>
			<div class="col-md-8 <?php echo sanitize_html_class( ( $notumn_post_sidebar ) ? 'posts-column' : 'col-md-push-2' ) ?>">
				<?php endif; ?>
				<div class="posts-container relative">

					<?php if ( have_posts() ) : while ( have_posts() ) : the_post() ?>
						<?php get_template_part( 'content' ); ?>
					<?php endwhile;
					endif; ?>

				</div><!-- .posts-container -->
			</div><!-- .posts-column -->

			<?php if ( $notumn_post_sidebar ) :
				get_sidebar( 'post' );
			endif; ?>

		</div><!-- .row -->
	</div><!-- .container -->

<?php
get_footer();
