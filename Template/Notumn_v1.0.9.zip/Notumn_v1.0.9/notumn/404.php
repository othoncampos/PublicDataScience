<?php
/**
 * 404 Page Template.
 *
 * @package notumn
 * @since 1.0
 */

get_header();
?>
	<div class="container">

		<div class="error-404">
			<h1 class="font-2">404</h1>
			<h2><?php esc_html_e( 'Page Not Found', 'notumn' ); ?></h2>
			<p><?php echo wp_kses_post( sprintf( '%s <br class="hidden-xs">%s',
				__( 'Oops! The page you are looking for could not be found.', 'notumn' ),
				__( 'Please check your url again or return home.', 'notumn' ) ) ); ?></p>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>"
			   class="btn btn-mod btn-dark"><?php esc_html_e( 'Return Home', 'notumn' ) ?></a>
		</div>

	</div>
<?php
get_footer();
