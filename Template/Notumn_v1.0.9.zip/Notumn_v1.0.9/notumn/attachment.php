<?php
/**
 * Template for displaying attached images.
 *
 * @package notumn
 * @since 1.0
 */

get_header();
?>
	<div class="container">
		<div class="row">

			<div class="col-md-8">
				<div class="posts-container relative">

					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

						<header class="entry-header">
							<h1 class="entry-title font-2">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h1>
							<div class="entry-date font-3" title="<?php the_time( 'Y-m-d H:i:s' ); ?>">
								<?php esc_html_e( 'Posted on', 'notumn' ); ?> <span class="date"><?php
									the_time( get_option( 'date_format' ) ); ?></span>
							</div>
						</header><!-- .entry header -->

						<?php if ( wp_attachment_is_image( $post->id ) ) : ?>
							<div class="entry-image">
								<div class="wp-caption">
									<a href="<?php echo esc_url( wp_get_attachment_url( $post->ID ) ); ?>"
									   target="_blank"><?php notumn_attachment_image( $post->ID, 'notumn_full_thumb' ); ?></a>
									<p class="wp-caption-text"><?php echo esc_html( $post->post_excerpt ); ?></p>
								</div>
							</div><!-- .entry-image -->
						<?php else : ?>
							<a href="<?php echo esc_html( wp_get_attachment_url( $post->ID ) ); ?>"
							   title="<?php echo esc_html( get_the_title( $post->ID ) ) ?>" rel="attachment">
								<?php echo esc_html( basename( $post->guid ) ) ?>
							</a>
						<?php endif; ?>

						<div class="entry-meta-box font-2 clearfix">
							<div class="entry-author-name">
								<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
									<?php esc_html_e( 'By ', 'notumn' );  the_author(); ?></a>
							</div>
							<div class="entry-social-links">
								<?php notumn_sharing_links( $post->ID ); ?>
							</div>
							<div class="entry-likes"><?php notumn_likes(); ?></div>
						</div><!-- .entry-meta -->

						<?php get_template_part( 'includes/templates/posts_pagination' ); ?>

						<?php comments_template( '', false ); ?>

					</article>

					<?php endwhile;
					endif; ?>

				</div>
			</div><!-- .column -->

			<?php get_sidebar( 'archive' ); ?>

		</div><!-- .row -->
	</div><!-- .container -->

<?php
get_footer();
