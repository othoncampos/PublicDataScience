<?php
/**
 * Content Grid.
 *
 * @package notumn
 * @since 1.0
 */

if ( is_archive() || is_search() ) {
	$notumn_layout = get_theme_mod( 'notumn_archive_layout', 'list_sidebar' );
} else {
	$notumn_layout = get_theme_mod( 'notumn_homepage_layout', 'fullwidth' );
}
$notumn_entry_class = 'standard';
?>
<div class="<?php echo ($notumn_layout === 'grid')? 'col-md-4 col-sm-6' : 'col-sm-6'; ?>">
	<article id="post-<?php the_ID(); ?>" <?php post_class( array( 'grid-post' ) ); ?>>
<?php

		if ( has_post_format( 'gallery' ) ) :

		$notumn_gallery_images = get_post_meta( $post->ID, '_format_gallery_images', true );

		if ( $notumn_gallery_images ) : ?>
		<div class="gallery-entry owl-carousel <?php echo sanitize_html_class( $notumn_entry_class ); ?>">

			<?php foreach ( $notumn_gallery_images as $gallery_image ) : ?>
				<div class="entry-image ratio-fit">
					<div class="holder-ratio-wrap ratio-fit">
						<?php notumn_gallery_thumbnail( $gallery_image, 'notumn_grid_thumb', 330,
							'(max-width: 767px) 100vw, %1$s' ); ?>
					</div>
				</div><!-- .entry-image -->
			<?php endforeach; ?>

		</div><!-- .gallery-entry -->
		<?php endif;

		elseif ( has_post_format( 'video' ) ) : ?>

		<div class="entry-image js-height-inner-iframe"><?php
			echo notumn_oembed_video( $post->ID ); ?></div>

		<?php elseif ( has_post_format( 'audio' ) ) : ?>

		<div class="entry-image js-height-inner-iframe"><?php
			echo notumn_oembed_audio( $post->ID ); ?></div>

		<?php else : ?>

		<?php if ( has_post_thumbnail() ) : ?>
		<div class="entry-image <?php echo sanitize_html_class( $notumn_entry_class ); ?>">
			<div class="holder-ratio-wrap ratio-fit">
				<a href="<?php the_permalink(); ?>"><?php notumn_thumbnail( $post->ID, 'notumn_grid_thumb', 330,
						'(max-width: 767px) 100vw, %1$s' ); ?></a>
			</div>
		</div><!-- .entry-image -->
		<?php endif;

		endif; ?>

		<div class="entry-header">
			<div class="entry-category font-2">
				<?php the_category( '' ); ?>
			</div>
			<h2 class="entry-title font-2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		</div>

		<div class="entry-content">
			<?php the_excerpt(); ?>
		</div>

		<div class="entry-meta clearfix font-2">
			<div class="left">
				<div class="entry-date">
					<span class="date published"><?php
						$notumn_post_title = get_the_title();
						if ( ! is_single() && empty( $notumn_post_title ) ) : ?>
							<a href="<?php the_permalink() ?>"><?php the_time( get_option( 'date_format' ) ); ?></a>
						<?php else :
							the_time( get_option( 'date_format' ) );
						endif; ?>
					</span>
                    <span class="date updated hidden"><?php the_modified_date( get_option( 'date_format' ) ); ?></span>
				</div>
                <span class="entry-author-name vcard author post-author hidden fn"><span class="fn"><?php the_author(); ?></span></span>
			</div>
			<div class="right">
				<?php if ( is_sticky() && is_home() && ! is_paged() ) : ?>
					<div class="entry-sticky">
						<i class="fa fa-thumb-tack"></i> <?php esc_html_e( 'Sticky', 'notumn' ); ?>
					</div>
				<?php endif; ?>
				<div class="entry-comments">
					<?php if ( defined( 'DISQUS_DOMAIN' ) ) : ?>
						<a class="disqus-link" href="<?php echo esc_url( get_the_permalink() . '#disqus_thread' ); ?>"></a>
					<?php else : ?>
						<a href="<?php echo esc_url( get_comments_link() ); ?>"><i class="fa fa-comments-o"></i> <?php comments_number( 0, 1, '%' ); ?></a>
					<?php endif; ?>
				</div>
				<div class="entry-likes"><?php notumn_likes(); ?></div>
			</div>
		</div>
	</article>
</div>
