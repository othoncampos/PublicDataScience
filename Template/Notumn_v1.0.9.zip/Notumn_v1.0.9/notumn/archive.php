<?php
/**
 * Archives Template.
 *
 * @package notumn
 * @since 1.0
 */

$notumn_archive_layout  = get_theme_mod( 'notumn_archive_layout', 'list_sidebar' );
$notumn_archive_sidebar = ( preg_match( '/sidebar/', $notumn_archive_layout ) ) ? true : false;
$notumn_archive_layout  = explode( '_', $notumn_archive_layout );
$notumn_archive_layout  = $notumn_archive_layout[0];
$notumn_container_lg    = array( 'list', 'fullwidth', 'grid' );
$notumn_author_fname    = get_the_author_meta( 'first_name' );
$notumn_author_lname    = get_the_author_meta( 'last_name' );

if ( empty( $notumn_author_fname ) && empty( $notumn_author_lname ) ) {
	$notumn_author_name = get_the_author();
} else {
	$notumn_author_name = "$notumn_author_fname $notumn_author_lname";
}

get_header();

if ( in_array( $notumn_archive_layout, $notumn_container_lg, true ) ) : ?>
	<div class="container container-lg">
<?php else : ?>
	<div class="container">
<?php endif; ?>

		<div class="row">

			<?php if ( $notumn_archive_layout === 'grid' || $notumn_archive_sidebar ) : ?>
			<div class="col-md-12">
			<?php elseif ( $notumn_archive_layout === 'fullwidth' ) : ?>
			<div class="col-md-10 col-md-push-1">
			<?php elseif ( $notumn_archive_layout === 'full' ) : ?>
			<div class="col-md-8 col-md-push-2">
			<?php endif; ?>

			<div class="archive-box font-2">

				<?php if ( is_author() ) : ?>
					<div class="sub-heading"><?php esc_html_e( 'All Posts By', 'notumn' ); ?></div>
					<h1 class="heading"><?php echo esc_html( $notumn_author_name ); ?> </h1>

				<?php elseif ( is_day() ) : ?>

					<div class="sub-heading"><?php esc_html_e( 'Daily Archives', 'notumn' ); ?></div>
					<h1 class="heading"><?php echo esc_html( get_the_date() ); ?></h1>

				<?php elseif ( is_month() ) : ?>

					<div class="sub-heading"><?php esc_html_e( 'Monthly Archives', 'notumn' ); ?></div>
					<h1 class="heading"><?php echo esc_html( get_the_date( 'F Y' ) ); ?></h1>

				<?php elseif ( is_year() ) : ?>

					<div class="sub-heading"><?php esc_html_e( 'Yearly Archives', 'notumn' ); ?></div>
					<h1 class="heading"><?php echo esc_html( get_the_date( 'Y' ) ); ?></h1>

				<?php elseif ( is_category() ) : ?>

					<div class="sub-heading"><?php esc_html_e( 'Browsing Category', 'notumn' ); ?></div>
					<h1 class="heading"><?php single_cat_title( '', true ); ?></h1>

					<?php
					$notumn_category_description = category_description();
					if ( ! empty( $notumn_category_description ) ) : ?>
						<div class="description font-3"><?php echo wp_kses_post( $notumn_category_description ); ?></div>
					<?php endif; ?>

				<?php elseif ( is_tag() ) : ?>

					<div class="sub-heading"><?php esc_html_e( 'Browsing Tag', 'notumn' ); ?></div>
					<h1 class="heading"><?php single_tag_title( '', true ); ?></h1>

				<?php endif; ?>

				</div>
			</div><!-- .column -->
		</div><!-- .row -->

		<div class="row">

		<?php if ( $notumn_archive_layout === 'grid' && ! $notumn_archive_sidebar ) : ?>
		<div class="col-md-12">
		<?php elseif ( $notumn_archive_layout === 'fullwidth' ) : ?>
		<div class="col-md-10 col-md-push-1">
		<?php else : ?>
		<div class="col-md-8 <?php echo sanitize_html_class( ($notumn_archive_sidebar)? 'posts-column' : 'col-md-push-2' ); ?>">
		<?php endif; ?>

		<div class="posts-container relative">

			<?php if ( $notumn_archive_layout === 'grid' ) : ?>
			<div class="row">
				<?php endif; ?>

				<?php if ( have_posts() ) : while ( have_posts() ) : the_post() ?>
					<?php get_template_part( 'content', $notumn_archive_layout ); ?>
				<?php endwhile; endif; ?>

				<?php if ( $notumn_archive_layout === 'grid' ) : ?>
			</div>
			<?php endif; ?>

		</div><!-- .posts-container -->

		<?php get_template_part( 'includes/templates/blog_pagination' ); ?>

		</div><!-- .posts-column -->

		<?php if ( $notumn_archive_sidebar ) :
			get_sidebar( 'archive' );
		endif; ?>

		</div><!-- .row -->
	</div><!-- .container -->

<?php
get_footer();
