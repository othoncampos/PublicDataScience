<?php
/**
 * Content Page.
 *
 * @package notumn
 * @since 1.0
 */

// Get Notumn Image Size: Full (no crop) or Standard (cropped).
$notumn_img_size = get_post_meta( $post->ID, '_notumn-img-size', true );
if ( empty( $notumn_img_size ) ) {
	$notumn_img_size = 'standard';
}

$notumn_page_layout = get_post_meta( $post->ID, '_notumn-page-layout', true );
if ( empty( $notumn_page_layout ) ) {
	$notumn_page_layout = 'medium_sidebar';
}

$notumn_page_sidebar = ( preg_match( '/sidebar/', $notumn_page_layout ) ) ? true : false;
$notumn_container_lg = array( 'fullwidth' );

// Find actual img size basing on page layout and $notumn_img_size.
if ( $notumn_img_size === 'standard' ) {

	$notumn_img_size = in_array( $notumn_page_layout, array(
		'full',
		'full_sidebar',
	), true ) ? 'notumn_featured_thumb' : 'notumn_notumn_lg_featured_thumb';

} elseif ( $notumn_img_size === 'full' ) {

	$notumn_img_size = in_array( $notumn_page_layout, array(
		'full',
		'full_sidebar',
	), true ) ? 'notumn_full_thumb' : 'notumn_lg_full_thumb';

}

if ( get_theme_mod( 'notumn_lg_enable', true ) ) :
	wp_add_inline_script( 'notumn-js', notumn_light_gallery_images( $post->ID ) );
endif;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( array( 'relative' ) ); ?>>

	<header class="entry-header">
		<h1 class="entry-title font-2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
        <?php if( get_theme_mod( 'notumn_page_publish_date', true ) ) : ?>
		<div class="entry-date font-3"
		     title="<?php the_time( 'Y-m-d H:i:s' ); ?>"><?php esc_html_e( 'Posted on', 'notumn' ); ?>
			<span class="date published"><?php the_time( get_option( 'date_format' ) ); ?></span>
			<span class="date updated hidden"><?php the_modified_date( get_option( 'date_format' ) ); ?></span>
		</div>
        <?php endif; ?>
	</header><!-- .entry header -->

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="entry-image">
			<a href="<?php echo esc_url( wp_get_attachment_url( get_post_thumbnail_id() ) ); ?>">
				<?php notumn_entry_image( $post->ID, $notumn_img_size ); ?>
			</a>
		</div><!-- .entry-image -->
	<?php endif; ?>

	<div class="entry-content">
		<?php the_content(); ?>
		<?php wp_link_pages( array( 'next_or_number' => 'number', 'previouspagelink' => ' &laquo; ', 'nextpagelink' => ' &raquo;' ) ); ?>
	</div><!-- .entry-content -->

	<?php if( is_front_page() ) {
            if ( get_theme_mod( 'notumn_static_show_metabar', true ) ) {
                get_template_part( 'includes/templates/entry_metabox' );
            }
        } else {
            get_template_part( 'includes/templates/entry_metabox' );
        }
	?>

	<?php comments_template( '', false ); ?>

</article>
