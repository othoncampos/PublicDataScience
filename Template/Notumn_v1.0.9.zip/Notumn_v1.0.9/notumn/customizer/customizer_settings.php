<?php
/**
 * Customizer Settigns.
 *
 * @package notumn
 * @since 1.0
 */

function notumn_register_theme_customizer( $wp_customize ) {

	/**
	 * Panels & Sections
	 */

	// General Settigns Section.
	$wp_customize->add_section( 'general_settings_section', array(
			'title'    => esc_html__( 'General Settings', 'notumn' ),
			'priority' => 1,
		)
	);

	// Blog Settings Section.
	$wp_customize->add_section( 'blog_settings_section', array(
			'title'       => esc_html__( 'Blog Settings', 'notumn' ),
			'description' => esc_html__( 'You need to set the Front page displays Your latest posts in settings > reading.', 'notumn' ),
			'priority'    => 2,
		)
	);

	// Featured Carousel Settings Section.
	$wp_customize->add_section( 'featured_carousel_settings_section', array(
			'title'       => esc_html__( 'Featured Carousel', 'notumn' ),
			'description' => esc_html__( 'Featued Carousel can either display the featured posts or popular posts on blog page.', 'notumn' ),
			'priority'    => 3,
		)
	);

	// Typography.
	$wp_customize->add_section( 'typography_settings_section', array(
			'title'    => esc_html__( 'Typography', 'notumn' ),
			'priority' => 4,
		)
	);

	// Footer Settings Section.
	$wp_customize->add_section( 'footer_settings_section', array(
			'title'    => esc_html__( 'Footer Settings', 'notumn' ),
			'priority' => 5,
		)
	);

	// Social Links Section.
	$wp_customize->add_section( 'social_links_section', array(
			'title'       => esc_html__( 'Social Links', 'notumn' ),
			'description' => esc_html__( 'You can either provide your username or full link to your profile. Eg: envato or http://facebook.com/envato', 'notumn' ),
			'priority'    => 6,
		)
	);

	// Light Gallery Settings Section.
	$wp_customize->add_section( 'light_gallery_settings_section', array(
			'title'       => esc_html__( 'Light Gallery', 'notumn' ),
			'description' => esc_html__( 'Customize the look and functionality of light gallery.', 'notumn' ),
			'priority'    => 7,
		)
	);

	// Custom Code Section.
	$wp_customize->add_section( 'custom_code_section', array(
			'title'       => esc_html__( 'Custom Code Areas', 'notumn' ),
			'description' => esc_html__( 'Use these custom code areas to insert Shortcodes, HTML etc on homepage.', 'notumn' ),
			'priority'    => 8,
		)
	);

	// General Color Settings.
	$wp_customize->add_section( 'general_color_settings_section', array(
			'title'    => esc_html__( 'Color Settings: General', 'notumn' ),
			'priority' => 9,
		)
	);

	// Lite Theme Color Settings.
	$wp_customize->add_panel( 'lite_theme_color_settings_panel', array(
		'title'       => esc_html__( 'Color Settings: Lite Theme', 'notumn' ),
		'description' => esc_html__( 'To apply these colors to the theme, please enable custom styles in customizer Color Settings: General > Enable Custom styles.', 'notumn' ),
		'priority'    => 10,
	) );

	// Lite theme Color Settings section.
	$wp_customize->add_section( 'lt_navigation_color_settings_section', array(
			'title'    => esc_html__( 'Navigation Color Settings', 'notumn' ),
			'panel'    => 'lite_theme_color_settings_panel',
			'priority' => 1,
		)
	);

	// Lite theme Color Settings section.
	$wp_customize->add_section( 'lt_sidebar_color_settings_section', array(
			'title'    => esc_html__( 'Sidebar Color Settings', 'notumn' ),
			'panel'    => 'lite_theme_color_settings_panel',
			'priority' => 2,
		)
	);

	// Lite theme Color Settings section.
	$wp_customize->add_section( 'lt_footer_color_settings_section', array(
			'title'    => esc_html__( 'Footer Color Settings', 'notumn' ),
			'panel'    => 'lite_theme_color_settings_panel',
			'priority' => 3,
		)
	);

	// Dark Theme Color Settings.
	$wp_customize->add_panel( 'dark_theme_color_settings_panel', array(
		'description' => esc_html__( 'To apply these colors to the theme, please enable custom styles in customizer Color Settings: General > Enable Custom styles.', 'notumn' ),
		'title'       => esc_html__( 'Color Settings: Dark Theme', 'notumn' ),
		'priority'    => 11,
	) );

	// Dark theme Color Settings section.
	$wp_customize->add_section( 'dt_navigation_color_settings_section', array(
			'title'    => esc_html__( 'Navigation Color Settings', 'notumn' ),
			'panel'    => 'dark_theme_color_settings_panel',
			'priority' => 1,
		)
	);

	// Dark theme Color Settings section.
	$wp_customize->add_section( 'dt_sidebar_color_settings_section', array(
			'title'    => esc_html__( 'Sidebar Color Settings', 'notumn' ),
			'panel'    => 'dark_theme_color_settings_panel',
			'priority' => 2,
		)
	);

	// Dark theme Color Settings section.
	$wp_customize->add_section( 'dt_footer_color_settings_section', array(
			'title'    => esc_html__( 'Footer Color Settings', 'notumn' ),
			'panel'    => 'dark_theme_color_settings_panel',
			'priority' => 3,
		)
	);

	// Custom styles section.
	$wp_customize->add_section( 'custom_css_section', array(
			'title'    => esc_html__( 'Custom CSS', 'notumn' ),
			'priority' => 12,
		)
	);

	// Google Analytics section.
	$wp_customize->add_section( 'google_analytics', array(
			'title'    => esc_html__( 'Google Analytics', 'notumn' ),
			'priority' => 13,
		)
	);

	/**
	 * Settings and Controls
	 */

	// Logo Settings.
	$wp_customize->add_setting( 'notumn_header_logo', array(
		'default'           => get_template_directory_uri() . '/img/logo-dark.png',
		'sanitize_callback' => 'notumn_sanitize_url',
		'transport' => 'postMessage'
	) );

	$wp_customize->add_control(
		new WP_Customize_Image_Control( $wp_customize,
			'upload_header_logo', array(
				'label'    => esc_html__( 'Logo:', 'notumn' ),
				'section'  => 'general_settings_section',
				'settings' => 'notumn_header_logo',
				'context'  => 'custom_logo',
			)
		)
	);

	$wp_customize->selective_refresh->add_partial( 'notumn_header_logo', array(
		'selector' => '.header-logo a',
		'render_callback' => function(){
			?>
			<img src="<?php echo esc_url( get_theme_mod( 'notumn_header_logo', get_template_directory_uri() . '/img/logo-dark.png' ) ); ?>"
			     alt="<?php bloginfo( 'name' ); ?>"
			     width="<?php echo esc_attr( get_theme_mod( 'notumn_header_logo_size', 280 ) ); ?>">
			<?php
		}
	) );

	// Retina Logo Settings.
	$wp_customize->add_setting( 'notumn_header_logo_retina', array(
		'default'           => get_template_directory_uri() . '/img/logo-dark@2x.png',
		'sanitize_callback' => 'notumn_sanitize_url',
	) );

	$wp_customize->add_control(
		new WP_Customize_Image_Control( $wp_customize,
			'upload_footer_logo_retina', array(
				'label'       => esc_html__( 'Retina Logo @2x:', 'notumn' ),
				'description' => esc_html__( 'Retina logo must have same name as the normal logo but it should end with @2x E.g. logo-dark@2x.png', 'notumn' ),
				'section'     => 'general_settings_section',
				'settings'    => 'notumn_header_logo_retina',
				'context'     => 'custom_logo',
			)
		)
	);

	// Header Logo Size Setting.
	$wp_customize->add_setting( 'notumn_header_logo_size', array(
		'default'           => 280,
		'sanitize_callback' => 'notumn_sanitize_number',
		'transport' => 'postMessage'
	) );

	$wp_customize->add_control( 'notumn_header_logo_size', array(
		'label'       => esc_html__( 'Header Logo Size:', 'notumn' ),
		'section'     => 'general_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 10,
			'max'   => 700,
			'style' => 'width: 60px',
		),
	) );

	// Header Logo Size Setting.
	$wp_customize->add_setting( 'notumn_header_logo_size_mobile', array(
		'default'           => 240,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_header_logo_size_mobile', array(
		'label'       => esc_html__( 'Header Logo Size for Mobile:', 'notumn' ),
		'section'     => 'general_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 10,
			'max'   => 700,
			'style' => 'width: 60px',
		),
	) );

	// Header Padding Top Setting.
	$wp_customize->add_setting( 'notumn_header_padding_top', array(
		'default'           => 54,
		'sanitize_callback' => 'notumn_sanitize_number',
		'transport' => 'postMessage'
	) );

	$wp_customize->add_control( 'notumn_header_padding_top', array(
		'label'       => esc_html__( 'Header White Space above logo', 'notumn' ),
		'section'     => 'general_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 10,
			'max'   => 200,
			'style' => 'width: 60px',
		),
	) );

	// Header Padding Bottom Setting.
	$wp_customize->add_setting( 'notumn_header_padding_bottom', array(
		'default'           => 54,
		'sanitize_callback' => 'notumn_sanitize_number',
		'transport' => 'postMessage'
	) );

	$wp_customize->add_control( 'notumn_header_padding_bottom', array(
		'label'       => esc_html__( 'Header White Space below logo', 'notumn' ),
		'section'     => 'general_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 10,
			'max'   => 200,
			'style' => 'width: 60px',
		),
	) );


	// Footer Logo Settings.
	$wp_customize->add_setting( 'notumn_footer_logo', array(
		'default'           => get_template_directory_uri() . '/img/logo-dark.png',
		'sanitize_callback' => 'notumn_sanitize_url',
		'transport' => 'postMessage'
	) );

	$wp_customize->add_control(
		new WP_Customize_Image_Control( $wp_customize,
			'upload_footer_logo', array(
				'label'    => esc_html__( 'Footer Logo:', 'notumn' ),
				'section'  => 'footer_settings_section',
				'settings' => 'notumn_footer_logo',
				'context'  => 'custom_logo',
			)
		)
	);

	$wp_customize->selective_refresh->add_partial( 'notumn_footer_logo', array(
		'selector' => '.footer .footer-logo a',
		'render_callback' => function(){
			?>
			<img src="<?php echo esc_url( get_theme_mod( 'notumn_footer_logo', get_template_directory_uri() . '/img/logo-dark.png' ) ); ?>"
			     alt="<?php bloginfo( 'name' ); ?>"
			     width="<?php echo esc_attr( get_theme_mod( 'notumn_footer_logo_size', 280 ) ); ?>" >
			<?php
		}
	) );

	// Retina Footer Logo Settings.
	$wp_customize->add_setting( 'notumn_footer_logo_retina', array(
		'default'           => get_template_directory_uri() . '/img/logo-dark@2x.png',
		'sanitize_callback' => 'notumn_sanitize_url',
	) );

	$wp_customize->add_control(
		new WP_Customize_Image_Control( $wp_customize,
			'upload_header_logo_retina', array(
				'label'       => esc_html__( 'Retina Footer Logo @2x:', 'notumn' ),
				'description' => esc_html__( 'Retina logo must have same name as the normal logo but it should end with @2x E.g. logo-dark@2x.png', 'notumn' ),
				'section'     => 'footer_settings_section',
				'settings'    => 'notumn_footer_logo_retina',
				'context'     => 'custom_logo',
			)
		)
	);

	// Header Logo Size Setting.
	$wp_customize->add_setting( 'notumn_footer_logo_size', array(
		'default'           => 280,
		'sanitize_callback' => 'notumn_sanitize_number',
		'transport' => 'postMessage'
	) );

	$wp_customize->add_control( 'notumn_footer_logo_size', array(
		'label'       => esc_html__( 'Footer Logo Size:', 'notumn' ),
		'section'     => 'footer_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 10,
			'max'   => 700,
			'style' => 'width: 60px',
		),
	) );

	// Footer Logo Size Setting for Mobile.
	$wp_customize->add_setting( 'notumn_footer_logo_size_mobile', array(
		'default'           => 250,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_footer_logo_size_mobile', array(
		'label'       => esc_html__( 'Footer Logo Size for Mobile:', 'notumn' ),
		'section'     => 'footer_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 10,
			'max'   => 700,
			'style' => 'width: 60px',
		),
	) );

	// Footer Logo Size Setting for Mobile.
	$wp_customize->add_setting( 'notumn_footer_logo_size_small_mobile', array(
		'default'           => 190,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_footer_logo_size_small_mobile', array(
		'label'       => esc_html__( 'Footer Logo Size for Small Mobile:', 'notumn' ),
		'section'     => 'footer_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 10,
			'max'   => 700,
			'style' => 'width: 60px',
		),
	) );

	// Footer left anchor text.
	$wp_customize->add_setting( 'notumn_footer_anchor_text', array(
		'default'           => esc_html( '© Copyright Notumn ' . date('Y') ),
        'sanitize_callback' => 'notumn_sanitize_custom_code'
	) );

	$wp_customize->add_control( 'notumn_footer_anchor_text', array(
		'label'   => esc_html__( 'Footer Left Anchor Text:', 'notumn' ),
		'section' => 'footer_settings_section',
		'type'    => 'text',
	) );

	// Footer left anchor URL.
	$wp_customize->add_setting( 'notumn_footer_anchor_url', array(
		'default'           => 'http://decaxstudios.com/notumn/',
		'sanitize_callback' => 'notumn_sanitize_url',
	) );

	$wp_customize->add_control( 'notumn_footer_anchor_url', array(
		'label'   => esc_html__( 'Footer Left Anchor URL:', 'notumn' ),
		'section' => 'footer_settings_section',
		'type'    => 'text',
	) );

	// Footer right text.
	$wp_customize->add_setting( 'notumn_footer_right_text', array(
		'default'           => 'All Rights Reserved.',
		'sanitize_callback' => 'notumn_sanitize_custom_code'
	) );

	$wp_customize->add_control( 'notumn_footer_right_text', array(
		'label'   => esc_html__( 'Footer Right Text:', 'notumn' ),
		'section' => 'footer_settings_section',
		'type'    => 'text',
	) );

	// Theme Style.
	$wp_customize->add_setting( 'notumn_theme_style', array(
		'default'           => 'lite-theme',
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( 'lite-theme', 'dark-theme' ), true ) ) {
				$val = 'lite-theme';
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'theme_style', array(
				'label'    => esc_html__( 'Theme Style:', 'notumn' ),
				'section'  => 'general_settings_section',
				'settings' => 'notumn_theme_style',
				'type'     => 'radio',
				'choices'  => array(
					'lite-theme' => esc_html__( 'Lite Theme', 'notumn' ),
					'dark-theme' => esc_html__( 'Dark Theme', 'notumn' ),
				),
			)
		)
	);

	// Preloader Setting.
	$wp_customize->add_setting( 'notumn_preloader', array(
		'default'           => 'spinner',
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( 'spinner', 'logo_blink', 'Off' ), true ) ) {
				$val = 'spinner';
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'preloader_setting', array(
				'label'    => esc_html__( 'Page Preloader:', 'notumn' ),
				'section'  => 'general_settings_section',
				'settings' => 'notumn_preloader',
				'type'     => 'select',
				'choices'  => array(
					'spinner'    => esc_html__( 'Spinner', 'notumn' ),
					'logo_blink' => esc_html__( 'Logo Blink', 'notumn' ),
					'Off'        => esc_html__( 'Off', 'notumn' ),
				),
			)
		)
	);

	// Home Page layout Setting.
	$wp_customize->add_setting( 'notumn_homepage_layout', array(
		'default'           => 'fullwidth',
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( 'full', 'full_sidebar', 'fullwidth', 'list_sidebar', 'grid', 'grid_sidebar' ), true ) ) {
				$val = 'fullwidth';
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new Notumn_Layout_Control( $wp_customize,
			'homepage_layout', array(
				'label'    => esc_html__( 'Homepage Layout:', 'notumn' ),
				'section'  => 'blog_settings_section',
				'settings' => 'notumn_homepage_layout',
				'type'     => 'select',
				'choices'  => array(
					'full'         => array(
						'label' => esc_html__( 'Full Posts', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-1.png',
					),
					'full_sidebar' => array(
						'label' => esc_html__( 'Full Posts + Sidebar', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-2.png',
					),
					'fullwidth'    => array(
						'label' => esc_html__( 'Full Width Posts', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-3.png',
					),
					'list_sidebar' => array(
						'label' => esc_html__( 'Posts List + Sidebar', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-4.png',
					),
					'grid'         => array(
						'label' => esc_html__( 'Grid Posts', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-5.png',
					),
					'grid_sidebar' => array(
						'label' => esc_html__( 'Grid Posts + Sidebar', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-6.png',
					),
				),
			)
		)
	);

	// Archive Page Layout Setting.
	$wp_customize->add_setting( 'notumn_archive_layout', array(
		'default'           => 'list_sidebar',
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( 'full', 'full_sidebar', 'fullwidth', 'list_sidebar', 'grid', 'grid_sidebar' ), true ) ) {
				$val = 'list_sidebar';
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new Notumn_Layout_Control( $wp_customize,
			'archive_layout', array(
				'label'    => esc_html__( 'Archive Layout:', 'notumn' ),
				'section'  => 'blog_settings_section',
				'settings' => 'notumn_archive_layout',
				'type'     => 'select',
				'choices'  => array(
					'full'         => array(
						'label' => esc_html__( 'Full Posts', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-1.png',
					),
					'full_sidebar' => array(
						'label' => esc_html__( 'Full Posts + Sidebar', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-2.png',
					),
					'fullwidth'    => array(
						'label' => esc_html__( 'Full Width Posts', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-3.png',
					),
					'list_sidebar' => array(
						'label' => esc_html__( 'Posts List + Sidebar', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-4.png',
					),
					'grid'         => array(
						'label' => esc_html__( 'Grid Posts', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-5.png',
					),
					'grid_sidebar' => array(
						'label' => esc_html__( 'Grid Posts + Sidebar', 'notumn' ),
						'icon'  => get_template_directory_uri() . '/customizer/images/layout-6.png',
					),
				),
			)
		)
	);

	// Author Box Setting.
	$wp_customize->add_setting( 'notumn_author_box', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'author_box', array(
				'label'    => esc_html__( 'Show Author Box on Posts', 'notumn' ),
				'section'  => 'blog_settings_section',
				'settings' => 'notumn_author_box',
				'type'     => 'checkbox',
			)
		)
	);

	// Related Posts Setting.
	$wp_customize->add_setting( 'notumn_related_posts', array(
		'default' => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'related_posts', array(
				'label'    => esc_html__( 'Show Related Posts on Posts', 'notumn' ),
				'section'  => 'blog_settings_section',
				'settings' => 'notumn_related_posts',
				'type'     => 'checkbox',
			)
		)
	);

	// Page Title Box Setting.
	$wp_customize->add_setting( 'notumn_page_title_box', array(
		'default'           => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'page_title_box', array(
				'label'    => esc_html__( 'Hide Page Title Box on pages', 'notumn' ),
				'section'  => 'blog_settings_section',
				'settings' => 'notumn_page_title_box',
				'type'     => 'checkbox',
			)
		)
	);

	// Page Publish Date Setting.
	$wp_customize->add_setting( 'notumn_page_publish_date', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'page_publish_date', array(
				'label'    => esc_html__( 'Show Publish date on pages', 'notumn' ),
				'section'  => 'blog_settings_section',
				'settings' => 'notumn_page_publish_date',
				'type'     => 'checkbox',
			)
		)
	);

	// Numbered Pagination Setting.
	$wp_customize->add_setting( 'notumn_numbered_pagination', array(
		'default'           => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'numbered_pagination', array(
				'label'    => esc_html__( 'Enable Numbered Pagination', 'notumn' ),
				'section'  => 'blog_settings_section',
				'settings' => 'notumn_numbered_pagination',
				'type'     => 'checkbox',
			)
		)
	);

	// Home page section title.
	$wp_customize->add_setting( 'notumn_section_title', array(
		'default' => esc_html__( 'Latest Posts', 'notumn' ),
		'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( 'notumn_section_title', array(
		'label'       => 'Section Title:',
		'description' => esc_html__( 'This title will be displayed on list and grid layouts of homepage.', 'notumn' ),
		'section'     => 'blog_settings_section',
		'type'        => 'text',
	) );

	$notumn_default_fonts = array(
		'notumn_font_1' => "'Open Sans', sans-serif;",
		'notumn_font_2' => "'Montserrat', sans-serif;",
		'notumn_font_3' => "'Crimson Text', serif;",
	);

	// Typography font 2 settings.
	$wp_customize->add_setting( 'notumn_font_2', array(
		'default'           => $notumn_default_fonts['notumn_font_2'],
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( "'Montserrat', sans-serif;", "'Roboto Slab', serif;", "'Droid Serif', serif", 'other' ), true ) ) {
				$val = "'Montserrat', sans-serif;";
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'font_2', array(
				'label'       => esc_html__( 'Headings Font:', 'notumn' ),
				'description' => esc_html__( 'This font will be used on Titles and other main areas.', 'notumn' ),
				'section'     => 'typography_settings_section',
				'settings'    => 'notumn_font_2',
				'type'        => 'select',
				'choices'     => array(
					"'Montserrat', sans-serif;" => 'Montserrat (Recommended)',
					"'Roboto Slab', serif;"     => 'Roboto Slab',
					"'Droid Serif', serif"      => 'Droid Serif',
					'other'                     => 'Other',
				),
			)
		)
	);

	// Typography font 2 settings.
	$wp_customize->add_setting( 'notumn_font_2_other', array(
		'default'           => $notumn_default_fonts['notumn_font_2'],
		'sanitize_callback' => function ( $val ) {
			return $val;
		},
	) );

	$wp_customize->add_control( 'notumn_font_2_other', array(
		'label'       => 'Other Headings Font:',
		'description' => sprintf( esc_html__( 'To use another google font, enter the code given at %s E.g.: font-family: \'Open Sans\', sans-serif;', 'notumn' ),
		'<a href="' . esc_url( 'http://www.google.com/fonts' ) . '" target="_blank">' . esc_html( 'http://www.google.com/fonts' ) . '</a><br>' ),
		'section'     => 'typography_settings_section',
		'type'        => 'text',
	) );

	// Typography font 1 settings.
	$wp_customize->add_setting( 'notumn_font_1', array(
		'default'           => $notumn_default_fonts['notumn_font_1'],
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( "'Open Sans', sans-serif;", "'Crimson Text', serif;", "'Droid Serif', serif", "'Roboto Slab', serif;", 'other' ), true ) ) {
				$val = "'Open Sans', sans-serif;";
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'font_1', array(
				'label'       => esc_html__( 'Body Font:', 'notumn' ),
				'description' => esc_html__( 'This font will be used on body text.', 'notumn' ),
				'section'     => 'typography_settings_section',
				'settings'    => 'notumn_font_1',
				'type'        => 'select',
				'choices'     => array(
					"'Open Sans', sans-serif;" => 'Open Sans (Recommended)',
					"'Crimson Text', serif;"   => 'Crimson Text',
					"'Droid Serif', serif"     => 'Droid Serif',
					"'Roboto Slab', serif;"    => 'Roboto Slab',
					'other'                    => 'Other',
				),
			)
		)
	);

	// Typography font 1 settings.
	$wp_customize->add_setting( 'notumn_font_1_other', array(
		'default'           => $notumn_default_fonts['notumn_font_1'],
		'sanitize_callback' => function ( $val ) {
			return $val;
		},
	) );

	$wp_customize->add_control( 'notumn_font_1_other', array(
		'label'       => 'Other Body Font:',
		'description' => sprintf( esc_html__( 'To use another google font, enter the code given at %s E.g.: font-family: \'Open Sans\', sans-serif;', 'notumn' ),
		'<a href="' . esc_url( 'http://www.google.com/fonts' ) . '" target="_blank">' . esc_html( 'http://www.google.com/fonts' ) . '</a><br>' ),
		'section'     => 'typography_settings_section',
		'type'        => 'text',
	) );

	// Typography font 3 settings.
	$wp_customize->add_setting( 'notumn_font_3', array(
		'default'           => $notumn_default_fonts['notumn_font_3'],
		'sanitize_callback' => function ( $val ) {
			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'font_3', array(
				'label'       => esc_html__( 'Additional Font:', 'notumn' ),
				'description' => esc_html__( 'This font will be used on descriptions and sub headings.', 'notumn' ),
				'section'     => 'typography_settings_section',
				'settings'    => 'notumn_font_3',
				'type'        => 'select',
				'choices'     => array(
					"'Crimson Text', serif;"    => 'Crimson Text (Recommended)',
					"'Droid Serif', serif"      => 'Droid Serif',
					"'Roboto Slab', serif;"     => 'Roboto Slab',
					"'Open Sans', sans-serif;"  => 'Open Sans',
					"'Montserrat', sans-serif;" => 'Montserrat',
					'other'                     => 'Other',
				),
			)
		)
	);

	// Typography font 3 settings.
	$wp_customize->add_setting( 'notumn_font_3_other', array(
		'default'           => $notumn_default_fonts['notumn_font_3'],
		'sanitize_callback' => function ( $val ) {
			return $val;
		},
	) );

	$wp_customize->add_control( 'notumn_font_3_other', array(
		'label'       => 'Other Additional Font:',
		'description' => sprintf( esc_html__( 'To use another google font, enter the code given at %s E.g.: font-family: \'Open Sans\', sans-serif;', 'notumn' ),
		'<a href="' . esc_url( 'http://www.google.com/fonts' ) . '" target="_blank">' . esc_html( 'http://www.google.com/fonts' ) . '</a><br>' ),
		'section'     => 'typography_settings_section',
		'type'        => 'text',
	) );

	// Font charset setting.
	$wp_customize->add_setting( 'notumn_charset_latin', array(
		'default'           => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'charset_latin', array(
				'label'    => esc_html__( 'Include Latin Extended Charset (Needed in some languages)', 'notumn' ),
				'section'  => 'typography_settings_section',
				'settings' => 'notumn_charset_latin',
				'type'     => 'checkbox',
			)
		)
	);

	// Font charset setting.
	$wp_customize->add_setting( 'notumn_charset_cyrillic', array(
		'default'           => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'charset_cyrillic', array(
				'label'    => esc_html__( 'Include Cyrillic Extended Charset (Needed in some languages)', 'notumn' ),
				'section'  => 'typography_settings_section',
				'settings' => 'notumn_charset_cyrillic',
				'type'     => 'checkbox',
			)
		)
	);

	// Font charset setting.
	$wp_customize->add_setting( 'notumn_charset_greek', array(
		'default' => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'charset_greek', array(
				'label'    => esc_html__( 'Include Greek Charset', 'notumn' ),
				'section'  => 'typography_settings_section',
				'settings' => 'notumn_charset_greek',
				'type'     => 'checkbox',
			)
		)
	);

	// Homepage Top custom code Setting.
	$wp_customize->add_setting( 'notumn_top_custom_code', array(
		'default' => '',
		'sanitize_callback' => 'notumn_sanitize_custom_code',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'top_custom_code', array(
				'label'    => esc_html__( 'Top Homepage custom code area:', 'notumn' ),
				'section'  => 'custom_code_section',
				'settings' => 'notumn_top_custom_code',
				'type'     => 'textarea',
			)
		)
	);

	// Custom Code Setting.
	$wp_customize->add_setting( 'notumn_top_custom_code_paged', array(
		'default' => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'top_custom_code_paged', array(
				'label'    => esc_html__( 'Show above code only on first page', 'notumn' ),
				'section'  => 'custom_code_section',
				'settings' => 'notumn_top_custom_code_paged',
				'type'     => 'checkbox',
			)
		)
	);

	// Homepage bottom custom code Setting.
	$wp_customize->add_setting( 'notumn_bottom_custom_code', array(
		'default' => '',
		'sanitize_callback' => 'notumn_sanitize_custom_code',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'bottom_custom_code', array(
				'label'    => esc_html__( 'Bottom Homepage custom code area:', 'notumn' ),
				'section'  => 'custom_code_section',
				'settings' => 'notumn_bottom_custom_code',
				'type'     => 'textarea',
			)
		)
	);

	// Custom Code Setting.
	$wp_customize->add_setting( 'notumn_bottom_custom_code_paged', array(
		'default' => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'bottom_custom_code_paged', array(
				'label'    => esc_html__( 'Show above code only on first page', 'notumn' ),
				'section'  => 'custom_code_section',
				'settings' => 'notumn_bottom_custom_code_paged',
				'type'     => 'checkbox',
			)
		)
	);

	// Featured Carousel Setting.
	$wp_customize->add_setting( 'notumn_featured_carousel', array(
		'default' => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'featured_carousel', array(
				'label'    => esc_html__( 'Enable Featured Carousel', 'notumn' ),
				'section'  => 'featured_carousel_settings_section',
				'settings' => 'notumn_featured_carousel',
				'type' => 'checkbox',
			)
		)
	);

	// Featured Carousel style Setting.
	$wp_customize->add_setting( 'notumn_carousel_style', array(
		'default'           => 'style-1',
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( 'style-1', 'style-2' ), true ) ) {
				$val = 'style-1';
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'carousel_style', array(
				'label'       => esc_html__( 'Featured Carousel Style:', 'notumn' ),
				'section'     => 'featured_carousel_settings_section',
				'settings'    => 'notumn_carousel_style',
				'description' => esc_html__( 'Note: carousel style 2 will only work with the homepage layouts that contain sidebar.', 'notumn' ),
				'type'        => 'select',
				'choices'     => array(
					'style-1' => esc_html__( 'Style 1', 'notumn' ),
					'style-2' => esc_html__( 'Style 2', 'notumn' ),
				),
			)
		)
	);

	// Featured Carousel Type Setting.
	$wp_customize->add_setting( 'notumn_carousel_type', array(
		'default'           => 'featured',
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( 'featured', 'popular-comments', 'popular-likes' ), true ) ) {
				$val = 'featured';
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'carousel_type', array(
				'label'    => esc_html__( 'Featured Carousel displays:', 'notumn' ),
				'section'  => 'featured_carousel_settings_section',
				'settings' => 'notumn_carousel_type',
				'type'     => 'select',
				'choices'  => array(
					'featured'         => esc_html__( 'Featured Posts', 'notumn' ),
					'popular-comments' => esc_html__( 'Popular Posts by Comments', 'notumn' ),
					'popular-likes'    => esc_html__( 'Popular Posts by Likes', 'notumn' ),
				),
			)
		)
	);

	// Featured Carousel Items Setting.
	$wp_customize->add_setting( 'notumn_max_carousel_items', array(
		'default'           => 5,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_max_carousel_items', array(
		'label'       => esc_html__( 'Max no.of posts to display:', 'notumn' ),
		'section'     => 'featured_carousel_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 3,
			'max'   => 8,
			'style' => 'width: 60px',
		),
	) );

	// Featured Carousel Setting.
	$wp_customize->add_setting( 'notumn_carousel_autoplay', array(
		'default' => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'carousel_autoplay', array(
				'label'    => esc_html__( 'Enable Carousel Auto Play', 'notumn' ),
				'section'  => 'featured_carousel_settings_section',
				'settings' => 'notumn_carousel_autoplay',
				'type'     => 'checkbox',
			)
		)
	);

	// Featured Carousel Setting.
	$wp_customize->add_setting( 'notumn_carousel_autoplay_speed', array(
		'default'           => 3000,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_carousel_autoplay_speed', array(
		'label'       => esc_html__( 'Carousel Auto Play Speed (ms):', 'notumn' ),
		'section'     => 'featured_carousel_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 1800,
			'max'   => 6000,
			'style' => 'width: 80px',
		),
	) );

	// Featured Carousel Setting.
	$wp_customize->add_setting( 'notumn_feat_carousel_paged', array(
		'default'           => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'feat_carousel_paged', array(
				'label'    => esc_html__( 'Show Carousel only on first page', 'notumn' ),
				'section'  => 'featured_carousel_settings_section',
				'settings' => 'notumn_feat_carousel_paged',
				'type'     => 'checkbox',
			)
		)
	);

	// Get Social Links data.
	$social_links = notumn_social_links();

	// Social links Settings.
	foreach ( $social_links as $social_link => $social_link_meta ) {
		$wp_customize->add_setting( $social_link, array(
			'default'           => '',
			'sanitize_callback' => 'notumn_sanitize_social_links',

		) );

		$wp_customize->add_control( $social_link, array(
			'label'   => $social_link_meta['label'],
			'section' => 'social_links_section',
			'type'    => 'text',
		) );
	}

	// Light Gallery setting.
	$wp_customize->add_setting( 'notumn_lg_enable', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_enable', array(
				'label'    => esc_html__( 'Enable Light Gallery', 'notumn' ),
				'section'  => 'light_gallery_settings_section',
				'settings' => 'notumn_lg_enable',
				'type'     => 'checkbox',
			)
		)
	);

	$img_sizes = notumn_available_img_sizes();
	unset( $img_sizes['wysija-newsletters-max'] );
	$lg_size_select = array();

	foreach ( $img_sizes as $img_size_str => $img_size ) {
		$height = ( $img_size['height'] ) ? $img_size['height'] : esc_html__( 'Max (no crop)', 'notumn' );
		if ( $img_size_str === 'full' ) {
			$lg_size_select[ $img_size_str ] = "$img_size_str - " . esc_html__( 'Original Size', 'notumn' );
		} else {
			$lg_size_select[ $img_size_str ] = "$img_size_str - {$img_size['width']}x{$height}";
		}
	}

	// Light Gallery Image Size setting.
	$wp_customize->add_setting( 'notumn_lg_size', array(
		'default'           => 'notumn_featured_thumb',
		'sanitize_callback' => function ( $val ) use ( $lg_size_select ) {
			if ( ! key_exists( $val, $lg_size_select ) ) {
				$val = 'notumn_featured_thumb';
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_size', array(
				'label'       => esc_html__( 'Image Size:', 'notumn' ),
				'section'     => 'light_gallery_settings_section',
				'settings'    => 'notumn_lg_size',
				'type'        => 'select',
				'choices'     => $lg_size_select,
			)
		)
	);

	$lg_transitions = array(
		'lg-slide', 'lg-fade', 'lg-zoom-in', 'lg-zoom-in-big', 'lg-zoom-out',
		'lg-zoom-out-big', 'lg-zoom-out-in', 'lg-zoom-in-out', 'lg-soft-zoom', 'lg-scale-up', 'lg-slide-circular',
		'lg-slide-circular-vertical', 'lg-slide-vertical', 'lg-slide-vertical-growth', 'lg-slide-skew-only',
		'lg-slide-skew-only-rev', 'lg-slide-skew-only-y', 'lg-slide-skew-only-y-rev', 'lg-slide-skew',
		'lg-slide-skew-rev', 'lg-slide-skew-cross', 'lg-slide-skew-cross-rev', 'lg-slide-skew-ver',
		'lg-slide-skew-ver-rev', 'lg-slide-skew-ver-cross', 'lg-slide-skew-ver-cross-rev', 'lg-lollipop',
		'lg-lollipop-rev', 'lg-rotate', 'lg-rotate-rev', 'lg-tube',
	);

	// Light Gallery Transition setting.
	$wp_customize->add_setting( 'notumn_lg_transition', array(
		'default'           => 'lg-slide',
		'sanitize_callback' => function ( $val ) use ( $lg_transitions ) {
			if ( ! in_array( $val, $lg_transitions, true ) ) {
				$val = 'lg-slide';
			}
			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_transition', array(
				'label'    => esc_html__( 'Gallery Transition:', 'notumn' ),
				'section'  => 'light_gallery_settings_section',
				'settings' => 'notumn_lg_transition',
				'type'     => 'select',
				'choices'  => array_combine( array_keys(
				array_flip( $lg_transitions ) ), $lg_transitions ),
			)
		)
	);

	// Light Gallery Transition Duration.
	$wp_customize->add_setting( 'notumn_lg_trans_duration', array(
		'default'           => 700,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_lg_trans_duration', array(
		'label'       => esc_html__( 'Transition Duraion:', 'notumn' ),
		'description' => esc_html__( 'Transition duration (in ms)', 'notumn' ),
		'section'     => 'light_gallery_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 100,
			'max'   => 3000,
			'style' => 'width: 70px',
		),
	) );

	// Light Gallery Title setting.
	$wp_customize->add_setting( 'notumn_lg_title', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_title', array(
				'label'    => esc_html__( 'Display Image Title', 'notumn' ),
				'section'  => 'light_gallery_settings_section',
				'settings' => 'notumn_lg_title',
				'type'     => 'checkbox',
			)
		)
	);

	// Light Gallery Caption setting.
	$wp_customize->add_setting( 'notumn_lg_caption', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_caption', array(
				'label'    => esc_html__( 'Display Image Caption', 'notumn' ),
				'section'  => 'light_gallery_settings_section',
				'settings' => 'notumn_lg_caption',
				'type'     => 'checkbox',
			)
		)
	);

	// Light Gallery Download Btn setting.
	$wp_customize->add_setting( 'notumn_lg_down_btn', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_down_btn', array(
				'label'    => esc_html__( 'Show Download Button', 'notumn' ),
				'section'  => 'light_gallery_settings_section',
				'settings' => 'notumn_lg_down_btn',
				'type'     => 'checkbox',
			)
		)
	);

	// Light Gallery Download Btn setting.
	$wp_customize->add_setting( 'notumn_lg_thumbnails', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_thumbnails', array(
				'label'    => esc_html__( 'Show Gallery Thumbnails', 'notumn' ),
				'section'  => 'light_gallery_settings_section',
				'settings' => 'notumn_lg_thumbnails',
				'type'     => 'checkbox',
			)
		)
	);

	// Light Gallery Autoplay setting.
	$wp_customize->add_setting( 'notumn_lg_autoplay', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_autoplay', array(
				'label'    => esc_html__( 'Enable Autoplay', 'notumn' ),
				'section'  => 'light_gallery_settings_section',
				'settings' => 'notumn_lg_autoplay',
				'type'     => 'checkbox',
			)
		)
	);

	// Light Gallery Autoplay Pause Setting.
	$wp_customize->add_setting( 'notumn_lg_pause', array(
		'default'           => 4500,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_lg_pause', array(
		'label'       => esc_html__( 'Autoplay Pause:', 'notumn' ),
		'description' => esc_html__( 'The time (in ms) between each auto transition.', 'notumn' ),
		'section'     => 'light_gallery_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 1000,
			'max'   => 8000,
			'style' => 'width: 70px',
		),
	) );

	// Light Gallery Transparency Setting.
	$wp_customize->add_setting( 'notumn_lg_transparency', array(
		'default'           => 70,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_lg_transparency', array(
		'label'       => esc_html__( 'Backgroud Transparency:', 'notumn' ),
		'section'     => 'light_gallery_settings_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 0,
			'max'   => 100,
			'style' => 'width: 60px',
		),
	) );

	// Light Gallery Autoplay setting.
	$wp_customize->add_setting( 'notumn_lg_zoom', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_zoom', array(
				'label'    => esc_html__( 'Enable zoom option', 'notumn' ),
				'section'  => 'light_gallery_settings_section',
				'settings' => 'notumn_lg_zoom',
				'type'     => 'checkbox',
			)
		)
	);

	// Light Gallery Actual Size setting.
	$wp_customize->add_setting( 'notumn_lg_actualsize', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'lg_actualsize', array(
				'label'    => esc_html__( 'Enable actual pixel icon', 'notumn' ),
				'section'  => 'light_gallery_settings_section',
				'settings' => 'notumn_lg_actualsize',
				'type'     => 'checkbox',
			)
		)
	);

	// Enable Custom Styles setting.
	$wp_customize->add_setting( 'notumn_custom_styles', array(
		'default'           => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'custom_styles', array(
				'label'    => esc_html__( 'Enable Custom Colors', 'notumn' ),
				'section'  => 'general_color_settings_section',
				'settings' => 'notumn_custom_styles',
				'type'     => 'checkbox',
			)
		)
	);

	/**
	 * Color controls & Settings
	 */
	$notumn_color_sections = array(
		'general_color_settings_section'       => array(
			'body_text_color'    => array( 'label' => esc_html__( 'Body Text Color', 'notumn' ), 'default' => '#727272' ),
			'headings_color'     => array( 'label' => esc_html__( 'Headings Color', 'notumn' ), 'default' => '#1d1d1d' ),
			'anchor_color'       => array( 'label' => esc_html__( 'Anchor Color', 'notumn' ), 'default' => '#848484' ),
			'anchor_hover_color' => array( 'label' => esc_html__( 'Anchor Hover Color', 'notumn' ), 'default' => '#1d1d1d' ),
			'accent_color'       => array( 'label' => esc_html__( 'Accent Color', 'notumn' ), 'default' => '#d0b48b' ),
			'post_titles_color'  => array( 'label' => esc_html__( 'Post Titles Color', 'notumn' ), 'default' => '#1d1d1d' ),
			'post_meta_color'  => array( 'label' => esc_html__( 'Post Meta Color', 'notumn' ), 'default' => '#9e9e9e' ),
		),
		'lt_navigation_color_settings_section' => array(
			'lt_nav_txt_color'       => array( 'label' => esc_html__( 'Text Color', 'notumn' ), 'default' => '#1d1d1d' ),
			'lt_nav_txt_hover_color' => array( 'label' => esc_html__( 'Text Hover Color', 'notumn' ), 'default' => '#d0b48b' ),
			'lt_nav_bg_color'        => array( 'label' => esc_html__( 'Background Color', 'notumn' ), 'default' => '#ffffff' ),
			'lt_nav_bd_color'        => array( 'label' => esc_html__( 'Border Color', 'notumn' ), 'default' => '#dadada' ),
			'lt_nav_seach_bg'        => array( 'label' => esc_html__( 'Search Field BG Color', 'notumn' ), 'default' => '#ffffff' ),
		),
		'lt_sidebar_color_settings_section'    => array(
			'lt_wg_h2_color'    => array( 'label' => esc_html__( 'Widget Title Color', 'notumn' ), 'default' => '#727272' ),
			'lt_wg_h2_bg'       => array( 'label' => esc_html__( 'Widget Title BG color', 'notumn' ), 'default' => '#ffffff' ),
			'lt_wg_h2_bd_color' => array( 'label' => esc_html__( 'Widget Title Border color', 'notumn' ), 'default' => '#dadada' ),
			'lt_wg_txt_color'   => array( 'label' => esc_html__( 'Widget Text color', 'notumn' ), 'default' => '#1d1d1d' ),
			'lt_wg_txt_hover'   => array( 'label' => esc_html__( 'Widget Text Hover color', 'notumn' ), 'default' => '#d0b48b' ),
			'lt_wg_list_sep'    => array( 'label' => esc_html__( 'Widget Separator color', 'notumn' ), 'default' => '#eeeeee' ),
			'lt_wg_meta_color'    => array( 'label' => esc_html__( 'Widget Meta color', 'notumn' ), 'default' => '#d0b48b' ),
		),
		'lt_footer_color_settings_section'     => array(
			'lt_ft_bg_color'       => array( 'label' => esc_html__( 'Background Color', 'notumn' ), 'default' => '#ffffff' ),
			'lt_ft_bd_color'       => array( 'label' => esc_html__( 'Borders Color', 'notumn' ), 'default' => '#dadada' ),
			'lt_ft_txt_color'      => array( 'label' => esc_html__( 'Text & Icons Color', 'notumn' ), 'default' => '#727272' ),
			'lt_ft_txt_hover'      => array( 'label' => esc_html__( 'Text & Icons Hover Color', 'notumn' ), 'default' => '#d0b48b' ),
			'lt_ft_wg_h2_color'    => array( 'label' => esc_html__( 'Widget Title Color', 'notumn' ), 'default' => '#727272' ),
			'lt_ft_wg_h2_bg'       => array( 'label' => esc_html__( 'Widget Title BG color', 'notumn' ), 'default' => '#ffffff' ),
			'lt_ft_wg_h2_bd_color' => array( 'label' => esc_html__( 'Widget Title Border color', 'notumn' ), 'default' => '#dadada' ),
			'lt_ft_wg_txt_color'   => array( 'label' => esc_html__( 'Widget Text color', 'notumn' ), 'default' => '#1d1d1d' ),
			'lt_ft_wg_txt_hover'   => array( 'label' => esc_html__( 'Widget Text Hover color', 'notumn' ), 'default' => '#d0b48b' ),
			'lt_ft_wg_list_sep'    => array( 'label' => esc_html__( 'Widget Separator color', 'notumn' ), 'default' => '#eeeeee' ),
			'lt_ft_wg_meta_color'  => array( 'label' => esc_html__( 'Widget Meta color', 'notumn' ), 'default' => '#d0b48b' ),
		),
		'dt_navigation_color_settings_section' => array(
			'dt_nav_txt_color'       => array( 'label' => esc_html__( 'Text Color', 'notumn' ), 'default' => '#ffffff' ),
			'dt_nav_txt_hover_color' => array( 'label' => esc_html__( 'Text Hover Color', 'notumn' ), 'default' => '#d0b48b' ),
			'dt_nav_bg_color'        => array( 'label' => esc_html__( 'Background Color', 'notumn' ), 'default' => '#1d1d1d' ),
			'dt_nav_bd_color'        => array( 'label' => esc_html__( 'Border Color', 'notumn' ), 'default' => '#303030' ),
			'dt_nav_seach_bg'        => array( 'label' => esc_html__( 'Search Field BG Color', 'notumn' ), 'default' => '#1d1d1d' ),
		),
		'dt_sidebar_color_settings_section'    => array(
			'dt_wg_h2_color'    => array( 'label' => esc_html__( 'Widget Title Color', 'notumn' ), 'default' => '#dadada' ),
			'dt_wg_h2_bg'       => array( 'label' => esc_html__( 'Widget Title BG color', 'notumn' ), 'default' => '#1d1d1d' ),
			'dt_wg_h2_bd_color' => array( 'label' => esc_html__( 'Widget Title Border color', 'notumn' ), 'default' => '#303030' ),
			'dt_wg_txt_color'   => array( 'label' => esc_html__( 'Widget Text color', 'notumn' ), 'default' => '#1d1d1d' ),
			'dt_wg_txt_hover'   => array( 'label' => esc_html__( 'Widget Text Hover color', 'notumn' ), 'default' => '#d0b48b' ),
			'dt_wg_list_sep'    => array( 'label' => esc_html__( 'Widget Separator color', 'notumn' ), 'default' => '#eeeeee' ),
			'dt_wg_meta_color'  => array( 'label' => esc_html__( 'Widget Meta color', 'notumn' ), 'default' => '#d0b48b' ),
		),
		'dt_footer_color_settings_section'     => array(
			'dt_ft_bg_color'       => array( 'label' => esc_html__( 'Background Color', 'notumn' ), 'default' => '#1d1d1d' ),
			'dt_ft_bd_color'       => array( 'label' => esc_html__( 'Borders Color', 'notumn' ), 'default' => '#303030' ),
			'dt_ft_txt_color'      => array( 'label' => esc_html__( 'Text & Icons Color', 'notumn' ), 'default' => '#848484' ),
			'dt_ft_txt_hover'      => array( 'label' => esc_html__( 'Text & Icons Hover Color', 'notumn' ), 'default' => '#d0b48b' ),
			'dt_ft_wg_h2_color'    => array( 'label' => esc_html__( 'Widget Title Color', 'notumn' ), 'default' => '#dadada' ),
			'dt_ft_wg_h2_bg'       => array( 'label' => esc_html__( 'Widget Title BG color', 'notumn' ), 'default' => '#1d1d1d' ),
			'dt_ft_wg_h2_bd_color' => array( 'label' => esc_html__( 'Widget Title Border color', 'notumn' ), 'default' => '#303030' ),
			'dt_ft_wg_txt_color'   => array( 'label' => esc_html__( 'Widget Text color', 'notumn' ), 'default' => '#dadada' ),
			'dt_ft_wg_txt_hover'   => array( 'label' => esc_html__( 'Widget Text Hover color', 'notumn' ), 'default' => '#d0b48b' ),
			'dt_ft_wg_list_sep'    => array( 'label' => esc_html__( 'Widget Separator color', 'notumn' ), 'default' => '#303030' ),
			'dt_ft_wg_meta_color'  => array( 'label' => esc_html__( 'Widget Meta color', 'notumn' ), 'default' => '#d0b48b' ),
		),
	);

	foreach ( $notumn_color_sections as $notumn_color_section => $notumn_color_settings ) {

		foreach ( $notumn_color_settings as $color_setting_id => $color_setting ) {

			$wp_customize->add_setting( "notumn_{$color_setting_id}", array(
				'default'           => $color_setting['default'],
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			$wp_customize->add_control(
				new WP_Customize_Color_Control( $wp_customize, $color_setting_id, array(
						'label'    => $color_setting['label'],
						'section'  => $notumn_color_section,
						'settings' => "notumn_{$color_setting_id}",
					)
				)
			);
		}
	}

	// Custom Styles Settings.
	$wp_customize->add_setting( 'notumn_custom_css', array(
		'default'           => '',
		'sanitize_callback' => 'notumn_sanitize_custom_code',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'custom_css', array(
				'label'    => esc_html__( 'Custom CSS:', 'notumn' ),
				'section'  => 'custom_css_section',
				'settings' => 'notumn_custom_css',
				'type'     => 'textarea',
			)
		)
	);

	// Google Analytics Settings.
	$wp_customize->add_setting( 'notumn_google_analytics_id', array(
		'sanitize_callback' => 'sanitize_text_field',
	) );

	$wp_customize->add_control( 'notumn_google_analytics_id', array(
		'label'       => 'Google Analytics ID:',
		'description' => esc_html__( 'Enter your Google Analytics ID to enable website traffic reporting.', 'notumn' ),
		'section'     => 'google_analytics',
		'type'        => 'text',
		'input_attrs' => array(
			'placeholder' => 'UA-XXXXXX-XX',
		),
	) );

	// Static Front Page Settings Panel.
	$wp_customize->add_panel( 'static_page_settings_panel', array(
		'title'    => esc_html__( 'Static Front Page Settings', 'notumn' ),
		'priority' => 30,
	) );


	// Static Front Page Featured Carousel Section.
	$wp_customize->add_section( 'notumn_static_carousel_section', array(
			'title'    => esc_html__( 'Featured Carousel', 'notumn' ),
			'panel'    => 'static_page_settings_panel',
			'priority' => 1,
		)
	);

	// Static Front Page Custom Code Settings Section.
	$wp_customize->add_section( 'notumn_static_custom_code_section', array(
			'title'    => esc_html__( 'Custom Code Areas', 'notumn' ),
			'panel'    => 'static_page_settings_panel',
			'priority' => 2,
		)
	);

	// Static Front Page Miscellaneous Settings Section.
	$wp_customize->add_section( 'notumn_static_miscellaneous_section', array(
			'title'    => esc_html__( 'Miscellaneous Settings', 'notumn' ),
			'panel'    => 'static_page_settings_panel',
			'priority' => 3,
		)
	);

	// Static Front Page Featured Carousel Setting.
	$wp_customize->add_setting( 'notumn_static_featured_carousel', array(
		'default' => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'static_featured_carousel', array(
				'label'    => esc_html__( 'Enable Featured Carousel', 'notumn' ),
				'section'  => 'notumn_static_carousel_section',
				'settings' => 'notumn_static_featured_carousel',
				'type' => 'checkbox',
			)
		)
	);

	// Featured Carousel style Setting.
	$wp_customize->add_setting( 'notumn_static_carousel_style', array(
		'default'           => 'style-1',
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( 'style-1', 'style-2' ), true ) ) {
				$val = 'style-1';
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'static_carousel_style', array(
				'label'       => esc_html__( 'Featured Carousel Style:', 'notumn' ),
				'section'     => 'notumn_static_carousel_section',
				'settings'    => 'notumn_static_carousel_style',
				'description' => esc_html__( 'Note: carousel style 2 will only work with the page layouts "Medium Width + Sidebar" &  "Medium Width (No Sidebar)".', 'notumn' ),
				'type'        => 'select',
				'choices'     => array(
					'style-1' => esc_html__( 'Style 1', 'notumn' ),
					'style-2' => esc_html__( 'Style 2', 'notumn' ),
				),
			)
		)
	);

	// Featured Carousel Type Setting.
	$wp_customize->add_setting( 'notumn_static_carousel_type', array(
		'default'           => 'featured',
		'sanitize_callback' => function ( $val ) {
			if ( ! in_array( $val, array( 'featured', 'popular-comments', 'popular-likes' ), true ) ) {
				$val = 'featured';
			}

			return $val;
		},
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'static_carousel_type', array(
				'label'    => esc_html__( 'Featured Carousel displays:', 'notumn' ),
				'section'  => 'notumn_static_carousel_section',
				'settings' => 'notumn_static_carousel_type',
				'type'     => 'select',
				'choices'  => array(
					'featured'         => esc_html__( 'Featured Posts', 'notumn' ),
					'popular-comments' => esc_html__( 'Popular Posts by Comments', 'notumn' ),
					'popular-likes'    => esc_html__( 'Popular Posts by Likes', 'notumn' ),
				),
			)
		)
	);

	// Featured Carousel Items Setting.
	$wp_customize->add_setting( 'notumn_static_max_carousel_items', array(
		'default'           => 5,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_static_max_carousel_items', array(
		'label'       => esc_html__( 'Max no.of posts to display:', 'notumn' ),
		'section'     => 'notumn_static_carousel_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 3,
			'max'   => 8,
			'style' => 'width: 60px',
		),
	) );

	// Featured Carousel Setting.
	$wp_customize->add_setting( 'notumn_static_carousel_autoplay', array(
		'default' => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'static_carousel_autoplay', array(
				'label'    => esc_html__( 'Enable Carousel Auto Play', 'notumn' ),
				'section'  => 'notumn_static_carousel_section',
				'settings' => 'notumn_static_carousel_autoplay',
				'type'     => 'checkbox',
			)
		)
	);

	// Featured Carousel Setting.
	$wp_customize->add_setting( 'notumn_static_carousel_autoplay_speed', array(
		'default'           => 3000,
		'sanitize_callback' => 'notumn_sanitize_number',
	) );

	$wp_customize->add_control( 'notumn_static_carousel_autoplay_speed', array(
		'label'       => esc_html__( 'Carousel Auto Play Speed (ms):', 'notumn' ),
		'section'     => 'notumn_static_carousel_section',
		'type'        => 'number',
		'input_attrs' => array(
			'min'   => 1800,
			'max'   => 6000,
			'style' => 'width: 80px',
		),
	) );

	// Static Front Page top custom code Setting.
	$wp_customize->add_setting( 'notumn_static_top_custom_code', array(
		'default' => '',
		'sanitize_callback' => 'notumn_sanitize_custom_code',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'static_top_custom_code', array(
				'label'    => esc_html__( 'Top custom code area:', 'notumn' ),
				'section'  => 'notumn_static_custom_code_section',
				'settings' => 'notumn_static_top_custom_code',
				'type'     => 'textarea',
			)
		)
	);

	// Static Front Page bottom custom code setting.
	$wp_customize->add_setting( 'notumn_static_bottom_custom_code', array(
		'default' => '',
		'sanitize_callback' => 'notumn_sanitize_custom_code',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'static_bottom_custom_code', array(
				'label'    => esc_html__( 'Bottom custom code area:', 'notumn' ),
				'section'  => 'notumn_static_custom_code_section',
				'settings' => 'notumn_static_bottom_custom_code',
				'type'     => 'textarea',
			)
		)
	);

	// Static Front show meta bar setting.
	$wp_customize->add_setting( 'notumn_static_show_metabar', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'static_show_metabar', array(
				'label'    => esc_html__( 'Diaplay Metabar ( Author Name, Social Sharing Links & Likes bar ) on static front page.', 'notumn' ),
				'section'  => 'notumn_static_miscellaneous_section',
				'settings' => 'notumn_static_show_metabar',
				'type'     => 'checkbox',
			)
		)
	);

	// Static Front Page Title Box Setting.
	$wp_customize->add_setting( 'notumn_static_page_title_box', array(
		'default'           => false,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'static_page_title_box', array(
				'label'    => esc_html__( 'Hide Page Title Box on static front page.', 'notumn' ),
				'section'  => 'notumn_static_miscellaneous_section',
				'settings' => 'notumn_static_page_title_box',
				'type'     => 'checkbox',
			)
		)
	);

	// Static Front Page Publish Date Setting.
	$wp_customize->add_setting( 'notumn_static_page_publish_date', array(
		'default'           => true,
		'sanitize_callback' => 'notumn_sanitize_checkbox',
	) );

	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize,
			'static_page_publish_date', array(
				'label'    => esc_html__( 'Show Publish date on static front page.', 'notumn' ),
				'section'  => 'notumn_static_miscellaneous_section',
				'settings' => 'notumn_static_page_publish_date',
				'type'     => 'checkbox',
			)
		)
	);

	// Modify Default section priority.
	$wp_customize->get_section( 'title_tagline' )->priority = 1;

}
add_action( 'customize_register', 'notumn_register_theme_customizer' );

/**
 * Enqueue script for custom customize control.
 */
function notumn_customize_enqueue() {
	wp_enqueue_script( 'custom-customize', get_template_directory_uri() . '/customizer/js/custom.customize.js',
	array( 'jquery', 'customize-controls' ), false, true );
}

add_action( 'customize_controls_enqueue_scripts', 'notumn_customize_enqueue' );

function notumn_customizer_style() {
	wp_enqueue_style( 'customizer-css', get_template_directory_uri() . '/customizer/css/customizer.css' );
}

add_action( 'customize_controls_print_styles', 'notumn_customizer_style' );

function notumn_customizer_live_preview()
{
	wp_enqueue_script(
		'notumn-themecustomizer',
		get_template_directory_uri() . '/customizer/js/notumn-customizer.js',
		array( 'jquery', 'customize-preview' ),
		'',
		true
	);
}
add_action( 'customize_preview_init', 'notumn_customizer_live_preview' );

/**
 * Validators & Sanitizers
 */
function notumn_sanitize_social_links( $val ) {

	if ( ! filter_var( $val, FILTER_VALIDATE_URL ) ) {
		$val = sanitize_text_field( $val );
	}

	return $val;
}

function notumn_sanitize_checkbox( $val ) {
	return filter_var( $val, FILTER_VALIDATE_BOOLEAN );
}

function notumn_sanitize_custom_code( $code ) {
	return $code;
}

function notumn_sanitize_number( $val ) {
	return filter_var( $val, FILTER_SANITIZE_NUMBER_INT );
}

function notumn_sanitize_url( $val ) {

	if ( ! filter_var( trim( $val ), FILTER_VALIDATE_URL ) ) {
		$val = '#';
	}

	return $val;
}
