( function( $ ) {

    // Update the header logo width in real time...
    wp.customize( 'notumn_header_logo_size', function( value ) {
        value.bind( function( newval ) {
            $( '.header-logo img' ).width( newval );
        } );
    } );

    // Update the footer logo width in real time...
    wp.customize( 'notumn_footer_logo_size', function( value ) {
        value.bind( function( newval ) {
            $( '.footer .footer-logo img' ).width( newval );
        } );
    } );

    // Update the header padding top in real time...
    wp.customize( 'notumn_header_padding_top', function( value ) {
        value.bind( function( newval ) {
            $('.header-logo').css('padding-top', parseInt(newval));
        } );
    } );

    // Update the header padding top in real time...
    wp.customize( 'notumn_header_padding_bottom', function( value ) {
        value.bind( function( newval ) {
            $('.header-logo').css('padding-bottom', parseInt(newval));
        } );
    } );

} )( jQuery );
