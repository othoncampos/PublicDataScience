(function ($) {

    $(document).ready(function () {

        var font1Select = $('#customize-control-font_1').find('select'),
            font2Select = $('#customize-control-font_2').find('select'),
            font3Select = $('#customize-control-font_3').find('select');

        if( font1Select.val() != 'other' ){
            $('#customize-control-notumn_font_1_other').hide();
        }

        if( font2Select.val() != 'other' ){
            $('#customize-control-notumn_font_2_other').hide();
        }

        if( font3Select.val() != 'other' ){
            $('#customize-control-notumn_font_3_other').hide();
        }

        font1Select.on('change', function(){
            if( $(this).val() == 'other' ){
                $('#customize-control-notumn_font_1_other').slideDown();
            } else {
                $('#customize-control-notumn_font_1_other').slideUp();
            }
        });

        font2Select.on('change', function(){
            if( $(this).val() == 'other' ){
                $('#customize-control-notumn_font_2_other').slideDown();
            } else {
                $('#customize-control-notumn_font_2_other').slideUp();
            }
        });

        font3Select.on('change', function(){
            if( $(this).val() == 'other' ){
                $('#customize-control-notumn_font_3_other').slideDown();
            } else {
                $('#customize-control-notumn_font_3_other').slideUp();
            }
        });

        // Customizer Layout Select
        var layoutIconsControls = $('.layout-icons');

        layoutIconsControls.each(function(){
            var controlTitle = $(this).siblings('.customize-control-title');

            $(this).find('input').on('change', function () {
                controlTitle.find('small').text($(this).attr('title'));
            });
        });

    });

})(jQuery);
