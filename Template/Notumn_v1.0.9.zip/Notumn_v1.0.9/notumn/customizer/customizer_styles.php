<?php
/**
 * Customizer Styles.
 *
 * @package notumn
 * @since 1.0
 */
function notumn_customizer_css() {
	ob_start();
	?>
		.lg-backdrop {  background-color: <?php echo notumn_lg_bg_color(); ?>;  }

		body .header-logo img {
			width: <?php echo get_theme_mod( 'notumn_header_logo_size', 280 ), 'px;'; ?>
		}

		body .header-logo {
			padding: <?php echo get_theme_mod( 'notumn_header_padding_top', 54 ), 'px 0 ',
								get_theme_mod( 'notumn_header_padding_bottom', 52 ), 'px;' ; ?>
		}

		@media only screen and (max-width: 479px){
			.header-logo img {
				width: <?php echo get_theme_mod( 'notumn_header_logo_size_mobile', 240 ), 'px !important;'; ?>
			}
		}


		body .footer .footer-logo img {
			width: <?php echo get_theme_mod( 'notumn_footer_logo_size', 280 ), 'px;'; ?>
		}

		@media only screen and (max-width: 479px){
			.footer .footer-logo img {
				width: <?php echo get_theme_mod( 'notumn_footer_logo_size_mobile', 250 ), 'px !important;'; ?>
			}
		}

		@media only screen and (max-width: 320px) {
			.footer .footer-logo img {
				width: <?php echo get_theme_mod( 'notumn_footer_logo_size_small_mobile', 190 ), 'px !important;'; ?>
			}
		}

    <?php if( get_theme_mod( 'notumn_page_title_box', false ) ) : ?>
        .page .entry-header {
            display: none;
        }
        .page .entry-content {
            margin-top: 0;
        }
    <?php endif; ?>

    <?php if( get_theme_mod( 'notumn_static_page_title_box', false ) ) : ?>
        .page-template.page .entry-header {
            display: none;
        }
        .page-template.page .entry-content {
            margin-top: 0;
        }
    <?php endif; ?>

    <?php if( ! get_theme_mod( 'notumn_static_page_publish_date', true ) ) : ?>
        .page-template.page .entry-date {
            display: none;
        }
    <?php endif; ?>

	<?php if ( get_theme_mod( 'notumn_custom_styles', false ) ) : ?>
		body {  color: <?php echo notumn_sanitize_color( 'notumn_body_text_color' ); ?>;  }
		h1, h2, h3, h4, h5, h6 { color: <?php echo notumn_sanitize_color( 'notumn_headings_color' ); ?>; }
		a { color: <?php echo notumn_sanitize_color( 'notumn_anchor_color' ); ?>; }
		a:hover, a:active, a:hover { color: <?php echo notumn_sanitize_color( 'notumn_anchor_hover_color' ); ?>; }

		article .entry-category a, article .read-more a, .entry-meta-box a:hover, .entry-author .author-name a:hover,
		.entry-author .author-social-links a:hover, .entry-pagination a:hover, .post-list-item .entry-likes a:hover,
		article.grid-post .entry-meta a:hover, .archive-box > .sub-heading, .entry-comments a:hover, .comments-pagination a:hover,
		.notumn_latest_posts_widget .post-meta a, .dark-theme #footer .notumn_about_widget .about-social-links a:hover,
		.featured-item-foot .featured-item-category a, .featured-item-meta a:hover, .owl-theme .owl-controls .owl-page.active span {
			color: <?php echo notumn_sanitize_color( 'notumn_accent_color' ); ?>;
		}

        .page-loader .spinner {
            border-top-color: <?php echo notumn_sanitize_color( 'notumn_accent_color' ); ?>;
        }

		article .entry-title a,
		.featured-item .featured-item-title a {
			color: <?php echo notumn_sanitize_color( 'notumn_post_titles_color' ); ?>;
		}

		.post-list-item .entry-meta,
		.featured-item .featured-item-meta,
		.featured-item .featured-item-meta a,
		.post-list-item .entry-meta a {
			color: <?php echo notumn_sanitize_color( 'notumn_post_meta_color' ); ?>;
		}

		.featured-item-meta .item-comments:before, .featured-item-meta .item-date:before {
			background-color: <?php echo notumn_sanitize_color( 'notumn_post_meta_color' ); ?>;
		}

		<?php if ( get_theme_mod(  'notumn_theme_style', 'lite-theme' ) === 'lite-theme' ) : ?>

		.main-nav, .main-nav .left-nav li a, .right-nav li a {
			color: <?php echo notumn_sanitize_color( 'notumn_lt_nav_txt_color' ); ?>;
		}

		.main-nav, .mobile-on .left-nav, .main-nav .sub-mn, .mobile-on .left-nav li.js-opened > a:before {
			border-color: <?php echo notumn_sanitize_color( 'notumn_lt_nav_bd_color' ); ?>;
			background-color: <?php echo notumn_sanitize_color( 'notumn_lt_nav_bg_color' ); ?>;
		}

		.main-nav .left-nav li a:hover, .mobile-on .mobile-nav.active, .mobile-on .left-nav li.js-opened > a,
		.right-nav li a:hover {
			color: <?php echo notumn_sanitize_color( 'notumn_lt_nav_txt_hover_color' ); ?>;
		}

         body .main-nav .left-nav, body .main-nav .left-nav li.js-opened > a:before {
            border-color: <?php echo notumn_sanitize_color( 'notumn_lt_nav_bd_color' ); ?>;
            background-color: <?php echo notumn_sanitize_color( 'notumn_lt_nav_bg_color' ); ?>;
        }

        .main-nav .mobile-nav.active, .main-nav .left-nav li.js-opened > a {
            color: <?php echo notumn_sanitize_color( 'notumn_lt_nav_txt_hover_color' ); ?>;
        }

		.search-container input[type="text"]{
			background-color: <?php echo notumn_sanitize_color( 'notumn_lt_nav_seach_bg' ); ?>;
		}
		
		.widget .widget-title {
			color: <?php echo notumn_sanitize_color( 'notumn_lt_wg_h2_color' ); ?>;
			background-color: <?php echo notumn_sanitize_color( 'notumn_lt_wg_h2_bg' ); ?>;
			border-color: <?php echo notumn_sanitize_color( 'notumn_lt_wg_h2_bd_color' ); ?>;
		}
		
		.widget ul li {	border-color: <?php echo notumn_sanitize_color( 'notumn_lt_wg_list_sep' ); ?>; }
		.widget ul li a { color: <?php echo notumn_sanitize_color( 'notumn_lt_wg_txt_color' ); ?>; }
		.widget ul li a:hover {  color: <?php echo notumn_sanitize_color( 'notumn_lt_wg_txt_hover' ); ?>; }
		
		.footer {
			background-color: <?php echo notumn_sanitize_color( 'notumn_lt_ft_bg_color' ); ?>;
		}

		.footer .footer-box, .footer .footer-social-links a {
			border-color: <?php echo notumn_sanitize_color( 'notumn_lt_ft_bd_color' ); ?>;
		}

		.footer .footer-box, .footer .footer-box a, .footer .footer-text a, .footer .footer-rights {
			color: <?php echo notumn_sanitize_color( 'notumn_lt_ft_txt_color' ); ?>;
		}

		.footer .footer-social-links a:hover, .footer .footer-text a:hover {
			color: <?php echo notumn_sanitize_color( 'notumn_lt_ft_txt_hover' ); ?>;
			border-color: <?php echo notumn_sanitize_color( 'notumn_lt_ft_txt_hover' ); ?>;
		}

		.footer .widget .widget-title {
			color: <?php echo notumn_sanitize_color(  'notumn_lt_ft_wg_h2_color' ); ?>;
			background-color: <?php echo notumn_sanitize_color(  'notumn_lt_ft_wg_h2_bg' ); ?>;
			border-color: <?php echo notumn_sanitize_color(  'notumn_lt_ft_wg_h2_bd_color' ); ?>;
		}

		.footer .widget ul li {	border-color: <?php echo notumn_sanitize_color( 'notumn_lt_ft_wg_list_sep' ); ?>; }
		.footer .widget ul li a { color: <?php echo notumn_sanitize_color( 'notumn_lt_ft_wg_txt_color' ); ?>; }
		.footer .widget ul li a:hover {  color: <?php echo notumn_sanitize_color( 'notumn_lt_ft_wg_txt_hover' ); ?>; }

		.widget .post-meta,
		.widget .post-meta a,
		.widget .post-meta span {
			color: <?php echo notumn_sanitize_color(  'notumn_lt_wg_meta_color' ); ?>;
		}

		.footer .widget .post-meta,
		.footer .widget .post-meta a,
		.footer .widget .post-meta span {
			color: <?php echo notumn_sanitize_color(  'notumn_lt_ft_wg_meta_color' ); ?>;
		}

		<?php else : ?>

        .dark-theme .menu-item .fa-angle-down,
        .dark-theme .menu-item .fa-angle-up {
            color: <?php echo notumn_sanitize_color( 'notumn_accent_color' ); ?>;
        }

        .dark-theme .left-nav li a, .dark-theme .mobile-nav, .dark-theme .right-nav li a {
			color: <?php echo notumn_sanitize_color( 'notumn_dt_nav_txt_color' ); ?>;
		}

		.dark-theme .left-nav li a:hover, .dark-theme .right-nav li a:hover, .dark-theme .mobile-on .mobile-nav.active,
		.dark-theme .mobile-on .left-nav li.js-opened > a {
			color: <?php echo notumn_sanitize_color( 'notumn_dt_nav_txt_hover_color' ); ?>;
		}

		.dark-theme .main-nav, .dark-theme .main-nav .sub-mn, .dark-theme .mobile-on .left-nav,
		.dark-theme .mobile-on .left-nav li.js-opened > a:before {
			border-color: <?php echo notumn_sanitize_color( 'notumn_dt_nav_bd_color' ); ?>;
			background-color: <?php echo notumn_sanitize_color( 'notumn_dt_nav_bg_color' ); ?>;
		}

        .dark-theme .main-nav .mobile-nav.active,
        .dark-theme .main-nav .left-nav li.js-opened > a {
            color: <?php echo notumn_sanitize_color( 'notumn_dt_nav_txt_hover_color' ); ?>;
        }

        .dark-theme .main-nav .left-nav,
        .dark-theme .main-nav .left-nav li.js-opened > a:before {
            border-color: <?php echo notumn_sanitize_color( 'notumn_dt_nav_bd_color' ); ?>;
            background-color: <?php echo notumn_sanitize_color( 'notumn_dt_nav_bg_color' ); ?>;
        }

		.dark-theme .search-container input[type="text"] {
			background-color: <?php echo notumn_sanitize_color( 'notumn_dt_nav_seach_bg' ); ?>;
		}

		.dark-theme .widget .widget-title {
			color: <?php echo notumn_sanitize_color( 'notumn_dt_wg_h2_color' ); ?>;
			background-color: <?php echo notumn_sanitize_color( 'notumn_dt_wg_h2_bg' ); ?>;
			border-color: <?php echo notumn_sanitize_color( 'notumn_dt_wg_h2_bd_color' ); ?>;
		}

		.dark-theme .widget ul li {	border-color: <?php echo notumn_sanitize_color( 'notumn_dt_wg_list_sep' ); ?>; }
		.dark-theme .widget ul li a { color: <?php echo notumn_sanitize_color( 'notumn_dt_wg_txt_color' ); ?>; }
		.dark-theme .widget ul li a:hover {  color: <?php echo notumn_sanitize_color( 'notumn_dt_wg_txt_hover' ); ?>; }

		.dark-theme .footer {
			background-color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_bg_color' ); ?>;
		}

		.dark-theme .footer .footer-box, .dark-theme .footer .footer-social-links a {
			border-color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_bd_color' ); ?>;
		}

		.dark-theme .footer .footer-box, .dark-theme .footer .footer-box a, .dark-theme .footer .footer-text a,
		.dark-theme .footer .footer-rights {
			color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_txt_color' ); ?>;
		}

		.dark-theme .footer .footer-social-links a:hover, .dark-theme .footer .footer-text a:hover {
			color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_txt_hover' ); ?>;
			border-color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_txt_hover' ); ?>;
		}

		.dark-theme .footer .widget .widget-title {
			color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_wg_h2_color' ); ?>;
			background-color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_wg_h2_bg' ); ?>;
			border-color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_wg_h2_bd_color' ); ?>;
		}

		.dark-theme .footer .widget ul li {	border-color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_wg_list_sep' ); ?>; }
		.dark-theme .footer .widget ul li a { color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_wg_txt_color' ); ?>; }
		.dark-theme .footer .widget ul li a:hover {  color: <?php echo notumn_sanitize_color( 'notumn_dt_ft_wg_txt_hover' ); ?>; }

		.dark-theme .widget .post-meta,
		.dark-theme .widget .post-meta a,
		.dark-theme .widget .post-meta span {
			color: <?php echo notumn_sanitize_color(  'notumn_dt_wg_meta_color' ); ?>;
		}

		.dark-theme .footer .widget .post-meta,
		.dark-theme .footer .widget .post-meta a,
		.dark-theme .footer .widget .post-meta span {
			color: <?php echo notumn_sanitize_color(  'notumn_dt_ft_wg_meta_color' ); ?>;
		}

		<?php endif; ?>
		<?php endif; ?>
	<?php
	return ob_get_clean();
}

add_action( 'wp_enqueue_scripts', function () {

	wp_add_inline_style( 'notumn', notumn_customizer_css() );

	$custom_css = get_theme_mod( 'notumn_custom_css' );

	if ( ! empty( $custom_css ) ) {
		wp_add_inline_style( 'notumn', $custom_css );
	}
}, 99 );

/**
 * Notumn hex color sanitizer
 *
 * @param string $mod_name Theme modification name.
 * @return string|void
 */
function notumn_sanitize_color( $mod_name ) {
	return sanitize_hex_color( get_theme_mod( $mod_name ) );
}

function notumn_lg_bg_color() {
	$lg_transparency = (integer) get_theme_mod( 'notumn_lg_transparency', '70' );
	$lg_transparency = ( $lg_transparency > 100 ) ? 1 : $lg_transparency / 100;

	return "rgba(0,0,0,{$lg_transparency})";
}