<?php
/**
 * Notumn Customizer Custom controls.
 *
 * @package notumn
 * @since 1.0
 */
function notumn_custom_controls() {

	class Notumn_Layout_Control extends WP_Customize_Control {
		public $type = 'layout_select';

		public function render_content() {
			if ( empty( $this->choices ) ) {
				return;
			}

			$name         = '_customize-radio-' . $this->id;
			$active_label = $this->choices[ $this->value() ]['label'];

			if ( ! empty( $this->label ) ) : ?>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?> <small><?php echo esc_html( $active_label ); ?></small></span>
			<?php endif;
			if ( ! empty( $this->description ) ) : ?>
				<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php endif;

			?>
			<div class="layout-icons">
				<?php foreach ( $this->choices as $value => $option ) : ?>
					<input id="<?php echo esc_attr( "{$this->id}-{$value}" ); ?>" type="radio" value="<?php echo esc_attr( $value ); ?>"
					       name="<?php echo esc_attr( $name ); ?>" style="display: none;" <?php $this->link(); checked( $this->value(), $value ); ?>
					       title="<?php echo esc_attr( $option['label'] ); ?>" />
					<label for="<?php echo esc_attr( "{$this->id}-{$value}" ); ?>" class="layout-icon" title="<?php echo esc_attr( $option['label'] ); ?>">
						<img src="<?php echo esc_url( $option['icon'] ); ?>" alt="icon">
					</label>
				<?php endforeach; ?>
			</div>
			<?php
		}
	}
}

add_action( 'customize_register', 'notumn_custom_controls' );
