<?php
/**
 * Template for displaying comments.
 *
 * @package notumn
 * @since 1.0
 */

if ( is_singular() && comments_open() ) :

	$notumn_cmt_args = array(
		'walker'       => new Notumn_Walker_Comment(),
		'max_depth'    => 3,
		'callback'     => 'notumn_comments',
		'end-callback' => 'notumn_end_comments',
		'reply_text'   => wp_kses_post( sprintf( '<i class="fa fa-comment"></i> %s', __( 'Reply', 'notumn' ) ) ),
		'style'        => 'ul',
		'avatar_size'  => 100,
		'type'         => 'all',
	);

?>
<div class="entry-comments" id="comments">

	<h4 class="entry-post-title font-2">
		<?php comments_number( esc_html__( 'No Comments', 'notumn' ), esc_html__( '1 Comment', 'notumn' ), wp_kses_post( __( 'Comments', 'notumn' ) . ' <span>(%)</span>' ) ); ?>
	</h4>

	<div class="comments">
		<ul class="comment-list clearlist">
			<?php wp_list_comments( $notumn_cmt_args ); ?>
		</ul><!-- .comment-list -->
	</div><!-- .comments -->

	<div class="comments-pagination">
		<?php paginate_comments_links( array( 'prev_text' => '&laquo;', 'next_text' => '&raquo;' ) ); ?>
	</div>

	<?php
	$notumn_commenter = wp_get_current_commenter();
	$notumn_req       = get_option( 'require_name_email' );
	$notumn_aria_req  = ( $notumn_req ? " aria-required='true'" : '' );
	wp_enqueue_script( 'comment-reply' );

	$notumn_comment_fields = array(
		'author' => '<div class="row"><div class="col-md-6"><input required type="text" class="form-control" name="author" placeholder="'. esc_attr__( 'Name *', 'notumn' ) .'" '
		            . $notumn_aria_req . ' value="' . esc_attr( $notumn_commenter['comment_author'] ) . '" /></div>',

		'email' => '<div class="col-md-6"><input type="email" class="form-control" name="email" placeholder="'. esc_attr__( 'Email *', 'notumn' ) .'" '
		           . $notumn_aria_req . ' value="' . esc_attr( $notumn_commenter['comment_author_email'] ) . '" required="required"></div></div>',

		'url' => '<input type="text" class="form-control" name="url" placeholder="'. esc_attr__( 'Website', 'notumn' ) .'" value="' . esc_attr( $notumn_commenter['comment_author_url'] ) . '">',
	);

	$notumn_comment_field = '<textarea class="form-control" id="comment" name="comment" cols="45" rows="4" aria-required="true" placeholder="'. esc_attr__( 'Comment', 'notumn' ) .'"></textarea>';

	comment_form( array(
		'fields'               => $notumn_comment_fields,
		'comment_field'        => $notumn_comment_field,
		'comment_notes_after'  => '',
		'class_form'           => 'comment-form form',
		'class_submit'         => 'btn btn-mod btn-dark',
		'logged_in_as'         => '',
		'comment_notes_before' => '',
		'title_reply'          => esc_html__( 'Leave a Reply', 'notumn' ),
		'cancel_reply_link'    => esc_html__( 'Cancel Reply', 'notumn' ),
		'label_submit'         => esc_html__( 'Post Comment', 'notumn' ),
	) );
	?>
</div><!-- .entry-comments -->
<?php endif; ?>
