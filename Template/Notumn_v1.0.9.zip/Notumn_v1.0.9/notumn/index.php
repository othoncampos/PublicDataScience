<?php
/**
 * Index page.
 *
 * @package notumn
 * @since 1.0
 */

$notumn_home_layout    = get_theme_mod( 'notumn_homepage_layout', 'fullwidth' );
$notumn_home_sidebar   = ( preg_match( '/sidebar/', $notumn_home_layout ) ) ? true : false;
$notumn_home_layout    = explode( '_', $notumn_home_layout );
$notumn_home_layout    = $notumn_home_layout[0];
$notumn_carousel       = get_theme_mod( 'notumn_featured_carousel', true );
$notumn_carousel_style = get_theme_mod( 'notumn_carousel_style', 'style-1' );
$notumn_container_lg   = array( 'list', 'fullwidth', 'grid' );
$notumn_section_title  = array( 'list', 'grid' );

get_header();
?>

<?php if ( $notumn_carousel && $notumn_carousel_style === 'style-1' ) :
	get_template_part( 'includes/templates/featured_carousel' );
endif;

if ( in_array( $notumn_home_layout, $notumn_container_lg, true ) ) : ?>
	<div class="container container-lg">
<?php else : ?>
	<div class="container">
<?php endif; ?>
	
		<?php get_template_part( 'includes/templates/top_custom_code' ); ?>

		<div class="row">

			<?php if ( $notumn_home_layout === 'grid' && ! $notumn_home_sidebar ) : ?>
			<div class="col-md-12">
			<?php elseif ( $notumn_home_layout === 'fullwidth' ) : ?>
			<div class="col-md-10 col-md-push-1">
			<?php else : ?>
			<div class="col-md-8 <?php echo sanitize_html_class( ($notumn_home_sidebar)? 'posts-column' : 'col-md-push-2' ) ?>">
			<?php endif; ?>

			<?php if ( $notumn_carousel && $notumn_carousel_style === 'style-2' && $notumn_home_sidebar ) {
				get_template_part( 'includes/templates/featured_carousel' ); } ?>

				<div class="posts-container relative <?php echo sanitize_html_class( $notumn_home_layout ); ?>">

					<?php if ( in_array( $notumn_home_layout, $notumn_section_title, true ) ) : ?>
					<div class="section-title font-2">
						<h2><?php echo esc_html( get_theme_mod( 'notumn_section_title', __( 'Latest Posts', 'notumn' ) ) ); ?></h2>
					</div><!-- .section-title-->
					<?php endif; ?>

					<?php if ( $notumn_home_layout === 'grid' ) : ?>
						<div class="row">
					<?php endif; ?>

					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'content', $notumn_home_layout ); ?>
					<?php endwhile; endif; ?>

					<?php if ( $notumn_home_layout === 'grid' ) : ?>
						</div>
					<?php endif; ?>

				</div><!-- .posts-container -->

				<?php get_template_part( 'includes/templates/blog_pagination' ); ?>

			</div><!-- .posts-column -->

			<?php if ( $notumn_home_sidebar ) { get_sidebar(); } ?>

		</div><!-- .row -->

		<?php get_template_part( 'includes/templates/bottom_custom_code' ); ?>

	</div><!-- .container -->

<?php
get_footer();
