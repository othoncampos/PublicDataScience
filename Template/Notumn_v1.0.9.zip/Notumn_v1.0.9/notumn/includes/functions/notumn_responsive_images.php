<?php
/**
 * Notumn Responsive Image Functions.
 *
 * @package notumn
 * @since 1.0
 */

/**
 * Notumn Lazy Load Responsive Images.
 */
if ( ! function_exists( 'notumn_lazify_images' ) ) {

	function notumn_lazify_images( $content = '', $remove_hws = false,
		$img_container_width = false, $img_media_query = false ) {

		if ( version_compare( PHP_VERSION, '5.4.0', '>=' ) ) {

			if ( ! empty( $content ) && ! is_feed() ) {

				$document = new DiDom\Document( $content, false );

				foreach ( $document->find( 'img' ) as $img ) {

					$srcset_attr = '';

					if ( $img->hasAttribute( 'src' ) ) {

						$src_attr = $img->getAttribute( 'src' );
						$img->removeAttribute( 'src' );
						$img->setAttribute( 'data-src', $src_attr );

						if ( $img->hasAttribute( 'srcset' ) ) {
							$srcset_attr = $img->getAttribute( 'srcset' );
							$img->removeAttribute( 'srcset' );
							$img->setAttribute( 'data-srcset', $srcset_attr );

							if ( $img->hasAttribute( 'sizes' ) ) {
								$sizes_attr = $img->getAttribute( 'sizes' );
								$img->removeAttribute( 'sizes' );
								$img->setAttribute( 'data-sizes', $sizes_attr );
							}
						}
					}

					$classes = $img->getAttribute( 'class' );
					$classes .= ' lazyload';

					// Jet Pack Gallery Img.
					if ( $img->hasAttribute( 'data-attachment-id' ) ) {
						$attachment_id = $img->getAttribute( 'data-attachment-id' );
						$classes .= ' wp-image-' . $attachment_id;
					}

					$img->setAttribute( 'class', $classes );

					$img_height = (integer) $img->getAttribute( 'height' );
					$img_width  = (integer) $img->getAttribute( 'width' );

					if ( $remove_hws ) {
						$img->removeAttribute( 'height' );
						$img->removeAttribute( 'width' );
						$img->removeAttribute( 'sizes' );
						$img->removeAttribute( 'data-sizes' );
					}

					if ( $img_width !== 0 && $img_height !== 0 ) {

						$ratio_pad  = ( $img_height / $img_width * 100 );
						$new_ratio_wrap_div = new DiDom\Element( 'div' );
						$new_ratio_wrap_div->setAttribute( 'class', 'ratio-box' );
						$new_ratio_wrap_div->setAttribute( 'style', 'padding-bottom: ' . $ratio_pad . '% !important;' );

						$ratio_wrap_align = new DiDom\Element( 'div' );

						$ratio_wrap_width_required = true;

						if ( $img_container_width !== false ) {
							if ( $img_width >= $img_container_width &&
							     notumn_img_has_bigger_sizes( $img_width, $srcset_attr )
							) {
								$ratio_wrap_width_required = false;
								$img->setAttribute( 'sizes', sprintf( $img_media_query, $img_width . 'px' ) );
							}
						}

						$new_ratio_wrap_div->appendChild( $img );

						if ( $ratio_wrap_width_required ) {
							$ratio_wrap_align->setAttribute( 'style', 'width: ' . $img_width . 'px;' );
							$ratio_wrap_align->setAttribute( 'data-width', $img_width );
						}

						// Ratio-box alignment for no caption images.
						if ( preg_match( '/align(left|right|center)/', $classes, $matches ) ) {
							$ratio_wrap_align->setAttribute( 'class', 'ratio-wrap-' . $matches[1] );
						} else {
							$ratio_wrap_align->setAttribute( 'class', 'ratio-wrap' );
						}
						$ratio_wrap_align->appendChild( $new_ratio_wrap_div );

						$img->replace( $ratio_wrap_align );

					} else {

						$ratio_wrap_align = new DiDom\Element( 'div' );
						if ( preg_match( '/align(left|right|center)/', $classes, $matches ) ) {
							$ratio_wrap_align->setAttribute( 'class', 'ratio-wrap-' . $matches[1] );
						} else {
							$ratio_wrap_align->setAttribute( 'class', 'ratio-wrap' );
						}

						$ratio_wrap_align->appendChild( $img );
						$img->replace( $ratio_wrap_align );
					}

					$content = preg_replace( '~<(?:!DOCTYPE|/?(?:html|head|body))[^>]*>\s*~i', '', $document );
					$content = preg_replace( '#<!\[CDATA\[(.+?)\]\]>#s', '$1', $content );
				}
			}
		}

		return $content;
	}
}
add_filter( 'the_content', 'notumn_lazify_images', 30 );

/**
 * Notumn Lazify Thumbnail.
 */
if ( ! function_exists( 'notumn_thumbnail' ) ) {
	function notumn_thumbnail( $post_id, $size, $img_container_width = false, $img_media_query = false ) {
		$attachment_id = get_post_thumbnail_id( $post_id );
		$img_html = wp_get_attachment_image( $attachment_id, $size, false,
			array( 'class' => 'wp-image-' . $attachment_id ) );
		echo notumn_lazify_images( $img_html, true, $img_container_width, $img_media_query );
	}
}

/**
 * Notumn Lazify Entry Image.
 */
if ( ! function_exists( 'notumn_entry_image' ) ) {
	function notumn_entry_image( $post_id, $size ) {
		$img_html = get_the_post_thumbnail( $post_id, $size,
			array( 'class' => 'wp-image-' . get_post_thumbnail_id( $post_id ) ) );
		echo notumn_lazify_images( $img_html, true );
	}
}

/**
 * Notumn Lazify Attachment Image.
 */
if ( ! function_exists( 'notumn_attachment_image' ) ) {
	function notumn_attachment_image( $attachment_id, $size ) {
		$img_html = wp_get_attachment_image( $attachment_id, $size, false,
			array( 'class' => 'wp-image-' . $attachment_id ) );
		echo notumn_lazify_images( $img_html );
	}
}

/**
 * Notumn Lazify Gallery Thumbnail.
 */
if ( ! function_exists( 'notumn_gallery_thumbnail' ) ) {
	function notumn_gallery_thumbnail( $attachment_id, $size,  $img_container_width = false, $img_media_query = false  ) {
		$img_html = wp_get_attachment_image( $attachment_id, $size, false,
			array( 'class' => 'wp-image-' . $attachment_id ) );
		echo notumn_lazify_images( $img_html, true, $img_container_width, $img_media_query );
	}
}

/**
 * Notumn max srcset filter.
 */
if ( ! function_exists( 'notumn_filter_max_srcset' ) ) {
	function notumn_filter_max_srcset( $max_width, $size_array ) {
		if ( $size_array[0] === 870 || $size_array[0] === 690 || $size_array[0] === 670 ) {
			$max_width = 900;
		} elseif ( $size_array[0] === 345 ) {
			$max_width = 700;
		}

		return $max_width;
	}
	add_filter( 'max_srcset_image_width', 'notumn_filter_max_srcset', 10, 2 );
}

/**
 * Image Caption Shortcode.
 */
if ( ! function_exists( 'notumn_img_caption_shortcode' ) ) {
	function notumn_img_caption_shortcode( $val, $attr, $content = null ) {
		$atts = shortcode_atts( array(
			'id'      => '',
			'align'   => '',
			'width'   => '',
			'caption' => '',
		), $attr );

		if ( 1 > (int) $atts['width'] || empty( $atts['caption'] ) ) {
			return $val;
		}

		if ( preg_match( '/align(left|right|center)/', $atts['align'], $matches ) ) {
			return '<div id="' . esc_attr( $atts['id'] ) . '" class="wp-caption ' . sanitize_html_class( $atts['align'] ) . ' ' .
			       sanitize_html_class( 'ratio-wrap-' . $matches[1] ) . '" style="'. esc_attr( 'width:'. $atts['width'] .'px;' ) .'" >' .
			       do_shortcode( $content ) . '<p class="wp-caption-text">' . wp_kses_post( $atts['caption'] ) . '</p></div>';
		}

		return '<div id="' . esc_attr( $atts['id'] ) . '" class="wp-caption ' . sanitize_html_class( $atts['align'] ) . '" >' .
		       do_shortcode( $content ) . '<p class="wp-caption-text">' . wp_kses_post( $atts['caption'] ) . '</p></div>';
	}
	add_filter( 'img_caption_shortcode', 'notumn_img_caption_shortcode', 10, 3 );
}


/**
 * Add class attribute for Image Attachments.
 * 
 * @since 1.0.5
 */
if ( ! function_exists( 'notumn_attachment_img_attr' ) ) {
	function notumn_attachment_img_attr( $attr, $attchment ) {

		$attchment_classes = $attr['class'];

		if ( ! preg_match( '/wp-image-/', $attchment_classes ) ) {
			$attr['class'] = $attchment_classes . ' wp-image-' . $attchment->ID;
		}

		return $attr;
	}

	add_filter( 'wp_get_attachment_image_attributes', 'notumn_attachment_img_attr', 10, 2 );
}

/**
 * Check if bigger image sizes available.
 *
 * @since 1.0.6
 */
function notumn_img_has_bigger_sizes( $size, $srcset ){
	if( $srcset !== null ){
		preg_match_all( '/ (\d+)w/', $srcset, $matches );

		if( ! empty( $matches[1] ) ){
			return ( max( $matches[1] ) > $size ) ? true : false;
		}
	}

	return false;
}

/**
 * Generate Light Gallery Data for a post.
 *
 * @param integer $post_id post's id.
 */
if ( ! function_exists( 'notumn_light_gallery_images' ) ) {

	function notumn_light_gallery_images( $post_id ) {

		$enable_title    = get_theme_mod( 'notumn_lg_title', true );
		$enable_caption  = get_theme_mod( 'notumn_lg_caption', true );
		$attachment_size = get_theme_mod( 'notumn_lg_size', 'notumn_featured_thumb' );
		$post_galleries  = get_post_galleries( $post_id, false );
		$attachment_ids  = array();
		$image_items     = array();
		$item_ids        = array();
		$post            = get_post( $post_id );

		preg_match_all( '/wp-image-(\d+)/', $post->post_content, $matches );

		if( ! empty( $matches[1] ) ){
			$attachment_ids = array_merge( $attachment_ids, $matches[1] );
		}

		if ( has_post_thumbnail( $post_id ) ) {
			$attachment_ids[] = get_post_thumbnail_id( $post_id );
		}

		foreach ( $post_galleries as $post_gallery ) {

			if ( ! empty( $post_gallery ) && array_key_exists( 'ids', $post_gallery ) ) {

				$gallery_items = $post_gallery['ids'];

				if ( ! empty( $gallery_items ) ) {
					$attachment_ids = array_merge( $attachment_ids, explode( ',', $gallery_items ) );
				}
			}
		}

		if ( has_post_format( 'gallery', $post_id ) ) {
			$gallery_images = get_post_meta( $post_id, '_format_gallery_images', true );
			if ( ! empty( $gallery_images ) ) {
				$attachment_ids = array_merge( $attachment_ids, $gallery_images );
			}
		}

		$attachment_ids = array_values( array_unique( $attachment_ids, SORT_REGULAR ) );

		foreach ( $attachment_ids as $attachment_id ) {

			$attachment = get_post( $attachment_id );

			if ( is_object( $attachment ) ) {
				$item_ids[] = $attachment_id;
				$sub_html = ($enable_title)? '<h4>'. wp_kses_post( $attachment->post_title ) .'</h4>' : '';
				$sub_html .= ($enable_caption)? '<p>'. wp_kses_post( $attachment->post_excerpt ) .'</p>' : '';

				$attachment_img_src = wp_get_attachment_image_src( $attachment_id, $attachment_size );
				$attachment_thumb_src = wp_get_attachment_image_src( $attachment_id, 'notumn_small_thumb' );

				$image_items[] = array(
					'src'     => $attachment_img_src[0],
					'thumb'   => $attachment_thumb_src[0],
					'subHtml' => $sub_html,
				);
			}
		}

		return 'lightGalleryData[' . esc_js( $post_id ) . '] = ' . wp_json_encode( array(
			'attachments' => array_flip( $item_ids ),
			'elements'    => $image_items,
		) );
	}
}
