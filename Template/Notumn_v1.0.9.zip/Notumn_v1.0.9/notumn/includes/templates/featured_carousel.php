<?php
$notumn_home_layout         = get_theme_mod( 'notumn_homepage_layout', 'fullwidth' );
$notumn_home_sidebar        = ( preg_match( '/sidebar/', $notumn_home_layout ) ) ? true : false;
$notumn_home_layout         = explode( '_', $notumn_home_layout );
$notumn_home_layout         = $notumn_home_layout[0];
$notumn_feat_carousel_paged = get_theme_mod( 'notumn_feat_carousel_paged', false );

if ( ( $notumn_feat_carousel_paged && ! is_paged() ) || ( ! $notumn_feat_carousel_paged ) ) :

	$notumn_carousel_style = get_theme_mod( 'notumn_carousel_style', 'style-1' );

	if ( $notumn_carousel_style === 'style-1' ): ?>
		<div class="featured-area owl-carousel">
	<?php elseif ( $notumn_carousel_style === 'style-2' ): ?>
		<div class="featured-area-2 owl-carousel">
	<?php endif;

	switch ( get_theme_mod( 'notumn_carousel_type', 'featured' ) ) {
		case 'featured' :
			default_case:

			$notumn_carousel_args = array(
				'showposts'  => get_theme_mod( 'notumn_max_carousel_items', '5' ),
				'meta_query' => array(
					'featured'  => array(
						'key'   => '_ntmn_is_featured',
						'value' => 'Y',
					),
					'thumbnail' => array(
						'key'     => '_thumbnail_id',
						'compare' => 'EXISTS',
					),
				),
				'ignore_sticky_posts' => true,
			);

			break;
		case 'popular-likes' :

			$notumn_carousel_args = array(
				'showposts'  => get_theme_mod( 'notumn_max_carousel_items', '5' ),
				'meta_query' => array(
					'thumbnail' => array(
						'key'     => '_thumbnail_id',
						'compare' => 'EXISTS',
					),
					'likes'     => array(
						'key'     => '_zilla_likes',
						'compare' => 'EXISTS',
					),
				),
				'orderby'    => 'likes',
				'ignore_sticky_posts' => true,
			);

			break;
		case 'popular-comments' :

			$notumn_carousel_args = array(
				'showposts'  => get_theme_mod( 'notumn_max_carousel_items', '5' ),
				'meta_query' => array(
					'thumbnail' => array(
						'key'     => '_thumbnail_id',
						'compare' => 'EXISTS',
					),
				),
				'orderby'    => 'comment_count',
				'ignore_sticky_posts' => true,
			);

			break;
		default:
			goto default_case;

	}

	$notumn_featured_query = new WP_Query( $notumn_carousel_args );

	if ( $notumn_featured_query->have_posts() ) :

		while ( $notumn_featured_query->have_posts() ) : $notumn_featured_query->the_post() ?>
			<div class="featured-item">
				<a href="<?php the_permalink(); ?>">
					<div class="featured-img">
						<?php
						if ( $notumn_carousel_style === 'style-2' &&
                             ( $notumn_home_layout === 'grid' || $notumn_home_layout === 'list' ) ) :
							notumn_thumbnail( $post->ID, 'notumn_carousel_thumb', 690,
								'(max-width: 997px) 50vw, (max-width: 585px) 100vw, %1$s' );
						else :
							notumn_thumbnail( $post->ID, 'notumn_featured_thumb', 670,
								'(max-width: 991px) 100vw, %1$s' );
						endif;
						?>
					</div>
				</a>

				<div class="featured-item-foot font-2">
					<div class="featured-item-category font-2"><?php the_category( '' ); ?></div>
					<h2 class="featured-item-title font-2">
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					</h2>
					<div class="featured-item-meta">
						<span class="item-comments">
							<?php
							if ( defined( 'DISQUS_DOMAIN' ) ) : ?>
								<a class="disqus-link" href="<?php echo esc_url( get_the_permalink() . '#disqus_thread' ); ?>"></a>
							<?php else : ?>
								<a href="<?php echo esc_url( get_comments_link() ); ?>"><i class="fa fa-comments-o"></i>
									<?php comments_number( 0, 1, '%' ); ?>
								</a>
							<?php endif;
							?>
						</span>
					<span class="item-date"
					      title="<?php the_time( 'Y-m-d H:i:s' ); ?>"><?php the_time( get_option( 'date_format' ) ); ?></span>
						<span class="item-likes"><?php notumn_likes(); ?></span>
					</div>
				</div><!-- .fututed-item-meta -->
			</div><!-- .featured-item -->
		<?php endwhile;
	endif; ?>
	</div><!-- .featured-area -->
	<?php
endif;
