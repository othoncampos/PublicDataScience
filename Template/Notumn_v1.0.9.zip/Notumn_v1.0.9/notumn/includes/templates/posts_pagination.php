<div class="entry-pagination post clearfix">
	<div class="prev-post">
		<?php previous_post_link( '%link', '<i class="fa fa-long-arrow-left"></i> %title', true, '' ); ?>
	</div>
	<div class="next-post">
		<?php next_post_link( '%link', '%title <i class="fa fa-long-arrow-right"></i>', true, '' ); ?>
	</div>
</div><!-- .entry-pagination -->
