<?php
$notumn_categories   = get_the_category();
$notumn_post_ids     = array( $post->ID );
$notumn_category_ids = array();

foreach ( $notumn_categories as $notumn_category ) {
	$notumn_category_ids[] = $notumn_category->term_id;
}

$notumn_rel_posts_args = array(
	'category__in'        => $notumn_category_ids,
	'post__not_in'        => $notumn_post_ids,
	'posts_per_page'      => 2,
	'ignore_sticky_posts' => true,
	'orderby'             => 'rand',
	'meta_query'          => array(
		array(
			'key'     => '_thumbnail_id',
			'compare' => 'EXISTS',
		),
	),
);

$notumn_rel_posts_query = new wp_query( $notumn_rel_posts_args ); ?>

<?php
if ( $notumn_rel_posts_query->have_posts() ) : ?>

	<div class="entry-related-posts">

		<h4 class="entry-post-title font-2"><?php esc_html_e( 'You might also like', 'notumn' ); ?></h4>

		<div class="row">

			<?php while ( $notumn_rel_posts_query->have_posts() ) : $notumn_rel_posts_query->the_post(); ?>

				<div class="col-sm-6">
					<article class="related-post post">

						<div class="entry-image">
							<div class="holder-ratio-wrap ratio-fit">
								<a href="<?php the_permalink(); ?>">
									<?php notumn_thumbnail( $post->ID, 'notumn_grid_thumb', 345,
										'(max-width: 768px) 50vw, (max-width: 767px) 100vw, %1$s' ); ?>
								</a>
							</div>
						</div><!-- .entry-image -->

						<header class="entry-header">
							<div class="entry-category font-2"><?php the_category( '' ); ?></div>
							<h2 class="entry-title font-2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						</header><!-- .entry header -->
					</article>
				</div>

			<?php endwhile ?>

		</div>

	</div><!-- .related-posts -->
<?php endif; ?>

<?php
wp_reset_postdata();
