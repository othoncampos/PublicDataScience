<?php
$notumn_home_layout              = get_theme_mod( 'notumn_homepage_layout', 'fullwidth' );
$notumn_home_sidebar             = ( preg_match( '/sidebar/', $notumn_home_layout ) ) ? true : false;
$notumn_home_layout              = explode( '_', $notumn_home_layout );
$notumn_home_layout              = $notumn_home_layout[0];
$notumn_bottom_custom_code       = get_theme_mod( 'notumn_bottom_custom_code' );
$notumn_bottom_custom_code_paged = get_theme_mod( 'notumn_bottom_custom_code_paged', false );

if ( ( ! empty( $notumn_bottom_custom_code ) )
     && ( ( $notumn_bottom_custom_code_paged && ! is_paged() ) || ( ! $notumn_bottom_custom_code_paged ) ) ) : ?>

	<div class="row bottom-custom-code">

		<?php if ( $notumn_home_layout === 'grid' && ! $notumn_home_sidebar ) : ?>
		<div class="col-md-12">
		<?php elseif ( $notumn_home_layout === 'fullwidth' ) : ?>
		<div class="col-md-10 col-md-push-1">
		<?php elseif ( $notumn_home_layout === 'full' && ! $notumn_home_sidebar ) : ?>
		<div class="col-md-8 col-md-push-2">
		<?php else : ?>
		<div class="col-md-12 cc-pad">
		<?php endif;

		if ( ( $notumn_bottom_custom_code_paged && ! is_paged() ) || ( ! $notumn_bottom_custom_code_paged ) ) :
			echo do_shortcode( $notumn_bottom_custom_code );
		endif; ?>

		</div>
	</div>
	<?php
endif;
