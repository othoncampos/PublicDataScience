<?php
// Get Social Links data.
$notumn_social_links = notumn_social_links();
foreach ( $notumn_social_links as $notumn_social_link => $notumn_social_link_meta ) :

	$notumn_social_link_val = get_theme_mod( $notumn_social_link );

	if ( ! empty( $notumn_social_link_val ) ) :

		if ( filter_var( $notumn_social_link_val, FILTER_VALIDATE_URL ) ) {
			$notumn_social_url = $notumn_social_link_val;
		} else {
			$notumn_social_url = sprintf( $notumn_social_link_meta['format'], $notumn_social_link_val );
		}

		echo '<li><a href="' . esc_url( $notumn_social_url ) . '" title="' . esc_attr( $notumn_social_link_meta['label'] ) .
		'" target="_blank"><i class="fa ' . sanitize_html_class( $notumn_social_link_meta['icon-class'] ) . '"></i></a></li>', "\n";

	endif;
endforeach;
