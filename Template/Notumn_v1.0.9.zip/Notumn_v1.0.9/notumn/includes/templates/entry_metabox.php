<?php
/*
 * Template part entry metabox.
 *
 *
 */
?>

<div class="entry-meta-box font-2 clearfix">
	<div class="entry-author-name vcard author post-author">
		<a href="<?php echo esc_url( get_author_posts_url(
			get_the_author_meta( 'ID' ) ) ); ?>"><?php esc_html_e( 'By ', 'notumn' );
			?><span class="fn"><?php the_author(); ?></span></a>
	</div>
	<div class="entry-social-links">
		<?php notumn_sharing_links( $post->Id ); ?>
	</div>
	<div class="entry-likes"><?php notumn_likes(); ?></div>
</div><!-- .entry-meta -->