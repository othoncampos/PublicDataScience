<?php
$notumn_author_description   = get_the_author_meta( 'description' );
$notumn_user_fname           = get_the_author_meta( 'first_name' );
$notumn_user_lname           = get_the_author_meta( 'last_name' );
$notumn_user_email           = get_the_author_meta( 'user_email' );
$notumn_user_url             = get_the_author_meta( 'user_url' );
$notumn_user_contact_methods = wp_get_user_contact_methods();

if ( ! empty( $notumn_author_description ) ):
	?>
	<div class="entry-author clearfix">
		<div class="row">
			<div class="col-sm-3">
				<div class="author-img">
					<div class="profile-img img-circle">
						<?php echo wp_kses_post( get_avatar( get_the_author_meta( 'ID' ), 176 ) ); ?>
					</div>
				</div>
			</div>
			<div class="col-sm-9">
				<div class="author-content">
					<h4 class="author-name font-2"><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php
							echo esc_html( "$notumn_user_fname $notumn_user_lname" ); ?></a>
					</h4>

					<p><?php echo esc_html( $notumn_author_description ); ?></p>

					<div class="author-social-links">

						<?php if ( ! empty( $notumn_user_email ) ) : ?>
							<a href="<?php echo esc_url( "mailto:{$notumn_user_email}?Subject=Hello" ); ?>"
							   title="Email"><i class="fa fa-envelope"></i></a>
						<?php endif; ?>

						<?php if ( ! empty( $notumn_user_url ) ) : ?>
							<a href="<?php echo esc_url( $notumn_user_url ); ?>" title="Website" target="_blank"><i
									class="fa fa-globe"></i></a>
						<?php endif;

						$notumn_social_links = notumn_social_links();

						foreach ( $notumn_user_contact_methods as $notumn_contact_method => $notumn_contact_method_label ) :

							$notumn_contact_method_val = get_the_author_meta( $notumn_contact_method );
							if ( ! empty( $notumn_contact_method_val ) && isset( $notumn_social_links[ $notumn_contact_method ] ) ) :

								if ( filter_var( $notumn_contact_method_val, FILTER_VALIDATE_URL ) ) {
									$notumn_social_url = $notumn_contact_method_val;
								} else {
									$notumn_social_url = sprintf( $notumn_social_links[ $notumn_contact_method ]['format'], $notumn_contact_method_val );
								}

								?>
								<a href="<?php echo esc_url( $notumn_social_url ); ?>"
								   title="<?php echo esc_attr( $notumn_contact_method_label ); ?>" target="_blank">
									<i class="fa <?php echo sanitize_html_class( $notumn_social_links[ $notumn_contact_method ]['icon-class'] ); ?>"></i></a>
							<?php endif;
						endforeach; ?>

					</div><!-- .author-social-links -->
				</div><!-- .author-content -->
			</div><!-- .column -->
		</div><!-- .row -->
	</div><!-- .entry-author -->
	<?php
endif;
