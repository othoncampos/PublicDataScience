<?php
/**
 * Static Front Page Top Custom Code Area.
 *
 * @package notumn
 * @since 1.0.7
 */

$notumn_page_layout           = get_post_meta( $post->ID, '_notumn-page-layout', true );
$notumn_page_sidebar          = ( preg_match( '/sidebar/', $notumn_page_layout ) ) ? true : false;
$notumn_static_front_layout   = explode( '_', $notumn_page_layout );
$notumn_static_front_layout   = $notumn_static_front_layout[0];
$notumn_top_custom_code       = get_theme_mod( 'notumn_static_top_custom_code' );

if ( ! empty( $notumn_top_custom_code ) ) : ?>

	<div class="row top-custom-code">

		<?php if ( $notumn_static_front_layout === 'medium' && $notumn_page_sidebar ) : ?>
		<div class="col-md-12">
		<?php elseif ( $notumn_static_front_layout === 'fullwidth' ) : ?>
		<div class="col-md-10 col-md-push-1">
		<?php elseif ( $notumn_static_front_layout === 'medium' && ! $notumn_page_sidebar ) : ?>
		<div class="col-md-8 col-md-push-2">
		<?php else : ?>
		<div class="col-md-12 cc-pad">
		<?php endif;
			echo do_shortcode( $notumn_top_custom_code );
		?>
		</div>
	</div>
	<?php
endif;
