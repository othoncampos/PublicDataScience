<?php
/**
 * Blog Pagination.
 *
 * @package notumn
 * @since 1.0
 */

$notumn_numbered_pagination    = get_theme_mod( 'notumn_numbered_pagination', false );
?>
<div class="entry-pagination clearfix">
    <?php if( $notumn_numbered_pagination ) :

    $notumn_pagination = paginate_links( array(
	    'base'     => str_replace( 99999, '%#%', esc_url( get_pagenum_link(99999) ) ),
	    'format'   => '',
	    'mid_size' => 2,
	    'prev_text' => '<i class="fa fa-angle-left"></i>',
	    'next_text' => '<i class="fa fa-angle-right"></i>',
	    'type' => 'list',
    ) );

    echo '<nav class="page-navigation">' . $notumn_pagination . '</nav>';

    else : ?>

	<div class="prev-post">
		<?php previous_posts_link( '<i class="fa fa-long-arrow-left"></i> ' . esc_html__( 'Newer Posts', 'notumn' ) ); ?>
	</div>
	<div class="next-post">
		<?php next_posts_link( esc_html__( 'Older Posts', 'notumn' ) . ' <i class="fa fa-long-arrow-right"></i>' ); ?>
	</div>

    <?php endif; ?>
</div><!-- .entry-pagination -->
