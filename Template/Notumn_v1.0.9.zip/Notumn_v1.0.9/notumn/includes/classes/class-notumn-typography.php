<?php
/**
 * Class Name: Notumn_typography
 *
 * @package notumn
 * @since 1.0
 */

if ( ! class_exists( 'Notumn_typography' ) ) {

	class Notumn_typography {

		/**
		 * Creates Google Font URLs and CSS using
		 * theme modifications values and returns.
		 *
		 * @return array
		 */
		public static function get_fonts() {

			$font_1 = get_theme_mod( 'notumn_font_1', "'Open Sans', sans-serif;" );
			$font_2 = get_theme_mod( 'notumn_font_2', "'Montserrat', sans-serif;" );
			$font_3 = get_theme_mod( 'notumn_font_3', "'Crimson Text', serif;" );

			if ( $font_1 === 'other' ) {
				$font_1 = get_theme_mod( 'notumn_font_1_other', "'Open Sans', sans-serif;" );
			}

			if ( $font_2 === 'other' ) {
				$font_2 = get_theme_mod( 'notumn_font_2_other', "'Montserrat', sans-serif;" );
			}

			if ( $font_3 === 'other' ) {
				$font_3 = get_theme_mod( 'notumn_font_3_other', "'Crimson Text', serif;" );
			}

			$font_1_style     = self::get_font_style( $font_1 );
			$font_2_style     = self::get_font_style( $font_2 );
			$font_3_style     = self::get_font_style( $font_3 );
			$font_1           = self::get_font_name( $font_1 );
			$font_2           = self::get_font_name( $font_2 );
			$font_3           = self::get_font_name( $font_3 );
			$charset_latin    = get_theme_mod( 'notumn_charset_latin' );
			$charset_cyrillic = get_theme_mod( 'notumn_charset_cyrillic' );
			$charset_greek    = get_theme_mod( 'notumn_charset_greek' );
			$font_ext         = '';

			if ( $charset_latin && $charset_greek && $charset_cyrillic ) {
				$font_ext = '&subset=latin,greek,greek-ext,cyrillic-ext,latin-ext,cyrilli';
			} elseif ( $charset_latin && $charset_greek ) {
				$font_ext = '&subset=latin,greek,greek-ext,latin-ext';
			} elseif ( $charset_latin && $charset_cyrillic ) {
				$font_ext = '&subset=latin,latin-ext,cyrillic,cyrillic-ext';
			} elseif ( $charset_latin ) {
				$font_ext = '&subset=latin,latin-ext';
			} elseif ( $charset_greek ) {
				$font_ext = '&subset=greek-ext,greek';
			} elseif ( $charset_cyrillic ) {
				$font_ext = '&subset=cyrillic,cyrillic-ext';
			}

			$font_url  = "//fonts.googleapis.com/css?family={$font_1}|{$font_2}|{$font_3}:400,400italic{$font_ext}";
			$fonts_css = "body{font-family:{$font_1_style}}.font-1{font-family:$font_1_style}.font-2{font-family:{$font_2_style}}.font-3{font-family:{$font_3_style}}";

			return array( esc_url( $font_url ), $fonts_css );
		}

		/**
		 * Retrives font name from css style
		 *
		 * @param string $font_css css style.
		 *
		 * @return string
		 */
		public static function get_font_name( $font_css ) {
			$font_css  = str_replace( 'font-family:', '', $font_css );
			$font_css  = trim( $font_css );
			$font_css  = substr( $font_css, 0, strpos( $font_css, ',' ) );
			$font_name = urlencode( str_replace( "'", '', $font_css ) );

			return $font_name;
		}

		/**
		 * Retrives font-family value.
		 *
		 * @param string $font_css css style.
		 *
		 * @return mixed|string
		 */
		public static function get_font_style( $font_css ) {
			$font_css = str_replace( 'font-family:', '', $font_css );
			$font_css = trim( $font_css );

			return $font_css;
		}
	}
}
