<?php
/**
 * Class Name: Notumn_Featured_Post
 *
 * @package notumn
 * @since 1.0
 */


if ( ! class_exists( 'Notumn_Featured_Post' ) ) {

	class Notumn_Featured_Post {

		/**
		 * Instance of the class.
		 *
		 * @var object
		 */
		private static $instance;

		/**
		 * Notumn_Featured_Post constructor.
		 */
		function __construct() {

			add_action( 'admin_head-edit.php', array( $this, 'admin_script' ) );
			add_filter( 'manage_edit-post_columns', array( $this, 'posts_custom_columns' ) );
			add_action( 'manage_posts_custom_column', array( $this, 'posts_custom_column' ), 10, 2 );
			add_action( 'wp_ajax_update_featured_post', array( $this, 'ajax_update_featured_post' ) );
		}

		/**
		 * Instantiate Class
		 *
		 * @return Notumn_Featured_Post
		 */
		static function instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new Notumn_Featured_Post();
			}

			return self::$instance;
		}

		/**
		 * Register Featured Post Column
		 *
		 * @param array $columns custom columns.
		 *
		 * @return mixed
		 */
		public function posts_custom_columns( $columns ) {
			$columns['notumn_featured'] = esc_html__( 'Featured', 'notumn' );

			return $columns;
		}

		/**
		 * Add Featured Post Column Content
		 *
		 * @param array   $column custom columns.
		 * @param integer $post_id post id.
		 */
		public function posts_custom_column( $column, $post_id ) {
			if ( $column === 'notumn_featured' ) {
				$featured = get_post_meta( $post_id, '_ntmn_is_featured', true );

				if ( $featured === 'Y' ) {
					$class = ' dashicons-star-filled';
				} else {
					$class = ' dashicons-star-empty';
				}
				?>
				<a href="#!" class="notumn-featured-toggle dashicons <?php echo sanitize_html_class( $class ) ?>"
				   data-post-id="<?php echo esc_attr( $post_id ); ?>"></a>
				<?php
			}
		}


		/**
		 * Featured Post Toggle Ajax Admin Script.
		 */
		public function admin_script() {
			?>
			<script type="text/javascript">
				jQuery(document).ready(function ($) {

					$('.notumn-featured-toggle').on('click', function () {

						var toggleEle = $(this),
							postId = $(this).attr('data-post-id');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							dataType: 'json',
							data: {
								'action': 'update_featured_post',
								'post_id': postId
							},
							success: function (data) {
								if (data.status == 'updated') {
									toggleEle
										.toggleClass('dashicons-star-empty')
										.toggleClass('dashicons-star-filled');
								}
							}
						});
					});

				});
			</script>
			<?php
		}

		/**
		 * Featured Post Toggle Ajax Handler.
		 */
		public function ajax_update_featured_post() {
			if ( isset( $_POST['post_id'] ) ) {
				$post_id  = $_POST['post_id'];
				$featured = get_post_meta( $post_id, '_ntmn_is_featured', true );
				if ( $featured === 'Y' ) {
					update_post_meta( $post_id, '_ntmn_is_featured', 'N' );
				} else {
					update_post_meta( $post_id, '_ntmn_is_featured', 'Y' );
				}
				echo wp_json_encode( array( 'post_id' => $post_id, 'status' => 'updated' ) );
				die();
			}
		}
	}

	Notumn_Featured_Post::instance();
}
