<?php
/**
 * Class Name: Notumn_social_links
 *
 * @package notumn
 * @since 1.0
 */

if ( ! class_exists( 'Notumn_social_links' ) ) {

	class Notumn_social_links {

		/**
		 * Social links default settings.
		 * %s : username
		 *
		 * @var array
		 */
		public static $social_links = array(
			'notumn_facebook'    => array(
				'label'      => 'Facebook',
				'icon-class' => 'fa-facebook',
				'format'     => 'http://facebook.com/%s',
			),
			'notumn_twitter'     => array(
				'label'      => 'Twitter',
				'icon-class' => 'fa-twitter',
				'format'     => 'http://twitter.com/%s',
			),
			'notumn_instagram'   => array(
				'label'      => 'Instagram',
				'icon-class' => 'fa-instagram',
				'format'     => 'http://instagram.com/%s',
			),
			'notumn_pinterest'   => array(
				'label'      => 'Pinterest',
				'icon-class' => 'fa-pinterest',
				'format'     => 'http://pinterest.com/%s',
			),
			'notumn_linkedin'    => array(
				'label'      => 'LinkedIn',
				'icon-class' => 'fa-linkedin',
				'format'     => 'http://www.linkedin.com/in/%s',
			),
			'notumn_tumblr'      => array(
				'label'      => 'Tumblr',
				'icon-class' => 'fa-tumblr',
				'format'     => 'http://%s.tumblr.com/',
			),
			'notumn_google-plus' => array(
				'label'      => 'Google+',
				'icon-class' => 'fa-google-plus',
				'format'     => 'http://plus.google.com/+%s',
			),
			'notumn_youtube'     => array(
				'label'      => 'Youtube',
				'icon-class' => 'fa-youtube',
				'format'     => 'http://youtube.com/%s',
			),
			'notumn_vimeo'       => array(
				'label'      => 'Vimeo',
				'icon-class' => 'fa-vimeo',
				'format'     => 'http://vimeo.com/%s',
			),
			'notumn_bloglovin'   => array(
				'label'      => 'Bloglovin\'',
				'icon-class' => 'fa-heart',
				'format'     => 'http://bloglovin.com/%s',
			),
		);

		/**
		 * Social Sharing links default settings.
		 * %1$s : permalink
		 * %2$s : title
		 * %3$s : image url
		 * %4$s : site name
		 *
		 * @var array
		 */
		public static $social_sharing_links = array(
			'notumn_facebook'    => array(
				'label'      => 'Facebook',
				'icon-class' => 'fa-facebook',
				'format'     => 'https://www.facebook.com/sharer/sharer.php?u=%1$s',
			),
			'notumn_twitter'     => array(
				'label'      => 'Twitter',
				'icon-class' => 'fa-twitter',
				'format'     => 'https://twitter.com/home?status=Check out this article:%2$s - %1$s',
			),
			'notumn_pinterest'   => array(
				'label'      => 'Pinterest',
				'icon-class' => 'fa-pinterest',
				'format'     => 'https://pinterest.com/pin/create/button/?url=%1$s&media=%3$s&description=%2$s',
			),
			'notumn_linkedin'    => array(
				'label'      => 'LinkedIn',
				'icon-class' => 'fa-linkedin',
				'format'     => 'https://www.linkedin.com/shareArticle?mini=true&url=%1$s&title=%2$s&summary=&source=%4$s',
			),
			'notumn_google-plus' => array(
				'label'      => 'Google+',
				'icon-class' => 'fa-google-plus',
				'format'     => 'https://plus.google.com/share?url=%1$s',
			),
		);

		/**
		 * Displays Social Sharing links for the post
		 *
		 * @param integer $post_id current post id.
		 */
		public static function notumn_sharing_links( $post_id ) {

			foreach ( self::$social_sharing_links as $sharing_link => $sharing_link_meta ) :
				$image_url = wp_get_attachment_url( get_post_thumbnail_id( $post_id ) );
				$share_url = sprintf( $sharing_link_meta['format'], get_the_permalink(),
					get_the_title(), $image_url, get_bloginfo( 'title' ) );
				?>
				<a href="<?php echo esc_url( $share_url ); ?>"
				   title="<?php echo esc_attr( $sharing_link_meta['label'] ); ?>"
				   target="_blank"><i class="fa <?php echo sanitize_html_class( $sharing_link_meta['icon-class'] ); ?>"></i></a>
				<?php
			endforeach;
		}
	}
}
