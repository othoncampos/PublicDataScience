<?php
/**
 * Class Name: Notumn_post_metaboxes
 *
 * @package notumn
 * @since 1.0
 */

if ( ! class_exists( 'Notumn_post_metaboxes' ) ) {

	class Notumn_post_metaboxes {

		/**
		 * Instance of the class.
		 *
		 * @var object
		 */
		private static $instance;

		/**
		 * Notumn_post_metaboxes constructor.
		 */
		function __construct() {
			add_action( 'add_meta_boxes', array( $this, 'notumn_add_meta_box' ) );
			add_action( 'save_post', array( $this, 'notumn_save_metabox' ) );
		}

		/**
		 * Instantiate Class
		 *
		 * @return Notumn_post_metaboxes
		 */
		static function instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new Notumn_post_metaboxes();
			}

			return self::$instance;
		}

		/**
		 * Create meta boxes
		 */
		function notumn_add_meta_box() {
			add_meta_box(
				'notumn_img_size_post_metabox',
				esc_html__( 'Notumn: Featured Image Size', 'notumn' ),
				array( $this, 'display_img_size_metabox' ),
				'post',
				'side'
			);

			add_meta_box(
				'notumn_img_size_page_metabox',
				esc_html__( 'Notumn: Featured Image Size', 'notumn' ),
				array( $this, 'display_img_size_metabox' ),
				'page',
				'side'
			);

			add_meta_box(
				'notumn_post_layout_metabox',
				esc_html__( 'Notumn: Post Layout Style', 'notumn' ),
				array( $this, 'display_post_layout_style_metabox' ),
				'post',
				'side'
			);

			add_meta_box(
				'notumn_page_layout_metabox',
				esc_html__( 'Notumn: Page Layout Style', 'notumn' ),
				array( $this, 'display_page_layout_style_metabox' ),
				'page',
				'side'
			);
		}


		/**
		 * Save the input meta values to the db
		 *
		 * @param integer $post_id post id.
		 *
		 * @return mixed
		 */
		function notumn_save_metabox( $post_id ) {

			// Check if our nonce is set.
			if ( ! isset( $_POST['notumn_meta_nonce'] ) ) {
				return $post_id;
			}

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return false;
			}

			// Verify that the nonce is valid.
			$nonce = $_POST['notumn_meta_nonce'];
			if ( ! wp_verify_nonce( $nonce, 'notumn_meta_nonce' ) ) {
				return $post_id;
			}

			if ( isset( $_POST['notumn-img-size'] ) ) {
				$notumn_img_size = $_POST['notumn-img-size'];
				if ( in_array( $notumn_img_size, array( 'full', 'standard' ), true ) ) {
					update_metadata( 'post', $post_id, '_notumn-img-size', $notumn_img_size );
				}
			}

			if ( isset( $_POST['notumn-post-layout'] ) ) {
				$notumn_post_layout = $_POST['notumn-post-layout'];
				if ( in_array( $notumn_post_layout, array( 'medium_sidebar', 'medium', 'fullwidth' ), true ) ) {
					update_metadata( 'post', $post_id, '_notumn-post-layout', $notumn_post_layout );
				}
			}

			if ( isset( $_POST['notumn-page-layout'] ) ) {
				$notumn_page_layout = $_POST['notumn-page-layout'];
				if ( in_array( $notumn_page_layout, array( 'medium_sidebar', 'medium', 'fullwidth' ), true ) ) {
					update_metadata( 'post', $post_id, '_notumn-page-layout', $notumn_page_layout );
				}
			}
		}

		/**
		 * Output the image size meta box html.
		 */
		function display_img_size_metabox() {

			$notumn_img_size = get_post_meta( get_the_ID(), '_notumn-img-size', true );
			wp_nonce_field( 'notumn_meta_nonce', 'notumn_meta_nonce' );

			// Default image size.
			if ( empty( $notumn_img_size ) ) {
				$notumn_img_size = 'standard';
			}
			?>
			<p>
				<input type="radio" id="notumn-img-size-full" name="notumn-img-size"
				       value="full" <?php checked( 'full', $notumn_img_size ); ?> style="margin-top: 1px;" >
				<label for="notumn-img-size-full"><?php esc_html_e( 'Full Size (no crop)', 'notumn' ); ?></label>
			</p>

			<p>
				<input type="radio" id="notumn-img-size-standard" name="notumn-img-size"
				       value="standard" <?php checked( 'standard', $notumn_img_size ); ?> style="margin-top: 1px;" >
				<label for="notumn-img-size-standard"><?php esc_html_e( 'Standard (cropped)', 'notumn' ); ?></label>
			</p>
			<?php
		}

		/**
		 * Output the post layout style meta box html.
		 */
		public function display_post_layout_style_metabox() {

			$notumn_post_layout = get_post_meta( get_the_ID(), '_notumn-post-layout', true );

			// Default Post Layout.
			if ( empty( $notumn_post_layout ) ) {
				$notumn_post_layout = 'medium_sidebar';
			}
			?>
			<p>
				<input type="radio" id="notumn-post-layout-ms" name="notumn-post-layout"
				       value="medium_sidebar" <?php checked( 'medium_sidebar', $notumn_post_layout ); ?> style="margin-top: 1px;" >
				<label for="notumn-post-layout-ms"><?php esc_html_e( 'Medium Width + Sidebar', 'notumn' ); ?></label>
			</p>

			<p>
				<input type="radio" id="notumn-post-layout-m" name="notumn-post-layout"
				       value="medium" <?php checked( 'medium', $notumn_post_layout ); ?> style="margin-top: 1px;" >
				<label for="notumn-post-layout-m"><?php esc_html_e( 'Medium Width (No Sidebar)', 'notumn' ); ?></label>
			</p>

			<p>
				<input type="radio" id="notumn-post-layout-f" name="notumn-post-layout"
				       value="fullwidth" <?php checked( 'fullwidth', $notumn_post_layout ); ?> style="margin-top: 1px;" >
				<label for="notumn-post-layout-f"><?php esc_html_e( 'Full Width (No Sidebar)', 'notumn' ); ?></label>
			</p>
			<?php
		}

		/**
		 * Output the post layout style meta box html.
		 */
		public function display_page_layout_style_metabox() {

			$notumn_page_layout = get_post_meta( get_the_ID(), '_notumn-page-layout', true );

			// Default Post Layout.
			if ( empty( $notumn_page_layout ) ) {
				$notumn_page_layout = 'medium_sidebar';
			}
			?>
			<p>
				<input type="radio" id="notumn-page-layout-ms" name="notumn-page-layout"
				       value="medium_sidebar" <?php checked( 'medium_sidebar', $notumn_page_layout ); ?> style="margin-top: 1px;" >
				<label for="notumn-page-layout-ms"><?php esc_html_e( 'Medium Width + Sidebar', 'notumn' ); ?></label>
			</p>

			<p>
				<input type="radio" id="notumn-page-layout-m" name="notumn-page-layout"
				       value="medium" <?php checked( 'medium', $notumn_page_layout ); ?> style="margin-top: 1px;" >
				<label for="notumn-page-layout-m"><?php esc_html_e( 'Medium Width (No Sidebar)', 'notumn' ); ?></label>
			</p>

			<p>
				<input type="radio" id="notumn-page-layout-f" name="notumn-page-layout"
				       value="fullwidth" <?php checked( 'fullwidth', $notumn_page_layout ); ?> style="margin-top: 1px;" >
				<label for="notumn-page-layout-f"><?php esc_html_e( 'Full Width (No Sidebar)', 'notumn' ); ?></label>
			</p>
			<?php
		}
	}

	Notumn_post_metaboxes::instance();
}
