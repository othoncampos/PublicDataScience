<?php
/**
 * Class Name: Notumn_Walker_Comment
 *
 * @package notumn
 * @since 1.0
 */
class Notumn_Walker_Comment extends Walker_Comment {
	/**
	 * Starts the list before the elements are added.
	 *
	 * @since 2.7.0
	 * @access public
	 *
	 * @see Walker::start_lvl()
	 * @global int $comment_depth
	 *
	 * @param string $output Passed by reference. Used to append additional content.
	 * @param int    $depth  Optional. Depth of the current comment. Default 0.
	 * @param array  $args   Optional. Uses 'style' argument for type of HTML list. Default empty array.
	 */
	public function start_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 1;
	}

	/**
	 * Ends the list of items after the elements are added.
	 *
	 * @since 2.7.0
	 * @access public
	 *
	 * @see Walker::end_lvl()
	 * @global int $comment_depth
	 *
	 * @param string $output Passed by reference. Used to append additional content.
	 * @param int    $depth  Optional. Depth of the current comment. Default 0.
	 * @param array  $args   Optional. Will only append content if style argument value is 'ol' or 'ul'.
	 *                       Default empty array.
	 */
	public function end_lvl( &$output, $depth = 0, $args = array() ) {
		$GLOBALS['comment_depth'] = $depth + 1;
	}
}

/**
 * Callback function for wp_list_comments()
 */
function notumn_comments( $comment, $args, $depth ) {
	$comment_reply_args = array_merge( $args, array(
		'depth'     => $depth,
		'max_depth' => $args['max_depth'],
		'before'    => '<span class="separator">—</span>',
	) );

	if ( $depth === 1 ) : ?>
		<li <?php comment_class( array( 'media', 'comment-item' ) ); ?> id="comment-<?php comment_ID(); ?>" ><?php
	else : ?>
		<div <?php comment_class( array( 'media', 'comment-item' ) ); ?> id="comment-<?php comment_ID(); ?>" ><?php
	endif; ?>

	<a href="#" class="pull-left">
		<?php echo wp_kses_post( get_avatar( $comment, 80, '', '', array( 'class' => array( 'comment-avatar', 'img-circle' ) ) ) ); ?>
	</a>
	<div class="media-body">
	<div class="comment-item-data">
		<span class="comment-author font-2"><?php echo wp_kses_post( get_comment_author_link() ); ?></span>
		<span class="comment-date" title="<?php
		echo esc_attr( sprintf( __( '%1$s at %2$s', 'notumn' ), get_comment_date(), get_comment_time() ) ); ?>">
		<?php esc_html_e( sprintf( human_time_diff( get_comment_time( 'U' ) ) . ' %s', __( 'ago', 'notumn' ) ) ); ?></span>
		<?php comment_reply_link( $comment_reply_args, $comment->comment_ID ); ?>
		<?php edit_comment_link( sprintf( '<i class="fa fa-edit"></i> %s', esc_html__( 'Edit', 'notumn' ) ), '<span class="separator">—</span>' ); ?>
	</div>
	<?php if ( ! $comment->comment_approved ) : ?>
		<em><i class="fa fa-info-circle"></i> <?php esc_html_e( 'Comment awaiting approval', 'notumn' ); ?></em>
		<br/>
	<?php endif; ?>
	<?php comment_text();
}

/**
 * Callback function for wp_list_comments()
 *
 * @param string $comment
 * @param array $args
 * @param integer $depth
 */
function notumn_end_comments( $comment, $args, $depth ) {
	?>
	</div>
	<?php
	if ( $depth === 0 ): ?>
            </li>
    <?php else: ?>
        </div>
    <?php endif;
}

/**
 * Move textarea comment field to the bottom
 *
 * @param array $fields comment fields.
 *
 * @return mixed
 */
function notumn_comment_field_adjust( $fields ) {
	$comment_field = $fields['comment'];
	unset( $fields['comment'] );
	$fields['comment'] = $comment_field;

	return $fields;
}
add_filter( 'comment_form_fields', 'notumn_comment_field_adjust' );
