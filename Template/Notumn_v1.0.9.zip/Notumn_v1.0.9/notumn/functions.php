<?php
define( 'NOTUMN_VER', '1.0.8' );

/**
 * Global Content width
 */
if ( ! isset( $content_width ) ) {
	$content_width = 870;
}

/**
 * Load Needed Files
 */
require_once get_template_directory() . '/customizer/class-notumn-custom-controller.php';
require_once get_template_directory() . '/customizer/customizer_settings.php';
require_once get_template_directory() . '/customizer/customizer_styles.php';
require_once get_template_directory() . '/includes/classes/class-notumn-metaboxes.php';
require_once get_template_directory() . '/includes/classes/class-notumn-featured-post.php';
require_once get_template_directory() . '/includes/classes/class-notumn-comments.php';
require_once get_template_directory() . '/includes/classes/class-notumn-walker-nav-menu.php';
require_once get_template_directory() . '/includes/classes/class-notumn-typography.php';
require_once get_template_directory() . '/includes/functions/notumn_responsive_images.php';
require_once get_template_directory() . '/includes/functions/notumn_required_plugins.php';

if( version_compare( PHP_VERSION, '5.4.0', '>=' ) ){
	require_once get_template_directory() . '/includes/vendors/DiDom/Document.php';
	require_once get_template_directory() . '/includes/vendors/DiDom/Element.php';
	require_once get_template_directory() . '/includes/vendors/DiDom/Errors.php';
	require_once get_template_directory() . '/includes/vendors/DiDom/Query.php';
}

/**
 * Theme Initialization and Support
 */
if ( ! function_exists( 'notumn_theme_setup' ) ) {
	function notumn_theme_setup() {

		// Title Tag Support.
		add_theme_support( 'title-tag' );

		// WP Thumbnails.
		add_theme_support( 'post-thumbnails' );

		// Localization support.
		load_theme_textdomain( 'notumn', get_template_directory() . '/languages' );

		// Thumbnail Sizes.
		add_image_size( 'notumn_lg_featured_thumb', 870, 580, true );
		add_image_size( 'notumn_lg_full_thumb',     870,   0, true );
		add_image_size( 'notumn_carousel_thumb',    690, 460, true );
		add_image_size( 'notumn_featured_thumb',    670, 447, true );
		add_image_size( 'notumn_full_thumb',        670,   0, true );
		add_image_size( 'notumn_grid_thumb',        345, 230, true );
		add_image_size( 'notumn_small_thumb',       100,  66, true );

		// Post Formats Support.
		add_theme_support( 'post-formats', array( 'gallery', 'video', 'audio' ) );

		// Selective Refresh Support.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Feed Links.
		add_theme_support( 'automatic-feed-links' );

		// Gutenberg.
		add_theme_support( 'align-wide' );
		add_theme_support( 'editor-styles' );
		add_editor_style( 'editor-style.css' );

		// Register theme Menu Locations.
		register_nav_menus( array(
			'main_menu' => 'Primary Menu',
		) );
	}
	add_action( 'after_setup_theme', 'notumn_theme_setup' );
}

/**
 * Admin Media Images Size Names.
 */
if ( ! function_exists( 'notumn_admin_media_sizes' ) ) {

	function notumn_admin_media_sizes( $sizes ) {

		return array_merge( $sizes, array(
			'notumn_small_thumb'       => esc_html__( 'Small Thumb', 'notumn' ),
			'notumn_grid_thumb'        => esc_html__( 'Grid Thumb', 'notumn' ),
			'notumn_featured_thumb'    => esc_html__( 'Full (cropped)', 'notumn' ),
			'notumn_full_thumb'        => esc_html__( 'Full (no crop)', 'notumn' ),
			'notumn_carousel_thumb'    => esc_html__( 'Carousel Thumb', 'notumn' ),
			'notumn_lg_featured_thumb' => esc_html__( 'Fullwidth (cropped)', 'notumn' ),
			'notumn_lg_full_thumb'     => esc_html__( 'Fullwidth (no crop)', 'notumn' ),
		) );
	}

	add_filter( 'image_size_names_choose', 'notumn_admin_media_sizes' );
}

/**
 * Enqueue Scripts & Styles
 */
if ( ! function_exists( 'notumn_enqueue_scripts' ) ) {
	function notumn_enqueue_scripts() {
		$enable_light_gallery = get_theme_mod( 'notumn_lg_enable', true );

		// Register Scripts.
		wp_register_script( 'bootstrap-js', get_template_directory_uri() . '/js/bootstrap.min.js',
			array( 'jquery' ), '3.3.6', true );
		wp_register_script( 'retina-js', get_template_directory_uri() . '/js/retina.min.js',
			array(), '1.3.0', true );
		wp_register_script( 'owlcarousel-js', get_template_directory_uri() . '/js/owl.carousel.min.js',
			array( 'jquery' ), '1.3.2', true );
		wp_register_script( 'fitvids-js', get_template_directory_uri() . '/js/jquery.fitvids.js',
			array( 'jquery' ), '1.1', true );
		wp_register_script( 'lazysizes-js', get_template_directory_uri() . '/js/lazysizes.min.js',
			array(), '2.0.0', true );
		wp_register_script( 'light-gallery-js', get_template_directory_uri() . '/js/lightgallery-all.min.js',
			array( 'jquery' ), '1.2.19', true );
		wp_register_script( 'notumn-js', get_template_directory_uri() . '/js/script.js',
			array( 'jquery', 'bootstrap-js', 'owlcarousel-js' ), NOTUMN_VER, true );

		// Localize scripts.
		wp_localize_script( 'notumn-js', 'featCarouselSettings', notumn_featured_carousel_settings() );
		wp_localize_script( 'notumn-js', 'lightGalleryData', notumn_light_gallery_settings() );

		// Conditional lt IE 9 Scripts.
		wp_register_script( 'html5shiv', '//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js' );
		wp_script_add_data( 'html5shiv', 'conditional', 'lt IE 9' );
		wp_register_script( 'respond', '//oss.maxcdn.com/respond/1.4.2/respond.min.js' );
		wp_script_add_data( 'respond', 'conditional', 'lt IE 9' );

		// Enqueue Scripts.
		wp_enqueue_script( 'bootstrap-js' );
		wp_enqueue_script( 'retina-js' );
		wp_enqueue_script( 'owlcarousel-js' );
		wp_enqueue_script( 'fitvids-js' );
		wp_enqueue_script( 'lazysizes-js' );
		if ( $enable_light_gallery ) {
			wp_enqueue_script( 'light-gallery-js' );
		}
		wp_enqueue_script( 'notumn-js' );
		wp_enqueue_script( 'html5shiv' );
		wp_enqueue_script( 'respond' );

		// Register Font Styles.
		$fonts = Notumn_typography::get_fonts();
		wp_register_style( 'notumn-fonts', $fonts[0] );

		// Register Styles.
		wp_register_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.css', array(), '3.3.6' );
		wp_register_style( 'fontawesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '4.6.3' );
		wp_register_style( 'owlcarousel', get_template_directory_uri() . '/css/owl.carousel.css', array(), '1.3.2' );
		wp_register_style( 'owlcarousel-theme', get_template_directory_uri() . '/css/owl.theme.css',
			array( 'owlcarousel' ), '1.3.2' );
		wp_register_style( 'owlcarousel-transitions', get_template_directory_uri() . '/css/owl.transitions.css',
			array( 'owlcarousel', 'owlcarousel-theme' ), '1.3.2' );
		wp_register_style( 'google-font', '//fonts.googleapis.com/css?family=Open+Sans', array(), null );
		wp_register_style( 'light-gallery', get_template_directory_uri() . '/css/lightgallery.min.css', array(), '1.2.19' );
		wp_register_style( 'light-gallery-transitions', get_template_directory_uri() . '/css/lg-transitions.min.css',
			array(), '1.2.19' );
		wp_register_style( 'notumn', get_template_directory_uri() . '/style.css',
			array( 'bootstrap', 'fontawesome', 'owlcarousel', 'owlcarousel-theme', 'owlcarousel-transitions' ), NOTUMN_VER );
		wp_register_style( 'notumn-responsive-styles', get_template_directory_uri() . '/css/notumn-responsive-styles.css',
			array( 'notumn' ), NOTUMN_VER );
		wp_add_inline_style( 'notumn', $fonts[1] );

		// Enqueue Syles.
		wp_enqueue_style( 'google-font' );
		wp_enqueue_style( 'notumn-fonts' );
		wp_enqueue_style( 'bootstrap' );
		wp_enqueue_style( 'fontawesome' );
		wp_enqueue_style( 'owlcarousel' );
		wp_enqueue_style( 'owlcarousel-theme' );
		wp_enqueue_style( 'owlcarousel-transitions' );
		if( $enable_light_gallery ){
			wp_enqueue_style( 'light-gallery' );
			wp_enqueue_style( 'light-gallery-transitions' ); }
		wp_enqueue_style( 'notumn' );
		wp_enqueue_style( 'notumn-responsive-styles' );
	}
	add_action( 'wp_enqueue_scripts', 'notumn_enqueue_scripts' );
}

/**
 * Notumn Main Menu Generator
 */
if ( ! function_exists( 'notumn_main_menu' ) ) {
	function notumn_main_menu() {
		if ( has_nav_menu( 'main_menu' ) ) {

			$args = array(
				'theme_location' => 'main_menu',
				'container'      => false,
				'menu_class'     => 'left-nav clearlist',
				'walker'         => new Notumn_Walker_Nav_Menu(),
			);

			wp_nav_menu( $args );
		}
	}
}

/**
 * Featured Carousel Settings
 */
if ( ! function_exists( 'notumn_featured_carousel_settings' ) ) {
	function notumn_featured_carousel_settings() {

		if ( ! is_home() ) {

			if ( get_theme_mod( 'notumn_static_carousel_autoplay', false ) ) {

				return array(
					'autoPlay' => (integer) get_theme_mod( 'notumn_static_carousel_autoplay_speed', '3000' ),
				);
			}

		} else {

			if ( get_theme_mod( 'notumn_carousel_autoplay', false ) ) {

				return array(
					'autoPlay' => (integer) get_theme_mod( 'notumn_carousel_autoplay_speed', '3000' ),
				);
			}
		}


		return array();
	}
}

/**
 * Light Gallery Settings
 */
if ( ! function_exists( 'notumn_light_gallery_settings' )) {
	function notumn_light_gallery_settings() {

		$lg_mode       = (string) get_theme_mod( 'notumn_lg_transition', 'lg-slide' );
		$lg_speed      = (integer) get_theme_mod( 'notumn_lg_trans_duration', '700' );
		$lg_download   = (bool) get_theme_mod( 'notumn_lg_down_btn', true );
		$lg_thumbnail  = (bool) get_theme_mod( 'notumn_lg_thumbnails', true );
		$lg_autoplay   = (bool) get_theme_mod( 'notumn_lg_autoplay', true );
		$lg_pause      = (integer) get_theme_mod( 'notumn_lg_pause', '4500' );
		$lg_zoom       = (bool) get_theme_mod( 'notumn_lg_zoom', true );
		$lg_actualsize = (bool) get_theme_mod( 'notumn_lg_actualsize', true );

		return array(
			'settings' => array(
				'mode'       => $lg_mode,
				'speed'      => $lg_speed,
				'thumbnail'  => $lg_thumbnail,
				'download'   => $lg_download,
				'autoplay'   => $lg_autoplay,
				'pause'      => $lg_pause,
				'zoom'       => $lg_zoom,
				'actualSize' => $lg_actualsize,
			),
		);
	}
}

/**
 * Filters wp_title to print a neat <title> tag
 * based on what is being viewed.
 */
if ( ! function_exists( 'notumn_wp_title' ) ) {
	function notumn_wp_title( $title, $sep ) {
		global $page, $paged;

		if ( is_feed() ) {
			return $title;
		}

		// Add the blog name.
		$title .= get_bloginfo( 'name', 'display' );

		// Add the blog description for the home/front page.
		$site_description = get_bloginfo( 'description', 'display' );
		if ( $site_description && ( is_home() || is_front_page() ) ) {
			$title .= " $sep $site_description";
		}

		// Add a page number if necessary.
		if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
			$title = esc_html( sprintf( __( 'Page %s', 'notumn' ), max( $paged, $page ) ) . " {$sep} $title" );
		}

		return $title;
	}

	add_filter( 'wp_title', 'notumn_wp_title', 10, 2 );
}

/**
 * The Content Read More Link
 */
if ( ! function_exists( 'notumn_read_more' ) ) {
	function notumn_read_more() {
		return '<div class="read-more font-2"><a href="'. esc_url( get_the_permalink() ) .'">'. esc_html__( 'Continue Reading', 'notumn' ) .'</a></div>';
	}
	add_filter( 'the_content_more_link', 'notumn_read_more' );
}

/**
 * The Excerpt Read More Link
 */
if ( ! function_exists( 'notumn_excerpt_more' ) ) {
	function notumn_excerpt_more( $more ) {
		return ' <span><a class="read-more" href="' . esc_url( get_permalink( get_the_ID() ) ) . '">' . esc_html__( 'Read More', 'notumn' ) . '</a></span>';
	}

	add_filter( 'excerpt_more', 'notumn_excerpt_more' );
}

/**
 * Custom Excerpt Length.
 */
if ( ! function_exists( 'notumn_custom_excerpt_length' ) ) {
	function notumn_custom_excerpt_length( $length ) {
		return 22;
	}
	add_filter( 'excerpt_length', 'notumn_custom_excerpt_length', 999 );
}

/**
 * Register Sidebars and widgetized areas.
 */
if ( ! function_exists( 'notumn_register_widget_areas' ) ) {

	function notumn_register_widget_areas() {

		register_sidebar( array(
			'name'          => 'Home / Blog page Sidebar',
			'id'            => 'homepage_sidebar',
			'description'   => esc_html__( 'This Sidebar is only displayed on Home / Blog page.', 'notumn' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );

		register_sidebar( array(
			'name'          => 'Static Front Page Sidebar',
			'id'            => 'static_front_sidebar',
			'description'   => esc_html__( 'This Sidebar is only displayed on static front page.', 'notumn' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );

		register_sidebar( array(
			'name'          => 'Posts Sidebar',
			'id'            => 'posts_sidebar',
			'description'   => esc_html__( 'This Sidebar is displayed on Posts and Pages.', 'notumn' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );

		register_sidebar( array(
			'name'          => 'Archive Sidebar',
			'id'            => 'archive_sidebar',
			'description'   => esc_html__( 'This Sidebar is displayed on Archive Pages', 'notumn' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );

		register_sidebar( array(
			'name'          => 'Footer 1',
			'id'            => 'footer_1',
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );

		register_sidebar( array(
			'name'          => 'Footer 2',
			'id'            => 'footer_2',
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );

		register_sidebar( array(
			'name'          => 'Footer 3',
			'id'            => 'footer_3',
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );
		
		register_sidebar( array(
			'name'          => 'Instagram Footer',
			'id'            => 'instagram_footer',
			'description'   => esc_html__( 'Drag the Instagram widget here. NOTE: For best results please set number of photos to 8.', 'notumn' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );
	}

	add_action( 'widgets_init', 'notumn_register_widget_areas' );
}

/**
 * Posts Navigation Links.
 */
if ( ! function_exists( 'notumn_posts_link_attr' ) ) {
	function notumn_posts_link_attr() {
		return 'class="font-2"';
	}
	add_filter( 'next_posts_link_attributes', 'notumn_posts_link_attr' );
	add_filter( 'previous_posts_link_attributes', 'notumn_posts_link_attr' );
}

/**
 * Post Navigation Links.
 */
if ( ! function_exists( 'notumn_post_link_attr' ) ) {

	function notumn_post_link_attr( $link ) {
		$link = str_replace( '<a href=', '<a class="font-2" href=',  $link );
		return $link;
	}
	add_filter( 'next_post_link', 'notumn_post_link_attr' );
	add_filter( 'previous_post_link', 'notumn_post_link_attr' );
}

/**
 * Notumn Post Likes.
 */
if ( ! function_exists( 'notumn_likes' ) ) {
	function notumn_likes() {
		if ( function_exists( 'zilla_likes' ) ) {
			global $zilla_likes;
			echo wp_kses_post( $zilla_likes->do_likes() );
		}
	}
}

/**
 * Notumn Sharing Links.
 */
if ( ! function_exists( 'notumn_sharing_links' ) ) {
	function notumn_sharing_links( $post_id ) {
		global $notumn_functionality;

		if( isset( $notumn_functionality ) ){
			Notumn_social_links::notumn_sharing_links( $post_id );
		}
	}
}

/**
 * Notumn Social Links.
 */
if ( ! function_exists( 'notumn_social_links' ) ) {
	function notumn_social_links() {
		global $notumn_functionality;

		if( isset( $notumn_functionality ) ){
			return Notumn_social_links::get_social_links();
		}

		return array();
	}
}

/**
 * Head Featured Image Meta.
 */
if ( ! function_exists( 'notumn_featured_img_meta' ) ) {
	function notumn_featured_img_meta() {
		if ( ( is_single() ) && ( ! class_exists( 'WPSEO_Admin' ) ) ) {
			if ( has_post_thumbnail() ) {
				global $post;
				$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
				echo '<meta property="og:image" content="' . esc_url( $featured_image[0] ) . '">', "\n";
				echo '<meta property="og:image:width" content="'. esc_attr( $featured_image[1] ) .'" />', "\n";
				echo '<meta property="og:image:height" content="'. esc_attr( $featured_image[2] ) .'" />', "\n";
			}
		}
	}
	add_action( 'wp_head', 'notumn_featured_img_meta' );
}

/**
 * Available Image Sizes.
 */
if( ! function_exists( 'notumn_available_img_sizes' ) ){
	function notumn_available_img_sizes() {
		global $_wp_additional_image_sizes;
		$img_sizes = $_wp_additional_image_sizes;
		$default_sizes = array( 'thumbnail', 'medium', 'medium_large', 'large', 'full' );

		foreach ( $default_sizes as $default_size ) {
			$img_sizes[ $default_size ] = array(
				'width' => get_option( $default_size . '_size_w' ),
				'height' => get_option( $default_size . '_size_h' ),
			);
		}

		return $img_sizes;
	}
}

/**
 * Notumn Video Post oembed
 */
if ( ! function_exists( 'notumn_oembed_video' ) ) {
	function notumn_oembed_video( $post_id ) {
		$notumn_video_embed = get_post_meta( $post_id, '_format_video_embed', true );

		if ( wp_oembed_get( $notumn_video_embed ) ) {
			$notumn_video_embed = wp_oembed_get( $notumn_video_embed, array( 'width' => 'auto' ) );
		}

		return $notumn_video_embed;
	}
}

/**
 * Notumn Audio Post oembed
 */
if ( ! function_exists( 'notumn_oembed_audio' ) ) {
	function notumn_oembed_audio( $post_id ) {
		$notumn_audio_embed = get_post_meta( $post_id, '_format_audio_embed', true );

		if ( wp_oembed_get( $notumn_audio_embed ) ) {
			$notumn_audio_embed = wp_oembed_get( $notumn_audio_embed, array( 'width' => 'auto' ) );
		}

		return $notumn_audio_embed;
	}
}

/**
 * Body Class Filter
 */
if ( ! function_exists( 'notumn_body_class' ) ) {
	function notumn_body_class( $classes ) {
		$new_classes[] = get_theme_mod( 'notumn_theme_style', 'lite-theme' );
		return array_merge( $classes, $new_classes );
	}

	add_filter( 'body_class', 'notumn_body_class' );
}

/**
 * Google Anaytics Integration
 */
if( ! function_exists( 'notumn_google_analytics' ) ){

	function notumn_google_analytics() {

		$analytics_id = get_theme_mod( 'notumn_google_analytics_id', '' );

		if ( empty( $analytics_id ) ) {
			return;
		}

		ob_start(); ?>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', '<?php echo $analytics_id; ?>', 'auto');
ga('send', 'pageview');
		<?php
		$analytics_tracking_code = ob_get_clean();
		wp_add_inline_script( 'notumn-js', $analytics_tracking_code );
	}

	add_action( 'wp_enqueue_scripts', 'notumn_google_analytics', 99 );
}

/**
 * Get Theme Accent Color.
 */
if ( ! function_exists( 'notumn_get_theme_color' ) ) {
	function notumn_get_theme_color() {
		return sanitize_hex_color( get_theme_mod( 'notumn_accent_color', '#d0b48b' ) );
	}
}
