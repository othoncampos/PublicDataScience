<?php
/**
 * Search Template.
 *
 * @package notumn
 * @since 1.0
 */

$notumn_archive_layout  = get_theme_mod( 'notumn_archive_layout', 'list_sidebar' );
$notumn_archive_sidebar = ( preg_match( '/sidebar/', $notumn_archive_layout ) ) ? true : false;
$notumn_archive_layout  = explode( '_', $notumn_archive_layout );
$notumn_archive_layout  = $notumn_archive_layout[0];
$notumn_container_lg    = array( 'list', 'fullwidth', 'grid' );

get_header();

if ( in_array( $notumn_archive_layout, $notumn_container_lg, true ) ) : ?>
<div class="container container-lg">
<?php else : ?>
<div class="container">
<?php endif; ?>

	<div class="row">
		<?php if ( $notumn_archive_layout === 'grid' || $notumn_archive_sidebar ) : ?>
		<div class="col-md-12">
		<?php elseif ( $notumn_archive_layout === 'fullwidth' ) : ?>
		<div class="col-md-10 col-md-push-1">
		<?php elseif ( $notumn_archive_layout === 'full' ) : ?>
		<div class="col-md-8 col-md-push-2">
		<?php endif; ?>
			<div class="archive-box font-2 <?php echo sanitize_html_class( ( $notumn_archive_layout === 'full' ) ? 'stretch' : '' ); ?> ">
				<div class="sub-heading"><?php esc_html_e( 'Search results for', 'notumn' ); ?></div>
				<h1 class="heading"><?php the_search_query(); ?></h1>
			</div>
		</div><!-- .column -->
	</div><!-- .row -->

	<div class="row">

	<?php if ( $notumn_archive_layout === 'grid' && ! $notumn_archive_sidebar ) : ?>
	<div class="col-md-12">
	<?php elseif ( $notumn_archive_layout === 'fullwidth' ) : ?>
	<div class="col-md-10 col-md-push-1">
	<?php else : ?>
	<div class="col-md-8 <?php echo sanitize_html_class( ($notumn_archive_sidebar)? 'posts-column' : 'col-md-push-2' ) ?>">
	<?php endif; ?>

	<div class="posts-container relative">

		<?php if ( have_posts() ) : ?>

			<?php if ( $notumn_archive_layout === 'grid' ) : ?>
				<div class="row">
			<?php endif; ?>

			<?php while ( have_posts() ) : the_post();
				get_template_part( 'content', $notumn_archive_layout );
			endwhile; ?>

			<?php if ( $notumn_archive_layout === 'grid' ) : ?>
				</div>
			<?php endif; ?>

		<?php else : ?>

			<div class="no-posts bs-callout bs-callout-warning">
				<h4><?php esc_html_e( 'No Results Found', 'notumn' ); ?></h4>
				<p><?php esc_html_e( 'Sorry, but no posts matched your query. Please check your spelling or try again with different keywords.', 'notumn' ); ?></p>
			</div>

		<?php endif; ?>

	</div><!-- .posts-container -->

<?php get_template_part( 'includes/templates/blog_pagination' ); ?>

	</div><!-- .posts-column -->

<?php if ( $notumn_archive_sidebar ) {
	get_sidebar( 'archive' );
} ?>

	</div><!-- .row -->
</div><!-- .container -->

<?php
get_footer();
