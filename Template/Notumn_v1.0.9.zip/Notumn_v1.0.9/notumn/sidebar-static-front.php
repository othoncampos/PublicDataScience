<?php
/**
 * Static Front Page Sidebar.
 *
 * @package notumn
 * @since 1.0.7
 */

?>
<div class="col-md-4 sidebar-column">
	<!-- Sidebar - Widget Area -->
	<aside class="sidebar widget-area font-2">
		<?php if ( is_active_sidebar( 'static_front_sidebar' ) ) { dynamic_sidebar( 'static_front_sidebar' ); }?>
	</aside><!-- End Sidebar - Widget Area -->
</div><!-- .sidebar-column -->
