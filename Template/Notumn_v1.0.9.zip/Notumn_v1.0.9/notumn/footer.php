<?php
/**
 * Footer file.
 *
 * @package notumn
 * @since 1.0
 */

?>
	<!-- Site Footer -->
	<footer id="footer" class="footer <?php
	if ( is_active_sidebar( 'footer_1' )
	     || is_active_sidebar( 'footer_2' )
	     || is_active_sidebar( 'footer_3' )
	     || ( get_theme_mod( 'notumn_theme_style', 'lite-theme' ) === 'dark-theme' )
	     || is_active_sidebar( 'instagram_footer' ) ) { echo sanitize_html_class( 'top-border-margin' ); } ?>">

		<?php if ( ! is_404() ) : ?>
		<div id="instagram-footer" class="font-2">
		<?php if ( is_active_sidebar( 'instagram_footer' ) ) { dynamic_sidebar( 'instagram_footer' ); } ?>
		</div>
		<?php endif; ?>

		<div class="container container-lg">

			<div class="row font-2 footer-widgets">

				<div class="col-md-4">
					<?php if ( is_active_sidebar( 'footer_1' ) ) { dynamic_sidebar( 'footer_1' ); }?>
				</div><!-- .column -->
				<div class="col-md-4">
					<?php if ( is_active_sidebar( 'footer_2' ) ) { dynamic_sidebar( 'footer_2' ); }?>
				</div><!-- .column -->
				<div class="col-md-4">
					<?php if ( is_active_sidebar( 'footer_3' ) ) { dynamic_sidebar( 'footer_3' ); }?>
				</div><!-- .column -->

			</div><!-- .footer-widgets -->

			<div class="footer-box">

				<div class="footer-logo">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php
						echo esc_url( get_theme_mod( 'notumn_footer_logo', get_template_directory_uri() . '/img/logo-dark.png' ) ); ?>"
							alt="<?php bloginfo( 'name' ); ?>" width="280" height="62"></a>
				</div><!-- .footer-logo -->

				<ul class="footer-social-links clearlist">
					<?php get_template_part( 'includes/templates/notumn_social_links' ); ?>
				</ul><!-- .footer-social-links -->

			</div><!-- .footer-box -->

			<div class="footer-text">
				<?php
					$notumn_footer_anchor_text = get_theme_mod( 'notumn_footer_anchor_text', '© Copyright Notumn ' . date('Y') );
					$notumn_footer_anchor_url  = get_theme_mod( 'notumn_footer_anchor_url', 'http://decaxstudios.com/notumn/' );
					$notumn_footer_right_text  = get_theme_mod( 'notumn_footer_right_text', 'All Rights Reserved.' );
				?>
				<div class="footer-copyright">
					<a href="<?php echo esc_url( $notumn_footer_anchor_url ); ?>" target="_blank"><?php
						echo esc_html( $notumn_footer_anchor_text ); ?></a>
				</div><!-- .footer-copyright -->

				<div class="footer-rights">
					<?php echo esc_html( $notumn_footer_right_text ); ?>
				</div><!-- .footer-rights -->

			</div><!-- .footer-text -->

		</div><!-- .contaienr -->

		<a href="#top" class="link-to-top page-scroll"><i class="fa fa-angle-up"></i></a>

	</footer><!-- End Site Footer -->

	</div><!-- End Page Wrap -->

	<?php wp_footer(); ?>
	
</body>
</html>
