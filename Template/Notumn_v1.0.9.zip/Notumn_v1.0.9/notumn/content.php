<?php
/**
 * Content
 *
 * @package notumn
 * @since 1.0
 */

// Get Notumn Image Size: Full (no crop) or Standard (cropped).
$notumn_img_size = get_post_meta( $post->ID, '_notumn-img-size', true );
if ( empty( $notumn_img_size ) ) {
	$notumn_img_size = 'standard';
}

$notumn_entry_class = $notumn_img_size;

if( is_single() ){

	$notumn_post_layout = get_post_meta( $post->ID, '_notumn-post-layout', true );

	if ( empty( $notumn_post_layout ) ) {
		$notumn_post_layout = 'medium_sidebar';
	}

	// Find actual img size basing on post layout and $notumn_img_size.
	if ( $notumn_img_size === 'standard' ) {

		$notumn_img_size = in_array( $notumn_post_layout, array(
			'medium_sidebar',
			'medium',
		), true ) ? 'notumn_featured_thumb' : 'notumn_lg_featured_thumb';

	} elseif ( $notumn_img_size === 'full' ) {

		$notumn_img_size = in_array( $notumn_post_layout, array(
			'medium_sidebar',
			'medium',
		), true ) ? 'notumn_full_thumb' : 'notumn_lg_full_thumb';

	}
} else {
	$notumn_home_layout = get_theme_mod( 'notumn_homepage_layout', 'fullwidth' );

	// Find actual img size basing on home layout and $notumn_img_size.
	if ( $notumn_img_size === 'standard' ) {

		$notumn_img_size = in_array( $notumn_home_layout, array(
			'full',
			'full_sidebar',
		), true ) ? 'notumn_featured_thumb' : 'notumn_lg_featured_thumb';

	} elseif ( $notumn_img_size === 'full' ) {

		$notumn_img_size = in_array( $notumn_home_layout, array(
			'full',
			'full_sidebar',
		), true ) ? 'notumn_full_thumb' : 'notumn_lg_full_thumb';

	}
}

if ( get_theme_mod( 'notumn_lg_enable', true ) ) :
	wp_add_inline_script( 'notumn-js', notumn_light_gallery_images( $post->ID ) );
endif;

if ( isset( $notumn_post_layout ) ) {
	$post_classes = array( 'relative', 'notumn_' . $notumn_post_layout );
} else {
	$post_classes = array( 'relative' );
}

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $post_classes ); ?>>

	<header class="entry-header">
		<div class="entry-category font-2"><?php the_category( '' ); ?></div>
		<h1 class="entry-title font-2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
		<div class="entry-date font-3" title="<?php the_time( 'Y-m-d H:i:s' ); ?>"><?php esc_html_e( 'Posted on', 'notumn' ); ?>
			<span class="date published"><?php
				$notumn_post_title = get_the_title();
				if ( ! is_single() && empty( $notumn_post_title ) ) : ?>
					<a href="<?php the_permalink() ?>"><?php the_time( get_option( 'date_format' ) ); ?></a>
				<?php else :
					the_time( get_option( 'date_format' ) );
				endif; ?>
			</span>
            <span class="date updated hidden"><?php the_modified_date( get_option( 'date_format' ) ); ?></span>
		</div>
		<?php if ( is_sticky() && is_home() && ! is_paged() ) : ?>
		<div class="sticky-tag font-2"><span><?php esc_html_e( 'Sticky', 'notumn' ); ?></span></div>
		<?php endif; ?>
	</header><!-- .entry header -->

	<?php
	$notumn_author_posts_url = get_author_posts_url( get_the_author_meta( 'ID' ) );

	if ( has_post_format( 'gallery' ) ) :

		$notumn_gallery_images = get_post_meta( $post->ID, '_format_gallery_images', true );

		if ( $notumn_gallery_images ) : ?>
			<div class="gallery-entry owl-carousel <?php echo sanitize_html_class( $notumn_entry_class ); ?>">

			<?php foreach ( $notumn_gallery_images as $notumn_gallery_image ) : ?>
				<div class="entry-image">
					<a href="<?php echo esc_url( wp_get_attachment_url( $notumn_gallery_image ) ); ?>">
						<?php notumn_attachment_image( $notumn_gallery_image, $notumn_img_size ); ?>
					</a>
				</div><!-- .entry-image -->
			<?php endforeach; ?>

			</div><!-- .gallery-entry -->
		<?php endif;

	elseif ( has_post_format( 'video' ) ) : ?>

		<div class="entry-image">
			<?php echo notumn_oembed_video( $post->ID ); ?>
		</div>

	<?php elseif ( has_post_format( 'audio' ) ) : ?>

		<div class="entry-image">
			<?php echo notumn_oembed_audio( $post->ID ); ?>
		</div>

	<?php else : ?>

		<?php if ( has_post_thumbnail() ) : ?>
			<div class="entry-image <?php echo sanitize_html_class( $notumn_entry_class ); ?>">
				<a href="<?php echo esc_url(
				is_single() ? wp_get_attachment_url( get_post_thumbnail_id() ) : get_the_permalink() ); ?>"><?php
					notumn_entry_image( $post->ID, $notumn_img_size ); ?>
				</a>
			</div><!-- .entry-image -->
		<?php endif;

	endif; ?>

	<div class="entry-content">
		<?php the_content(); ?>
		<?php wp_link_pages(); ?>
	</div><!-- .entry-content -->

	<div class="entry-meta-box font-2 clearfix">
		<?php if ( is_single() ) : ?>
			<div class="entry-author-name vcard author post-author">
				<a href="<?php echo esc_url( $notumn_author_posts_url ); ?>"><?php esc_html_e( 'By ', 'notumn' );
					?><span class="fn"><?php the_author(); ?></span></a>
			</div>
		<?php else : ?>
			<div class="entry-comments">
				<?php if ( defined( 'DISQUS_DOMAIN' ) ) : ?>
					<a class="disqus-link" href="<?php echo esc_url( get_the_permalink() . '#disqus_thread' ); ?>"></a>
				<?php else : ?>
					<a href="<?php echo esc_url( get_comments_link() ); ?>"><i class="fa fa-comments"></i> <?php
						comments_number( '0 <span>' . esc_html__( 'comments', 'notumn' ) . '</span>',
							'1 <span>' . esc_html__( 'comment', 'notumn' ) . '</span>',
							'% <span>' . esc_html__( 'comments', 'notumn' ) . '</span>' ); ?></a>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<div class="entry-social-links">
			<?php notumn_sharing_links( $post->Id ); ?>
		</div>
		<div class="entry-likes"><?php notumn_likes(); ?></div>
	</div><!-- .entry-meta -->

<?php if ( is_single() ) : ?>

	<?php if ( has_tag() ) : ?>
	<div class="entry-tags">
		<?php the_tags( '', '' ) ?>
	</div><!-- .entry-tags -->
	<?php endif;

	if ( get_theme_mod( 'notumn_author_box', true ) ) {
		get_template_part( 'includes/templates/author_box' );
	}


	get_template_part( 'includes/templates/posts_pagination' );

	if ( get_theme_mod( 'notumn_related_posts', true ) ) {
		get_template_part( 'includes/templates/related_posts' );
	}

	comments_template( '', false ); ?>
<?php endif; ?>

</article>
