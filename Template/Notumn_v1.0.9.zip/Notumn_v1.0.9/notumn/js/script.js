(function($){
    'use strict';
    
    /* ---------------------------------------------
     Navigation
     --------------------------------------------- */
    var mainNav = $('.main-nav'),
        mobileNavBtn =  mainNav.find('.mobile-nav'),
        leftNav = mainNav.find('.left-nav');
    
    function init_mainMenu(){
        
        //Desktop Menu
        leftNav.find('.has-sub-mn').parent('li').hover(function(){
            
            if(!mainNav.hasClass('mobile-on')){
                $(this).find('.sub-mn:first').stop(true, true).fadeIn();
            }
            
        }, function(){
            
            if(!mainNav.hasClass('mobile-on')){
                $(this).find('.sub-mn:first').stop(true, true).fadeOut('fast');
                
                $(this).removeClass('js-opened');
            }
        });
        
        //Mobile Menu
        mobileNavBtn.click(function(){
            
            if($(this).hasClass('active')){
                $(this).removeClass('active');
                leftNav.slideUp();
            } else {
                $(this).addClass('active');
                leftNav.slideDown();
            }
            
        });
        
        // Sub Menu
        leftNav.find('.has-sub-mn+i').click(function(e){

            if(mainNav.hasClass('mobile-on')){
                
                if($(this).parent('li').hasClass('js-opened')){
                    
                    //Changle Arrow direction
                    $(this).parent('li').find(".fa-angle-up:first")
                        .removeClass('fa-angle-up')
                        .addClass('fa-angle-down');
                    
                    //Hide the submenu
                    $(this).parent('li').removeClass('js-opened');
                    $(this).siblings('ul.sub-mn').slideUp();
                    
                } else {
                    
                    //Changle Arrow direction
                    $(this).parent('li').find(".fa-angle-down:first")
                        .removeClass('fa-angle-down')
                        .addClass('fa-angle-up');
                    
                    //Show the submenu
                    $(this).parent('li').addClass('js-opened');
                    $(this).siblings('ul.sub-mn').slideDown();
                }
            }
            
        });
        
        //Search Form
        var searchNavBtn = mainNav.find('.search-nav'),
            searchContainer = mainNav.find('.search-container'),
            closeSearchBtn = searchContainer.find('.close-search');
        
        searchNavBtn.click(function(e){
            searchContainer.fadeIn();
        });
        
        closeSearchBtn.click(function(){
            searchContainer.fadeOut();
        });
    
    }
    
    function mainMenu_resize(){
        
        // Menu Max Height
        leftNav.css("max-height", viewport().height - 100 + "px");

        //Mobile Menu Toggle
        if(viewport().width <= 1024){
            mainNav.addClass('mobile-on');
            if( ! mobileNavBtn.hasClass( 'active' ) ) {
                leftNav.hide();
            }
            
            // Change Arrows Direction.
            leftNav.find('.has-sub-mn').each(function(){
                if( $(this).parent('li').hasClass('js-opened') ){
                    $(this).parent('li').find(".fa")
                        .removeClass("fa-angle-right fa-angle-down")
                        .addClass("fa-angle-up");
                } else {
                    $(this).parent('li').find(".fa")
                        .removeClass("fa-angle-right fa-angle-up")
                        .addClass("fa-angle-down");
                }
            });
            
        }else if(viewport().width > 1024) {
            mainNav.removeClass('mobile-on');
            mobileNavBtn.removeClass('active');
            leftNav.show();
               
            // Change Arrows Direction.
            leftNav.find('> li > .fa')
                .removeClass('fa-angle-right fa-angle-up')
                .addClass('fa-angle-down');
            leftNav.find('> li > ul .fa')
                    .removeClass('fa-angle-up fa-angle-down')
                    .addClass('fa-angle-right');
        }
    }
    
    function init_js_heights(){
        
        //Sets Child's height to parent
        $.each($('.js-height-child').children(), function(indx, ele){
            $(this).parent().height($(this).outerHeight());
        });
        
        $.each($('.js-height-inner-iframe'), function(indx, ele){
            $(this).height($(this).find('iframe').height());
        });
    }

    function viewport() {
        var e = window, a = 'inner';
        if (!('innerWidth' in window )) {
            a = 'client';
            e = document.documentElement || document.body;
        }
        return {width: e[a + 'Width'], height: e[a + 'Height']};
    }

    /* --------------------------------------------
     Platform detect
     --------------------------------------------- */
    if(/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)){
        $("html").addClass("mobile");
    }
    else {
        $("html").addClass("no-mobile");
    }
    
    /* ---------------------------------------------
     owl Carousel
     --------------------------------------------- */
    function init_owlCarousel(){
        
        var featCarousel = $.extend({
            items: 4,
            itemsDesktop: [4096, 4],
            itemsDesktopSmall: [1920, 3],
            itemsTablet: [980, 2],
            itemsTabletSmall: [568, 1],
            itemsMobile: [479, 1],
        }, featCarouselSettings);

        //Featured Carousel
        $('.featured-area.owl-carousel').owlCarousel(featCarousel);

        var featCarousel2 = $.extend({
            items: 1,
            itemsDesktop: [1199, 1],
            itemsDesktopSmall: [980, 1],
            itemsTablet: [768, 1],
            itemsTabletSmall: [568, 1],
            itemsMobile: [479, 1],
            navigation: true,
            navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"]
        }, featCarouselSettings);
        
        //Featured Carousel 2
        $('.featured-area-2.owl-carousel').owlCarousel(featCarousel2);

        //Gallery Post Carousel
        $('.gallery-entry.full.owl-carousel').owlCarousel({
            items: 1,
            itemsDesktop: [1199, 1],
            itemsDesktopSmall: [980, 1],
            itemsTablet: [768, 1],
            itemsTabletSmall: [568, 1],
            itemsMobile: [479, 1],
            navigation: true,
            autoHeight: true,
            navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"]
        });
        
        //Gallery Post Carousel 2
        $('.gallery-entry.standard.owl-carousel').owlCarousel({
            items: 1,
            itemsDesktop: [1199, 1],
            itemsDesktopSmall: [980, 1],
            itemsTablet: [768, 1],
            itemsTabletSmall: [568, 1],
            itemsMobile: [479, 1],
            navigation: true,
            autoHeight: true,
            autoPlay: 4000,
            navigationText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"]
        });
    }
    
    /* ---------------------------------------------
     Light Gallery
     --------------------------------------------- */
    function init_lightGallery() {

        if ($.fn.lightGallery && lightGalleryData) {

            $('article.post, article.page').find('a').on('click', function (e) {

                // Check link to media file.
                if (/(\.jpg|\.jpeg|\.png|\.gif)$/.test($(this).attr('href'))) {

                    var wpImages = $(this).find('img[class*="wp-image-"]');

                    // Check if there are attachment images.
                    if (wpImages.length) {
                        
                        e.stopImmediatePropagation();
                        e.preventDefault();

                        var postIdAtt = $(this).closest('article[id^="post-"]').attr('id'),
                            postId = (new RegExp('post-(\\d+)')).exec(postIdAtt)[1],
                            imageId = (new RegExp('wp-image-(\\d+)')).exec(wpImages.get(0).className)[1],
                            attachments = lightGalleryData[postId]['attachments'],
                            elements = lightGalleryData[postId]['elements'];
                        
                        var defaults = $.extend({
                            dynamic: true,
                            hash: false,
                            index: attachments[imageId],
                            thumbContHeight: 95,
                            preload: 2,
                            currentPagerPosition: 'middle',
                            dynamicEl: elements,
                        }, lightGalleryData['settings']);

                        $(this).lightGallery( defaults );
                    }
                }
            });
        }
    }
    
    /* ---------------------------------------------
     Featured Carousel Resize Height
     --------------------------------------------- */
    var featuredCarousel = getFeaturedCarousel(),
        featuredItemFoots = featuredCarousel.find('.featured-item-foot'),
        featuredItemImgs = featuredCarousel.find('.featured-img');

    function featCarousel_resize(){

        var maxHeight = 0;
        
        featuredItemFoots.each(function(indx, ele){
            if( $(this).outerHeight() > maxHeight ){
                maxHeight = $(this).outerHeight();
            }
        });

        if(maxHeight > 120){
            featuredItemFoots.each(function(indx, ele){
                $(this).outerHeight(maxHeight);
                if( ! $(this).find('.fix-footheight').length ){
                    $(this).wrapInner( $('<div>').addClass('fix-footheight') );
                }
            });
        }

        featuredItemImgs.each(function (indx, ele) {
            var itemHeight = $(this).height(),
                ratioHeight = $(this).find('.ratio-wrap').height(),
                ratioBoxStyle = $(this).find('.ratio-box').attr('style'),
                padding = /padding-bottom: (\d+(\.\d{1,})?)%/.exec(ratioBoxStyle);

            if (padding != null && ( ratioHeight > itemHeight )) {

                $(this).addClass('ratio-size-change');

                var newWidth = itemHeight / (padding[1] / 100);

                if (newWidth > 0) {
                    $(this).find('.ratio-wrap').width(newWidth);
                }
            }

        });

    }

    function getFeaturedCarousel(){
        var featCarousel = $('.featured-area');
        return (featCarousel.length)? featCarousel : $('.featured-area-2');
    }
    
    /* ---------------------------------------------
     Page Scroll
     --------------------------------------------- */
    function init_pageScroll(){
        
        $.each($('.page-scroll'), function(){
            
            $(this).click(function(){
                var hash_offset = $($(this).attr('href')).offset().top;
                
                $('html, body').animate({
                    scrollTop: hash_offset
                }, 800);
                
                return false;
            });
        });
    }
    
    /* ---------------------------------------------
     Fitvids
     --------------------------------------------- */
    function init_fitvids(){
        $(".container").fitVids();
    }

    /* ---------------------------------------------
     Grid Posts
     --------------------------------------------- */
    function init_gridPosts(){
        var posts = $('article.grid-post'),
            maxHeight = 0;

        posts.css('min-height', 'initial');

        if ($(window).width() < 768) {
            posts.css('min-height', 'initial');
        } else {
            posts.each(function() {
                maxHeight = parseFloat($(this).outerHeight()) > maxHeight ? parseFloat($(this).outerHeight()) : maxHeight;
            });
            posts.css( 'min-height', maxHeight + 1 );
        }
    }

    /* ---------------------------------------------
     Image Ratio Functions.
     --------------------------------------------- */
    function init_ratioFitImgs(){
        $('.ratio-fit').each(function (){
            var attr = $(this).find('.ratio-wrap').attr('style');
            if (typeof attr !== typeof undefined && attr !== false) {
                $(this).addClass('ratio-size-change');
            }
        });
    }

    function ratioSizeChangeItems(){
        var ratioSizeChangeItems = $('.ratio-size-change');

        ratioSizeChangeItems.each(function (indx, ele) {
            var itemHeight = $(this).innerHeight(),
                ratioBoxStyle = $(this).find('.ratio-box').attr('style'),
                padding = /padding-bottom: (\d+(\.\d{1,})?)%/.exec(ratioBoxStyle),
                maxWidth = $(this).find('.ratio-wrap').attr('data-width');


            if( padding != null ){
                var newWidth = itemHeight / (padding[1] / 100);

                if (newWidth > 0 && newWidth <= maxWidth) {
                    $(this).find('.ratio-wrap').width(newWidth);
                } else if (newWidth > maxWidth){
                    $(this).find('.ratio-wrap').width(maxWidth);
                }
            }

        });
    }
    
    /* ---------------------------------------------
     Background Images
    --------------------------------------------- */
    function init_bgImages() {
        $('.img-background').each(function (indx) {

            if ($(this).attr("data-background")){
                $(this).css("background-image", "url(" + $(this).data("background") + ")");
            }
        });      
    }
    
    /* ---------------------------------------------
     Page Loader
     --------------------------------------------- */
    function init_pageloader() {
        
        if ($('.page-loader').length) {

            $('a').click(function (event) {

                var urlPattern = new RegExp("(https?:\/\/(?:www\.|(?!www))[^\s\.]+\.[^\s]{2,}|www\.[^\s]+\.[^\s]{2,})"),
                    url = $(this).attr('href'),
                    attr = $(this).attr('rel');

                if (typeof attr !== typeof undefined && attr !== false &&
                    attr == 'nofollow' || $(this).attr('target')) {
                    return;
                }

                if (urlPattern.exec(url) && (!/^javascript:/.test(url)) &&
                    !(/(\.jpg|\.jpeg|\.png|\.gif)$/.test( url )) ) {

                    event.preventDefault();
                    $(".page-loader").fadeIn('slow', function () {
                        document.location.href = url;
                    });
                    return false;
                }
            });
        }
    }

    /* ---------------------------------------------
     Scripts Initialization
     --------------------------------------------- */
    $(window).load(function(){

        // Page loader
        $(".page-loader .loader").delay(0).fadeOut();
        $(".page-loader").delay(200).fadeOut("slow");

        // Hash menu forwarding
        if (window.location.hash && $(window.location.hash).offset()){
            var hash_offset = $(window.location.hash).offset().top - 60;
            $('html, body').animate({
                scrollTop: hash_offset
            }, 1000);
        }

        $(window).trigger('resize');
    });

    $(document).ready(function(){
        $(window).trigger('resize');

        init_mainMenu();
        init_js_heights();
        init_owlCarousel();
        init_pageScroll();
        init_pageloader();
        init_bgImages();
        init_fitvids();
        init_lightGallery();
        init_gridPosts();
        init_ratioFitImgs();
    });

    $(window).resize(function(){
        featCarousel_resize();
        mainMenu_resize();
        init_js_heights();
        init_gridPosts();
        ratioSizeChangeItems();
    });

    var resizeId;
    $(window).resize(function() {
        clearTimeout(resizeId);
        resizeId = setTimeout(doneResizing, 350);
    });

    function doneResizing(){
        ratioSizeChangeItems();
    }
    
})(jQuery);