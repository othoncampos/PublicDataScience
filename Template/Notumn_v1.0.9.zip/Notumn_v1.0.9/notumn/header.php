<?php
/**
 * Header file.
 *
 * @package notumn
 * @since 1.0
 */

global $notumn_is_header;
$notumn_is_header = true;
$notumn_home_layout    = 'notumn_' . get_theme_mod( 'notumn_homepage_layout', 'fullwidth' );

?><!DOCTYPE html>
<html <?php language_attributes() ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    <meta name="theme-color" content="<?php echo notumn_get_theme_color(); ?>" />

    <?php wp_head(); ?>
</head>
<body <?php body_class( $notumn_home_layout ); ?>>

<?php
$notumn_page_preloader = get_theme_mod( 'notumn_preloader', 'spinner' );
if ( $notumn_page_preloader !== 'Off' ) : ?>

	<div class="page-loader">

		<?php if ( $notumn_page_preloader === 'spinner' ) : ?>
		<div class="loader spinner">Loading...</div>
		<?php elseif ( $notumn_page_preloader === 'logo_blink' ) : ?>
		<div class="loader logo-blink"><img src="<?php
			echo esc_url( get_theme_mod( 'notumn_header_logo' ) ); ?>" alt="<?php bloginfo( 'name' ); ?>"></div>
		<?php endif; ?>

	</div><!-- .page-loader -->

<?php endif; ?>

<!-- Page Wrap -->
<div class="page-wrap" id="top">

	<!-- Navigation -->
	<div class="js-height-child" style="min-height: 52px;">
		<nav class="main-nav font-2">
			<div class="container relative">

				<div class="mobile-nav">
					<i class="fa fa-bars"></i>
				</div>

				<?php notumn_main_menu(); ?>

				<ul class="right-nav clearlist">
					
					<?php get_template_part( 'includes/templates/notumn_social_links' );?>
					
					<li><a href="javascript:void(0)" class="search-nav">&nbsp;&nbsp;<label for="search"><i class="fa fa-search"></i></label></a></li>
				</ul><!-- .right-nav -->

				<div class="search-container">
					<?php get_search_form(); ?>
				</div><!-- .search-contaiener-->
			</div><!-- .contaiener -->
		</nav><!-- .main-nav -->
	</div>
	<!-- End Navigation -->

	<!-- Header Logo -->
	<?php
	$notumn_border_margin_class = ( (! is_singular() && ! is_archive() && ! is_search()) || is_front_page() ) ? 'bottom-border-margin' : '';

	?>
	<section class="header-logo <?php echo sanitize_html_class( $notumn_border_margin_class ) ?>">
		<div class="container relative">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<img
					src="<?php echo esc_url( get_theme_mod( 'notumn_header_logo', get_template_directory_uri() . '/img/logo-dark.png' ) ); ?>"
					alt="<?php bloginfo( 'name' ); ?>"
					width="<?php echo esc_attr( get_theme_mod( 'notumn_header_logo_size', 280 ) ); ?>"></a>
		</div>
	</section><!-- End Header Logo -->
	<?php
$notumn_is_header = false;
