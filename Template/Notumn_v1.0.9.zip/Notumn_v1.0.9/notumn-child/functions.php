<?php
/**
 * Notumn Child functions
 *
 * @package notumn
 * @since 1.0
 */

/**
 * Enqueue Child Styles
 */

function notumn_child_enqueue_scripts(){

	// Register Styles.
	wp_register_style( 'notumn-child', get_stylesheet_directory_uri() . '/style.css', array(), NOTUMN_VER );

	// Enqueue Styles.
	wp_enqueue_style( 'notumn-child' );
}
add_action( 'wp_enqueue_scripts', 'notumn_child_enqueue_scripts', 999 );
