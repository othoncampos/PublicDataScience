# PublicDataScience
Grupo de Estudos para estudo de dados públicos abertos.
